

#include "Comp_Control.h"
#include "Comp_Control_private.h"
#define Comp_Control_p                 (10.0)
#define Comp_Control_nv_a              (3.0)
#define Comp_Control_nv_aa             (3.0)
#define Comp_Contr_IN_Unit_Off_by_Alarm ((uint8_T)3U)
#define Comp_Contro_IN_Initial_OffAlarm ((uint8_T)3U)
#define Comp_Contro_IN_Unit_Off_by_User ((uint8_T)4U)
#define Comp_Control_IN_Cooling_Plant  ((uint8_T)1U)
#define Comp_Control_IN_Defrost        ((uint8_T)1U)
#define Comp_Control_IN_Exit_state     ((uint8_T)2U)
#define Comp_Control_IN_Exit_state2    ((uint8_T)1U)
#define Comp_Control_IN_HeatCool       ((uint8_T)2U)
#define Comp_Control_IN_Heating_DHW    ((uint8_T)3U)
#define Comp_Control_IN_Heating_Plant  ((uint8_T)4U)
#define Comp_Control_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define Comp_Control_IN_OffAlarm       ((uint8_T)4U)
#define Comp_Control_IN_ThermoOff      ((uint8_T)2U)


B_Comp_Control_T Comp_Control_B;
DW_Comp_Control_T Comp_Control_DW;
ExtU_Comp_Control_T Comp_Control_U;
ExtY_Comp_Control_T Comp_Control_Y;
RT_MODEL_Comp_Control_T Comp_Control_M_;
RT_MODEL_Comp_Control_T *const Comp_Control_M = &Comp_Control_M_;

static void Comp_Control_Unconstrained(const real_T b_Hinv[9], const real_T f[3],
  real_T x[3], int16_T n);
static real_T Comp_Control_norm(const real_T x[3]);
static void Comp_Control_abs(const real_T x[3], real_T y[3]);
static void Comp_Control_abs_a(const real_T x[24], real_T y[24]);
static real_T Comp_Control_xnrm2(int32_T n, const real_T x[9], int32_T ix0);
static void Comp_Control_xgemv(int32_T m, int32_T n, const real_T b_A[9],
  int32_T ia0, const real_T x[9], int32_T ix0, real_T y[3]);
static void Comp_Control_xgerc(int32_T m, int32_T n, real_T alpha1, int32_T ix0,
  const real_T y[3], real_T b_A[9], int32_T ia0);
static void Comp_Control_qr(const real_T b_A[9], real_T Q[9], real_T R[9]);
static real_T Comp_Control_KWIKfactor(const real_T b_Ac[72], const int16_T iC[24],
  int16_T nA, const real_T b_Linv[9], real_T RLinv[9], real_T D[9], real_T b_H[9],
  int16_T n);
static void Comp_Control_DropConstraint(int16_T kDrop, int16_T iA[24], int16_T
  *nA, int16_T iC[24]);
static void Comp_Control_qpkwik(const real_T b_Linv[9], const real_T b_Hinv[9],
  const real_T f[3], const real_T b_Ac[72], const real_T b[24], int16_T iA[24],
  int16_T b_maxiter, real_T FeasTol, real_T x[3], real_T lambda[24], real_T
  *status);


static void Comp_Control_Unconstrained_g(const real_T b_Hinv[9], const real_T f
  [3], real_T x[3], int16_T n);
static real_T Comp_Control_norm_m(const real_T x[3]);
static void Comp_Control_abs_d(const real_T x[3], real_T y[3]);
static void Comp_Control_abs_dw(const real_T x[24], real_T y[24]);
static real_T Comp_Control_xnrm2_p(int32_T n, const real_T x[9], int32_T ix0);
static void Comp_Control_xgemv_j(int32_T m, int32_T n, const real_T b_A[9],
  int32_T ia0, const real_T x[9], int32_T ix0, real_T y[3]);
static void Comp_Control_xgerc_p(int32_T m, int32_T n, real_T alpha1, int32_T
  ix0, const real_T y[3], real_T b_A[9], int32_T ia0);
static void Comp_Control_qr_n(const real_T b_A[9], real_T Q[9], real_T R[9]);
static real_T Comp_Control_KWIKfactor_a(const real_T b_Ac[72], const int16_T iC
  [24], int16_T nA, const real_T b_Linv[9], real_T RLinv[9], real_T D[9], real_T
  b_H[9], int16_T n);
static void Comp_Control_DropConstraint_p(int16_T kDrop, int16_T iA[24], int16_T
  *nA, int16_T iC[24]);
static void Comp_Control_qpkwik_j(const real_T b_Linv[9], const real_T b_Hinv[9],
  const real_T f[3], const real_T b_Ac[72], const real_T b[24], int16_T iA[24],
  int16_T b_maxiter, real_T FeasTol, real_T x[3], real_T lambda[24], real_T
  *status);


static void Comp_Co_enter_internal_HeatCool(void);
static void Comp_Control_Defrost(void);


static void Comp_Control_Unconstrained(const real_T b_Hinv[9], const real_T f[3],
  real_T x[3], int16_T n)
{
  int32_T i;
  real_T b_Hinv_0;
  int32_T i_0;
  for (i = 1; i - 1 < n; i++) {
    i_0 = (int16_T)i;
    b_Hinv_0 = -b_Hinv[i_0 - 1] * f[0];
    b_Hinv_0 += -b_Hinv[i_0 + 2] * f[1];
    b_Hinv_0 += -b_Hinv[i_0 + 5] * f[2];
    x[(int16_T)i - 1] = b_Hinv_0;
  }
}

/* Function for MATLAB Function: '<S68>/optimizer' */
static real_T Comp_Control_norm(const real_T x[3])
{
  real_T y;
  real_T scale;
  real_T absxk;
  real_T t;
  scale = 3.3121686421112381E-170;
  absxk = fabs(x[0]);
  if (absxk > 3.3121686421112381E-170) {
    y = 1.0;
    scale = absxk;
  } else {
    t = absxk / 3.3121686421112381E-170;
    y = t * t;
  }

  absxk = fabs(x[1]);
  if (absxk > scale) {
    t = scale / absxk;
    y = y * t * t + 1.0;
    scale = absxk;
  } else {
    t = absxk / scale;
    y += t * t;
  }

  absxk = fabs(x[2]);
  if (absxk > scale) {
    t = scale / absxk;
    y = y * t * t + 1.0;
    scale = absxk;
  } else {
    t = absxk / scale;
    y += t * t;
  }

  return scale * sqrt(y);
}

/* Function for MATLAB Function: '<S68>/optimizer' */
static void Comp_Control_abs(const real_T x[3], real_T y[3])
{
  y[0] = fabs(x[0]);
  y[1] = fabs(x[1]);
  y[2] = fabs(x[2]);
}

/* Function for MATLAB Function: '<S68>/optimizer' */
static void Comp_Control_abs_a(const real_T x[24], real_T y[24])
{
  int32_T k;
  for (k = 0; k < 24; k++) {
    y[k] = fabs(x[k]);
  }
}

/* Function for MATLAB Function: '<S68>/optimizer' */
static real_T Comp_Control_xnrm2(int32_T n, const real_T x[9], int32_T ix0)
{
  real_T y;
  real_T scale;
  int32_T kend;
  real_T absxk;
  real_T t;
  int32_T k;
  y = 0.0;
  if (n >= 1) {
    if (n == 1) {
      y = fabs(x[ix0 - 1]);
    } else {
      scale = 3.3121686421112381E-170;
      kend = (ix0 + n) - 1;
      for (k = ix0; k <= kend; k++) {
        absxk = fabs(x[k - 1]);
        if (absxk > scale) {
          t = scale / absxk;
          y = y * t * t + 1.0;
          scale = absxk;
        } else {
          t = absxk / scale;
          y += t * t;
        }
      }

      y = scale * sqrt(y);
    }
  }

  return y;
}

real_T rt_hypotd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T a;
  a = fabs(u0);
  y = fabs(u1);
  if (a < y) {
    a /= y;
    y *= sqrt(a * a + 1.0);
  } else if (a > y) {
    y /= a;
    y = sqrt(y * y + 1.0) * a;
  } else {
    if (!rtIsNaN(y)) {
      y = a * 1.4142135623730951;
    }
  }

  return y;
}

/* Function for MATLAB Function: '<S68>/optimizer' */
static void Comp_Control_xgemv(int32_T m, int32_T n, const real_T b_A[9],
  int32_T ia0, const real_T x[9], int32_T ix0, real_T y[3])
{
  int32_T ix;
  real_T c;
  int32_T b_iy;
  int32_T b;
  int32_T iac;
  int32_T d;
  int32_T ia;
  if ((m != 0) && (n != 0)) {
    for (b_iy = 0; b_iy < n; b_iy++) {
      y[b_iy] = 0.0;
    }

    b_iy = 0;
    b = (n - 1) * 3 + ia0;
    for (iac = ia0; iac <= b; iac += 3) {
      ix = ix0;
      c = 0.0;
      d = (iac + m) - 1;
      for (ia = iac; ia <= d; ia++) {
        c += b_A[ia - 1] * x[ix - 1];
        ix++;
      }

      y[b_iy] += c;
      b_iy++;
    }
  }
}

/* Function for MATLAB Function: '<S68>/optimizer' */
static void Comp_Control_xgerc(int32_T m, int32_T n, real_T alpha1, int32_T ix0,
  const real_T y[3], real_T b_A[9], int32_T ia0)
{
  int32_T jA;
  int32_T jy;
  real_T temp;
  int32_T ix;
  int32_T j;
  int32_T b;
  int32_T ijA;
  if (!(alpha1 == 0.0)) {
    jA = ia0 - 1;
    jy = 0;
    for (j = 0; j < n; j++) {
      if (y[jy] != 0.0) {
        temp = y[jy] * alpha1;
        ix = ix0;
        b = m + jA;
        for (ijA = jA; ijA < b; ijA++) {
          b_A[ijA] += b_A[ix - 1] * temp;
          ix++;
        }
      }

      jy++;
      jA += 3;
    }
  }
}

/* Function for MATLAB Function: '<S68>/optimizer' */
static void Comp_Control_qr(const real_T b_A[9], real_T Q[9], real_T R[9])
{
  real_T c_A[9];
  real_T work[3];
  real_T b;
  real_T b_atmp;
  real_T xnorm;
  int32_T knt;
  int32_T lastc;
  int32_T coltop;
  int32_T b_coltop;
  real_T tau_idx_0;
  int32_T exitg1;
  boolean_T exitg2;
  memcpy(&c_A[0], &b_A[0], 9U * sizeof(real_T));
  work[0] = 0.0;
  work[1] = 0.0;
  work[2] = 0.0;
  b_atmp = c_A[0];
  b = 0.0;
  xnorm = Comp_Control_xnrm2(2, c_A, 2);
  if (xnorm != 0.0) {
    xnorm = rt_hypotd_snf(c_A[0], xnorm);
    if (c_A[0] >= 0.0) {
      xnorm = -xnorm;
    }

    if (fabs(xnorm) < 1.0020841800044864E-292) {
      knt = -1;
      lastc = 0;
      do {
        knt++;
        for (coltop = 1; coltop < 3; coltop++) {
          c_A[coltop] *= 9.9792015476736E+291;
        }

        xnorm *= 9.9792015476736E+291;
        b_atmp *= 9.9792015476736E+291;
      } while (!(fabs(xnorm) >= 1.0020841800044864E-292));

      xnorm = rt_hypotd_snf(b_atmp, Comp_Control_xnrm2(2, c_A, 2));
      if (b_atmp >= 0.0) {
        xnorm = -xnorm;
      }

      b = (xnorm - b_atmp) / xnorm;
      b_atmp = 1.0 / (b_atmp - xnorm);
      for (coltop = 1; coltop < 3; coltop++) {
        c_A[coltop] *= b_atmp;
      }

      while (lastc <= knt) {
        xnorm *= 1.0020841800044864E-292;
        lastc++;
      }

      b_atmp = xnorm;
    } else {
      b = (xnorm - c_A[0]) / xnorm;
      b_atmp = 1.0 / (c_A[0] - xnorm);
      for (lastc = 1; lastc < 3; lastc++) {
        c_A[lastc] *= b_atmp;
      }

      b_atmp = xnorm;
    }
  }

  tau_idx_0 = b;
  c_A[0] = b_atmp;
  b_atmp = c_A[0];
  c_A[0] = 1.0;
  if (tau_idx_0 != 0.0) {
    knt = 3;
    lastc = 0;
    while ((knt > 0) && (c_A[lastc + 2] == 0.0)) {
      knt--;
      lastc--;
    }

    lastc = 2;
    exitg2 = false;
    while ((!exitg2) && (lastc > 0)) {
      coltop = (lastc - 1) * 3 + 3;
      b_coltop = coltop;
      do {
        exitg1 = 0;
        if (b_coltop + 1 <= coltop + knt) {
          if (c_A[b_coltop] != 0.0) {
            exitg1 = 1;
          } else {
            b_coltop++;
          }
        } else {
          lastc--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    Comp_Control_xgemv(knt, lastc, c_A, 4, c_A, 1, work);
    Comp_Control_xgerc(knt, lastc, -tau_idx_0, 1, work, c_A, 4);
  }

  c_A[0] = b_atmp;
  b_atmp = c_A[4];
  b = 0.0;
  xnorm = Comp_Control_xnrm2(1, c_A, 6);
  if (xnorm != 0.0) {
    xnorm = rt_hypotd_snf(c_A[4], xnorm);
    if (c_A[4] >= 0.0) {
      xnorm = -xnorm;
    }

    if (fabs(xnorm) < 1.0020841800044864E-292) {
      knt = -1;
      do {
        knt++;
        for (coltop = 5; coltop < 6; coltop++) {
          c_A[coltop] *= 9.9792015476736E+291;
        }

        xnorm *= 9.9792015476736E+291;
        b_atmp *= 9.9792015476736E+291;
      } while (!(fabs(xnorm) >= 1.0020841800044864E-292));

      xnorm = rt_hypotd_snf(b_atmp, Comp_Control_xnrm2(1, c_A, 6));
      if (b_atmp >= 0.0) {
        xnorm = -xnorm;
      }

      b = (xnorm - b_atmp) / xnorm;
      b_atmp = 1.0 / (b_atmp - xnorm);
      for (coltop = 5; coltop < 6; coltop++) {
        c_A[coltop] *= b_atmp;
      }

      for (lastc = 0; lastc <= knt; lastc++) {
        xnorm *= 1.0020841800044864E-292;
      }

      b_atmp = xnorm;
    } else {
      b = (xnorm - c_A[4]) / xnorm;
      b_atmp = 1.0 / (c_A[4] - xnorm);
      for (lastc = 5; lastc < 6; lastc++) {
        c_A[lastc] *= b_atmp;
      }

      b_atmp = xnorm;
    }
  }

  c_A[4] = b_atmp;
  b_atmp = c_A[4];
  c_A[4] = 1.0;
  if (b != 0.0) {
    knt = 2;
    lastc = 3;
    while ((knt > 0) && (c_A[lastc + 2] == 0.0)) {
      knt--;
      lastc--;
    }

    lastc = 1;
    b_coltop = 7;
    do {
      exitg1 = 0;
      if (b_coltop + 1 <= 7 + knt) {
        if (c_A[b_coltop] != 0.0) {
          exitg1 = 1;
        } else {
          b_coltop++;
        }
      } else {
        lastc = 0;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    Comp_Control_xgemv(knt, lastc, c_A, 8, c_A, 5, work);
    Comp_Control_xgerc(knt, lastc, -b, 5, work, c_A, 8);
  }

  c_A[4] = b_atmp;
  R[0] = c_A[0];
  for (lastc = 1; lastc + 1 < 4; lastc++) {
    R[lastc] = 0.0;
  }

  work[0] = 0.0;
  for (lastc = 0; lastc < 2; lastc++) {
    R[lastc + 3] = c_A[lastc + 3];
  }

  while (lastc + 1 < 4) {
    R[lastc + 3] = 0.0;
    lastc++;
  }

  work[1] = 0.0;
  for (lastc = 0; lastc < 3; lastc++) {
    R[lastc + 6] = c_A[lastc + 6];
  }

  work[2] = 0.0;
  c_A[8] = 1.0;
  for (lastc = 0; lastc < 2; lastc++) {
    c_A[7 - lastc] = 0.0;
  }

  c_A[4] = 1.0;
  if (b != 0.0) {
    coltop = 7;
    while ((lastc > 0) && (c_A[coltop - 2] == 0.0)) {
      lastc--;
      coltop--;
    }

    coltop = 1;
    knt = 8;
    do {
      exitg1 = 0;
      if (knt <= lastc + 7) {
        if (c_A[knt - 1] != 0.0) {
          exitg1 = 1;
        } else {
          knt++;
        }
      } else {
        coltop = 0;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    lastc = 0;
    coltop = 0;
  }

  if (lastc > 0) {
    Comp_Control_xgemv(lastc, coltop, c_A, 8, c_A, 5, work);
    Comp_Control_xgerc(lastc, coltop, -b, 5, work, c_A, 8);
  }

  for (coltop = 5; coltop < 6; coltop++) {
    c_A[coltop] *= -b;
  }

  c_A[4] = 1.0 - b;
  c_A[3] = 0.0;
  c_A[0] = 1.0;
  if (tau_idx_0 != 0.0) {
    lastc = 3;
    coltop = 4;
    while ((lastc > 0) && (c_A[coltop - 2] == 0.0)) {
      lastc--;
      coltop--;
    }

    coltop = 2;
    exitg2 = false;
    while ((!exitg2) && (coltop > 0)) {
      b_coltop = (coltop - 1) * 3 + 4;
      knt = b_coltop;
      do {
        exitg1 = 0;
        if (knt <= (b_coltop + lastc) - 1) {
          if (c_A[knt - 1] != 0.0) {
            exitg1 = 1;
          } else {
            knt++;
          }
        } else {
          coltop--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    lastc = 0;
    coltop = 0;
  }

  if (lastc > 0) {
    Comp_Control_xgemv(lastc, coltop, c_A, 4, c_A, 1, work);
    Comp_Control_xgerc(lastc, coltop, -tau_idx_0, 1, work, c_A, 4);
  }

  for (coltop = 1; coltop < 3; coltop++) {
    c_A[coltop] *= -tau_idx_0;
  }

  c_A[0] = 1.0 - tau_idx_0;
  for (lastc = 0; lastc < 3; lastc++) {
    Q[3 * lastc] = c_A[3 * lastc];
    Q[3 * lastc + 1] = c_A[3 * lastc + 1];
    Q[3 * lastc + 2] = c_A[3 * lastc + 2];
  }
}

/* Function for MATLAB Function: '<S68>/optimizer' */
static real_T Comp_Control_KWIKfactor(const real_T b_Ac[72], const int16_T iC[24],
  int16_T nA, const real_T b_Linv[9], real_T RLinv[9], real_T D[9], real_T b_H[9],
  int16_T n)
{
  real_T Status;
  real_T TL[9];
  real_T QQ[9];
  real_T RR[9];
  int32_T i;
  int16_T b_j;
  int16_T c_k;
  int32_T f_i;
  real_T b_Linv_0;
  int32_T i_0;
  int32_T f_i_0;
  int32_T exitg1;
  Status = 1.0;
  memset(&RLinv[0], 0, 9U * sizeof(real_T));
  for (i = 1; i - 1 < nA; i++) {
    f_i_0 = iC[(int16_T)i - 1];
    i_0 = (int16_T)i - 1;
    for (f_i = 0; f_i < 3; f_i++) {
      RLinv[f_i + 3 * i_0] = 0.0;
      RLinv[f_i + 3 * i_0] += b_Ac[f_i_0 - 1] * b_Linv[f_i];
      RLinv[f_i + 3 * i_0] += b_Linv[f_i + 3] * b_Ac[f_i_0 + 23];
      RLinv[f_i + 3 * i_0] += b_Linv[f_i + 6] * b_Ac[f_i_0 + 47];
    }
  }

  Comp_Control_qr(RLinv, QQ, RR);
  i = 1;
  do {
    exitg1 = 0;
    if (i - 1 <= nA - 1) {
      if (fabs(RR[(((int16_T)i - 1) * 3 + (int16_T)i) - 1]) < 1.0E-12) {
        Status = -2.0;
        exitg1 = 1;
      } else {
        i++;
      }
    } else {
      for (i = 1; i - 1 < n; i++) {
        for (f_i = 1; f_i - 1 < n; f_i++) {
          i_0 = (int16_T)i;
          f_i_0 = (int16_T)f_i;
          b_Linv_0 = b_Linv[(i_0 - 1) * 3] * QQ[(f_i_0 - 1) * 3];
          b_Linv_0 += b_Linv[(i_0 - 1) * 3 + 1] * QQ[(f_i_0 - 1) * 3 + 1];
          b_Linv_0 += b_Linv[(i_0 - 1) * 3 + 2] * QQ[(f_i_0 - 1) * 3 + 2];
          TL[((int16_T)i + 3 * ((int16_T)f_i - 1)) - 1] = b_Linv_0;
        }
      }

      memset(&RLinv[0], 0, 9U * sizeof(real_T));
      for (b_j = nA; b_j > 0; b_j--) {
        RLinv[(b_j + 3 * (b_j - 1)) - 1] = 1.0;
        for (c_k = b_j; c_k <= nA; c_k++) {
          RLinv[(b_j + 3 * (c_k - 1)) - 1] /= RR[((b_j - 1) * 3 + b_j) - 1];
        }

        if (b_j > 1) {
          for (i = 1; i - 1 <= b_j - 2; i++) {
            for (c_k = b_j; c_k <= nA; c_k++) {
              RLinv[((int16_T)i + 3 * (c_k - 1)) - 1] -= RR[((b_j - 1) * 3 +
                (int16_T)i) - 1] * RLinv[((c_k - 1) * 3 + b_j) - 1];
            }
          }
        }
      }

      for (i = 1; i - 1 < n; i++) {
        for (b_j = (int16_T)i; b_j <= n; b_j++) {
          b_H[((int16_T)i + 3 * (b_j - 1)) - 1] = 0.0;
          f_i = nA + 1;
          if (f_i > 32767) {
            f_i = 32767;
          }

          for (c_k = (int16_T)f_i; c_k <= n; c_k++) {
            b_H[((int16_T)i + 3 * (b_j - 1)) - 1] -= TL[((c_k - 1) * 3 +
              (int16_T)i) - 1] * TL[((c_k - 1) * 3 + b_j) - 1];
          }

          b_H[(b_j + 3 * ((int16_T)i - 1)) - 1] = b_H[((b_j - 1) * 3 + (int16_T)
            i) - 1];
        }
      }

      for (i = 1; i - 1 < nA; i++) {
        for (f_i = 1; f_i - 1 < n; f_i++) {
          D[((int16_T)f_i + 3 * ((int16_T)i - 1)) - 1] = 0.0;
          for (b_j = (int16_T)i; b_j <= nA; b_j++) {
            D[((int16_T)f_i + 3 * ((int16_T)i - 1)) - 1] += TL[((b_j - 1) * 3 +
              (int16_T)f_i) - 1] * RLinv[((b_j - 1) * 3 + (int16_T)i) - 1];
          }
        }
      }

      exitg1 = 1;
    }
  } while (exitg1 == 0);

  return Status;
}

/* Function for MATLAB Function: '<S68>/optimizer' */
static void Comp_Control_DropConstraint(int16_T kDrop, int16_T iA[24], int16_T
  *nA, int16_T iC[24])
{
  int16_T b;
  int16_T i;
  int32_T tmp;
  iA[iC[kDrop - 1] - 1] = 0;
  if (kDrop < *nA) {
    tmp = *nA - 1;
    if (tmp < -32768) {
      tmp = -32768;
    }

    b = (int16_T)tmp;
    for (i = kDrop; i <= b; i++) {
      iC[i - 1] = iC[i];
    }
  }

  iC[*nA - 1] = 0;
  tmp = *nA - 1;
  if (tmp < -32768) {
    tmp = -32768;
  }

  *nA = (int16_T)tmp;
}

/* Function for MATLAB Function: '<S68>/optimizer' */
static void Comp_Control_qpkwik(const real_T b_Linv[9], const real_T b_Hinv[9],
  const real_T f[3], const real_T b_Ac[72], const real_T b[24], int16_T iA[24],
  int16_T b_maxiter, real_T FeasTol, real_T x[3], real_T lambda[24], real_T
  *status)
{
  real_T r[3];
  real_T rMin;
  real_T RLinv[9];
  real_T D[9];
  real_T b_H[9];
  real_T U[9];
  real_T cTol[24];
  boolean_T cTolComputed;
  int16_T iC[24];
  int16_T nA;
  real_T Opt[6];
  real_T Rhs[6];
  boolean_T DualFeasible;
  boolean_T ColdReset;
  int16_T kDrop;
  real_T Xnorm0;
  real_T cMin;
  int16_T kNext;
  real_T cVal;
  real_T AcRow[3];
  real_T z[3];
  real_T t;
  int16_T iSave;
  real_T varargin_1[24];
  int32_T idx;
  uint16_T q;
  uint16_T b_x;
  int32_T i;
  int32_T i_0;
  int32_T tmp;
  int32_T tmp_0;
  int32_T exitg1;
  int32_T exitg2;
  int32_T exitg3;
  boolean_T exitg4;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  *status = 1.0;
  x[0] = 0.0;
  r[0] = 0.0;
  x[1] = 0.0;
  r[1] = 0.0;
  x[2] = 0.0;
  r[2] = 0.0;
  rMin = 0.0;
  cTolComputed = false;
  for (i = 0; i < 24; i++) {
    lambda[i] = 0.0;
    cTol[i] = 1.0;
    iC[i] = 0;
  }

  nA = 0;
  for (i = 0; i < 24; i++) {
    if (iA[i] == 1) {
      i_0 = nA + 1;
      if (i_0 > 32767) {
        i_0 = 32767;
      }

      nA = (int16_T)i_0;
      iC[nA - 1] = (int16_T)(i + 1);
    }
  }

  guard1 = false;
  if (nA > 0) {
    for (i = 0; i < 6; i++) {
      Opt[i] = 0.0;
    }

    Rhs[0] = f[0];
    Rhs[3] = 0.0;
    Rhs[1] = f[1];
    Rhs[4] = 0.0;
    Rhs[2] = f[2];
    Rhs[5] = 0.0;
    DualFeasible = false;
    i_0 = 3 * nA;
    if (i_0 > 32767) {
      i_0 = 32767;
    }

    kNext = (int16_T)i_0;
    if (kNext <= 50) {
      kNext = 50;
    }

    q = (uint16_T)(kNext / 10U);
    b_x = (uint16_T)((uint32_T)kNext - q * 10);
    if ((b_x > 0) && (b_x >= 5)) {
      q++;
    }

    ColdReset = false;
    do {
      exitg3 = 0;
      if ((!DualFeasible) && (nA > 0) && ((int32_T)*status <= b_maxiter)) {
        Xnorm0 = Comp_Control_KWIKfactor(b_Ac, iC, nA, b_Linv, RLinv, D, b_H, 3);
        if (Xnorm0 < 0.0) {
          if (ColdReset) {
            *status = -2.0;
            exitg3 = 2;
          } else {
            nA = 0;
            for (i = 0; i < 24; i++) {
              iA[i] = 0;
              iC[i] = 0;
            }

            ColdReset = true;
          }
        } else {
          for (i = 1; i - 1 < nA; i++) {
            i_0 = (int16_T)i + 3;
            if (i_0 > 32767) {
              i_0 = 32767;
            }

            Rhs[i_0 - 1] = b[iC[(int16_T)i - 1] - 1];
            for (kNext = (int16_T)i; kNext <= nA; kNext++) {
              U[(kNext + 3 * ((int16_T)i - 1)) - 1] = 0.0;
              for (idx = 1; idx - 1 < nA; idx++) {
                U[(kNext + 3 * ((int16_T)i - 1)) - 1] += RLinv[(((int16_T)idx -
                  1) * 3 + kNext) - 1] * RLinv[(((int16_T)idx - 1) * 3 +
                  (int16_T)i) - 1];
              }

              U[((int16_T)i + 3 * (kNext - 1)) - 1] = U[(((int16_T)i - 1) * 3 +
                kNext) - 1];
            }
          }

          for (i = 0; i < 3; i++) {
            i_0 = i + 1;
            Xnorm0 = b_H[i_0 - 1] * Rhs[0];
            Xnorm0 += b_H[i_0 + 2] * Rhs[1];
            Xnorm0 += b_H[i_0 + 5] * Rhs[2];
            Opt[i] = Xnorm0;
            for (idx = 1; idx - 1 < nA; idx++) {
              i_0 = (int16_T)idx + 3;
              if (i_0 > 32767) {
                i_0 = 32767;
              }

              Opt[i] += D[((int16_T)idx - 1) * 3 + i] * Rhs[i_0 - 1];
            }
          }

          for (i = 1; i - 1 < nA; i++) {
            i_0 = (int16_T)i;
            Xnorm0 = D[(i_0 - 1) * 3] * Rhs[0];
            Xnorm0 += D[(i_0 - 1) * 3 + 1] * Rhs[1];
            Xnorm0 += D[(i_0 - 1) * 3 + 2] * Rhs[2];
            i_0 = (int16_T)i + 3;
            if (i_0 > 32767) {
              i_0 = 32767;
            }

            Opt[i_0 - 1] = Xnorm0;
            for (idx = 1; idx - 1 < nA; idx++) {
              i_0 = (int16_T)i + 3;
              if (i_0 > 32767) {
                i_0 = 32767;
              }

              tmp = (int16_T)i + 3;
              if (tmp > 32767) {
                tmp = 32767;
              }

              tmp_0 = (int16_T)idx + 3;
              if (tmp_0 > 32767) {
                tmp_0 = 32767;
              }

              Opt[i_0 - 1] = U[(((int16_T)idx - 1) * 3 + (int16_T)i) - 1] *
                Rhs[tmp_0 - 1] + Opt[tmp - 1];
            }
          }

          Xnorm0 = -1.0E-12;
          kDrop = 0;
          for (i = 1; i - 1 < nA; i++) {
            i_0 = (int16_T)i + 3;
            if (i_0 > 32767) {
              i_0 = 32767;
            }

            lambda[iC[(int16_T)i - 1] - 1] = Opt[i_0 - 1];
            i_0 = (int16_T)i + 3;
            if (i_0 > 32767) {
              i_0 = 32767;
            }

            if ((Opt[i_0 - 1] < Xnorm0) && ((int16_T)i <= nA)) {
              kDrop = (int16_T)i;
              i_0 = (int16_T)i + 3;
              if (i_0 > 32767) {
                i_0 = 32767;
              }

              Xnorm0 = Opt[i_0 - 1];
            }
          }

          if (kDrop <= 0) {
            DualFeasible = true;
            x[0] = Opt[0];
            x[1] = Opt[1];
            x[2] = Opt[2];
          } else {
            (*status)++;
            if ((int32_T)*status > q) {
              nA = 0;
              for (i = 0; i < 24; i++) {
                iA[i] = 0;
                iC[i] = 0;
              }

              ColdReset = true;
            } else {
              lambda[iC[kDrop - 1] - 1] = 0.0;
              Comp_Control_DropConstraint(kDrop, iA, &nA, iC);
            }
          }
        }
      } else {
        if (nA <= 0) {
          memset(&lambda[0], 0, 24U * sizeof(real_T));
          Comp_Control_Unconstrained(b_Hinv, f, x, 3);
        }

        exitg3 = 1;
      }
    } while (exitg3 == 0);

    if (exitg3 == 1) {
      guard1 = true;
    }
  } else {
    Comp_Control_Unconstrained(b_Hinv, f, x, 3);
    guard1 = true;
  }

  if (guard1) {
    Xnorm0 = Comp_Control_norm(x);
    do {
      exitg2 = 0;
      if ((int32_T)*status <= b_maxiter) {
        cMin = -FeasTol;
        kNext = 0;
        for (i = 0; i < 24; i++) {
          if (!cTolComputed) {
            i_0 = i + 1;
            z[0] = b_Ac[i_0 - 1] * x[0];
            z[1] = b_Ac[i_0 + 23] * x[1];
            z[2] = b_Ac[i_0 + 47] * x[2];
            Comp_Control_abs(z, AcRow);
            if (!rtIsNaN(AcRow[0])) {
              idx = 1;
            } else {
              idx = 0;
              i_0 = 2;
              exitg4 = false;
              while ((!exitg4) && (i_0 < 4)) {
                if (!rtIsNaN(AcRow[i_0 - 1])) {
                  idx = i_0;
                  exitg4 = true;
                } else {
                  i_0++;
                }
              }
            }

            if (idx == 0) {
              cVal = AcRow[0];
            } else {
              cVal = AcRow[idx - 1];
              while (idx + 1 <= 3) {
                if (cVal < AcRow[idx]) {
                  cVal = AcRow[idx];
                }

                idx++;
              }
            }

            cTol[i] = fmax(cTol[i], cVal);
          }

          if (iA[i] == 0) {
            i_0 = i + 1;
            cVal = b_Ac[i_0 - 1] * x[0];
            cVal += b_Ac[i_0 + 23] * x[1];
            cVal += b_Ac[i_0 + 47] * x[2];
            cVal = (cVal - b[i]) / cTol[i];
            if (cVal < cMin) {
              cMin = cVal;
              kNext = (int16_T)(i + 1);
            }
          }
        }

        cTolComputed = true;
        if (kNext <= 0) {
          exitg2 = 1;
        } else {
          do {
            exitg1 = 0;
            if ((kNext > 0) && ((int32_T)*status <= b_maxiter)) {
              i = kNext;
              AcRow[0] = b_Ac[i - 1];
              AcRow[1] = b_Ac[i + 23];
              AcRow[2] = b_Ac[i + 47];
              guard2 = false;
              if (nA == 0) {
                i = kNext;
                for (i_0 = 0; i_0 < 3; i_0++) {
                  cMin = b_Ac[i - 1] * b_Hinv[i_0];
                  cMin += b_Hinv[i_0 + 3] * b_Ac[i + 23];
                  cMin += b_Hinv[i_0 + 6] * b_Ac[i + 47];
                  z[i_0] = cMin;
                }

                guard2 = true;
              } else {
                cMin = Comp_Control_KWIKfactor(b_Ac, iC, nA, b_Linv, RLinv, D,
                  b_H, 3);
                if (cMin <= 0.0) {
                  *status = -2.0;
                  exitg1 = 1;
                } else {
                  for (i_0 = 0; i_0 < 9; i_0++) {
                    U[i_0] = -b_H[i_0];
                  }

                  for (i_0 = 0; i_0 < 3; i_0++) {
                    cMin = U[i_0] * AcRow[0];
                    cMin += U[i_0 + 3] * AcRow[1];
                    cMin += U[i_0 + 6] * AcRow[2];
                    z[i_0] = cMin;
                  }

                  for (i = 1; i - 1 < nA; i++) {
                    i_0 = (int16_T)i;
                    t = D[(i_0 - 1) * 3] * AcRow[0];
                    t += D[(i_0 - 1) * 3 + 1] * AcRow[1];
                    t += D[(i_0 - 1) * 3 + 2] * AcRow[2];
                    r[(int16_T)i - 1] = t;
                  }

                  guard2 = true;
                }
              }

              if (guard2) {
                kDrop = 0;
                cMin = 0.0;
                DualFeasible = true;
                ColdReset = true;
                if (nA > 0) {
                  i = 0;
                  exitg4 = false;
                  while ((!exitg4) && (i <= nA - 1)) {
                    if (r[i] >= 1.0E-12) {
                      ColdReset = false;
                      exitg4 = true;
                    } else {
                      i++;
                    }
                  }
                }

                ColdReset = ((nA == 0) || ColdReset);
                if (!ColdReset) {
                  for (i = 1; i - 1 < nA; i++) {
                    if (r[(int16_T)i - 1] > 1.0E-12) {
                      cVal = lambda[iC[(int16_T)i - 1] - 1] / r[(int16_T)i - 1];
                      if ((kDrop == 0) || (cVal < rMin)) {
                        rMin = cVal;
                        kDrop = (int16_T)i;
                      }
                    }
                  }

                  if (kDrop > 0) {
                    cMin = rMin;
                    DualFeasible = false;
                  }
                }

                cVal = z[0] * AcRow[0];
                cVal += z[1] * AcRow[1];
                cVal += z[2] * AcRow[2];
                if (cVal <= 0.0) {
                  cVal = 0.0;
                  ColdReset = true;
                } else {
                  t = AcRow[0] * x[0];
                  t += AcRow[1] * x[1];
                  t += AcRow[2] * x[2];
                  cVal = (b[kNext - 1] - t) / cVal;
                  ColdReset = false;
                }

                if (DualFeasible && ColdReset) {
                  *status = -1.0;
                  exitg1 = 1;
                } else {
                  if (ColdReset) {
                    t = cMin;
                  } else if (DualFeasible) {
                    t = cVal;
                  } else {
                    t = fmin(cMin, cVal);
                  }

                  for (i = 1; i - 1 < nA; i++) {
                    lambda[iC[(int16_T)i - 1] - 1] -= r[(int16_T)i - 1] * t;
                    if ((iC[(int16_T)i - 1] <= 24) && (lambda[iC[(int16_T)i - 1]
                         - 1] < 0.0)) {
                      lambda[iC[(int16_T)i - 1] - 1] = 0.0;
                    }
                  }

                  lambda[kNext - 1] += t;
                  if (t == cMin) {
                    Comp_Control_DropConstraint(kDrop, iA, &nA, iC);
                  }

                  if (!ColdReset) {
                    cMin = x[0];
                    cMin += t * z[0];
                    x[0] = cMin;
                    cMin = x[1];
                    cMin += t * z[1];
                    x[1] = cMin;
                    cMin = x[2];
                    cMin += t * z[2];
                    x[2] = cMin;
                    if (t == cVal) {
                      if (nA == 3) {
                        *status = -1.0;
                        exitg1 = 1;
                      } else {
                        i_0 = nA + 1;
                        if (i_0 > 32767) {
                          i_0 = 32767;
                        }

                        nA = (int16_T)i_0;
                        iC[nA - 1] = kNext;
                        kDrop = nA;
                        while ((kDrop > 1) && (iC[kDrop - 1] <= iC[kDrop - 2]))
                        {
                          iSave = iC[kDrop - 1];
                          iC[kDrop - 1] = iC[kDrop - 2];
                          iC[kDrop - 2] = iSave;
                          kDrop--;
                        }

                        iA[kNext - 1] = 1;
                        kNext = 0;
                        (*status)++;
                      }
                    } else {
                      (*status)++;
                    }
                  } else {
                    (*status)++;
                  }
                }
              }
            } else {
              cMin = Comp_Control_norm(x);
              if (fabs(cMin - Xnorm0) > 0.001) {
                Xnorm0 = cMin;
                Comp_Control_abs_a(b, varargin_1);
                for (i = 0; i < 24; i++) {
                  cTol[i] = fmax(varargin_1[i], 1.0);
                }

                cTolComputed = false;
              }

              exitg1 = 2;
            }
          } while (exitg1 == 0);

          if (exitg1 == 1) {
            exitg2 = 1;
          }
        }
      } else {
        *status = 0.0;
        exitg2 = 1;
      }
    } while (exitg2 == 0);
  }
}

/*
 * Output and update for atomic system:
 *    '<S68>/optimizer'
 *    '<S165>/optimizer'
 */
void Comp_Control_optimizer(const real_T rtu_xk[3], real_T rtu_old_u, real_T
  rtu_ym, real_T rtu_ref, const boolean_T rtu_iA[24], B_optimizer_Comp_Control_T
  *localB)
{
  real_T y_innov;
  real_T cost;
  real_T aux2[10];
  real_T aux3[10];
  real_T aux[3];
  real_T xQP[3];
  real_T zopt[3];
  real_T unusedU0[24];
  int16_T iAnew[24];
  int8_T K[100];
  int32_T i1;
  int32_T b_kidx;
  real_T b_Mlim[24];
  real_T K_0[20];
  real_T b_Kx;
  real_T b_Kr;
  real_T aux_0;
  int32_T ibmat;
  real_T xk;
  real_T b_Sx;
  real_T xk_idx_0;
  real_T xk_idx_1;
  real_T aux3_0;
  static const real_T b_Kx_0[6] = { 0.0, -4.4507735851241836,
    0.43879533513771257, 0.0, -3.1237319787123838, 0.37477691414684089 };

  static const real_T b_Linv[9] = { 5.4775689934782914, -4.9472513817346586, 0.0,
    0.0, 7.8814590226994676, 0.0, 0.0, 0.0, 0.003162277660168379 };

  static const real_T b_Hinv[9] = { 54.479058312390272, -38.99155904013503, 0.0,
    -38.99155904013503, 62.117396326490848, 0.0, 0.0, 0.0, 9.9999999999999974E-6
  };

  static const real_T b_Ac[72] = { -0.0, -0.018323129009083641,
    -0.031713681721181636, -0.041499504974763707, -0.048650989966404795,
    -0.05387729911386939, -0.057696688700339616, -0.06048790070132009,
    -0.062527719959877978, -0.064018420990871711, 0.0, 0.018323129009083641,
    0.031713681721181636, 0.041499504974763707, 0.048650989966404795,
    0.05387729911386939, 0.057696688700339616, 0.06048790070132009,
    0.062527719959877978, 0.064018420990871711, -1.0, -1.0, 1.0, 1.0, -0.0, -0.0,
    -0.018323129009083641, -0.031713681721181636, -0.041499504974763707,
    -0.048650989966404795, -0.05387729911386939, -0.057696688700339616,
    -0.06048790070132009, -0.062527719959877978, 0.0, 0.0, 0.018323129009083641,
    0.031713681721181636, 0.041499504974763707, 0.048650989966404795,
    0.05387729911386939, 0.057696688700339616, 0.06048790070132009,
    0.062527719959877978, -0.0, -1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0,
    0.0, 0.0, 0.0 };

  static const real_T b_Mx[72] = { -0.0, -0.0, -0.0, -0.0, -0.0, -0.0, -0.0,
    -0.0, -0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 46.338838950170363, 33.86444887617521, 24.748157780135067,
    18.085967255807141, 13.217234772952983, 9.65916240876005, 7.058921176895943,
    5.1586634609684019, 3.7699540817415165, 2.7550845070578593,
    -46.338838950170363, -33.86444887617521, -24.748157780135067,
    -18.085967255807141, -13.217234772952983, -9.65916240876005,
    -7.058921176895943, -5.1586634609684019, -3.7699540817415165,
    -2.7550845070578593, 0.0, 0.0, 0.0, 0.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0,
    -1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    0.0, 0.0, 0.0, 0.0 };

  static const real_T b_Kr_0[20] = { -0.0, -0.018323129009083641,
    -0.031713681721181636, -0.041499504974763707, -0.048650989966404795,
    -0.05387729911386939, -0.057696688700339616, -0.06048790070132009,
    -0.062527719959877978, -0.064018420990871711, -0.0, -0.0,
    -0.018323129009083641, -0.031713681721181636, -0.041499504974763707,
    -0.048650989966404795, -0.05387729911386939, -0.057696688700339616,
    -0.06048790070132009, -0.062527719959877978 };

  static const int8_T b_Mlim_0[24] = { 90, 90, 90, 90, 90, 90, 90, 90, 90, 90,
    90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94, 94, 0, 0 };

  static const real_T b_Mu1[24] = { -0.0, -0.018323129009083641,
    -0.031713681721181636, -0.041499504974763707, -0.048650989966404795,
    -0.05387729911386939, -0.057696688700339616, -0.06048790070132009,
    -0.062527719959877978, -0.064018420990871711, 0.0, 0.018323129009083641,
    0.031713681721181636, 0.041499504974763707, 0.048650989966404795,
    0.05387729911386939, 0.057696688700339616, 0.06048790070132009,
    0.062527719959877978, 0.064018420990871711, -1.0, -1.0, 1.0, 1.0 };

  static const int8_T b_A[100] = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1,
    1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1 };

  static const real_T b_Sx_0[30] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, -46.338838950170363, -33.86444887617521, -24.748157780135067,
    -18.085967255807141, -13.217234772952983, -9.65916240876005,
    -7.058921176895943, -5.1586634609684019, -3.7699540817415165,
    -2.7550845070578593, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 };

  static const real_T b_Su1[10] = { 0.0, 0.018323129009083641,
    0.031713681721181636, 0.041499504974763707, 0.048650989966404795,
    0.05387729911386939, 0.057696688700339616, 0.06048790070132009,
    0.062527719959877978, 0.064018420990871711 };

  static const real_T b_H[9] = { 0.033329153770445007, 0.020920961660523298, 0.0,
    0.020920961660523298, 0.02923079554428052, 0.0, 0.0, 0.0, 100000.0 };

  static const int8_T b_Jm[20] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0 };

  static const real_T c_A[9] = { 0.0, 0.0, 0.0, -46.33883895017037,
    0.73080054751891255, 0.0, 0.0, 0.0, 1.0 };

  static const real_T b_a[3] = { 0.0, -0.00039541623019055547, 0.0 };

  static const real_T d_a[3] = { 0.000441825961528138, -6.9679487425238948E-6,
    0.048750510546431744 };

  /* :  coder.extrinsic('mpcblock_optimizer_double_mex'); */
  /* :  coder.extrinsic('mpcblock_optimizer_single_mex'); */
  /* :  coder.extrinsic('mpcblock_refmd_double_mex'); */
  /* :  coder.extrinsic('mpcblock_refmd_single_mex'); */
  /* :  isSimulation = coder.target('Sfun') && ~coder.target('RtwForRapid') && ~coder.target('RtwForSim'); */
  /* :  isAdaptive = false; */
  /* :  isLTV = false; */
  /* :  isDouble = isa(ref,'double'); */
  /* :  ZERO = zeros('like',ref); */
  /* :  ONE = ones('like',ref); */
  /* :  if isSimulation */
  /* :  else */
  /* :  [rseq, vseq, v] = mpcblock_refmd(ref,md,nv,ny,p,yoff,voff,no_md,no_ref,openloopflag, RYscale, RMDscale); */
  for (b_kidx = 0; b_kidx < 10; b_kidx++) {
    aux3[b_kidx] = rtu_ref;
  }

  /* :  old_u = old_u - uoff; */
  /* :  if no_mv==ONE */
  /* :  delmv = zeros(nu,1,'like',ref); */
  /* :  xk = xk - xoff; */
  /* :  if CustomEstimation==ONE */
  /* :  else */
  /* :  ym = ym.*RYscale(myindex) - myoff; */
  /* :  xk = xk + Bu*delmv; */
  /* :  ym_est = C(myindex,:)*xk + Dv(myindex,:)*v; */
  /* :  y_innov = ym - ym_est; */
  xk = rtu_xk[0];
  y_innov = 0.99999999999999989 * xk;
  xk_idx_0 = xk;
  xk = rtu_xk[1];
  y_innov += 0.0 * xk;
  xk_idx_1 = xk;
  xk = rtu_xk[2];
  y_innov += xk;
  y_innov = rtu_ym - y_innov;

  /* :  xest = xk + M*y_innov; */
  localB->xest[0] = 0.00060457803846511275 * y_innov + xk_idx_0;
  localB->xest[1] = -9.53467914902399E-6 * y_innov + xk_idx_1;
  localB->xest[2] = 0.048750510546431723 * y_innov + xk;

  /* :  if no_uref==ONE */
  /* :  utargetValue = utarget; */
  /* :  if no_cc~=ONE */
  /* :  return_sequence = (return_mvseq || return_xseq || return_ovseq)*ONE; */
  /* :  if isSimulation */
  /* :  else */
  /* :  [u, cost, useq, status, iAout] = mpcblock_optimizer(... */
  /* :              rseq, vseq, umin, umax, ymin, ymax, switch_in, xest, old_u, iA, ... */
  /* :              isQP, nu, ny, degrees, Hinv, Kx, Ku1, Kut, Kr, Kv, Mlim, ... */
  /* :              Mx, Mu1, Mv, z_degrees, utargetValue, p, uoff, voff, yoff, maxiter, ... */
  /* :              false, CustomSolverCodeGen, UseWarmStart, UseSuboptimalSolution, nxQP, openloopflag, ... */
  /* :              no_umin, no_umax, no_ymin, no_ymax, no_cc, switch_inport, ... */
  /* :              no_switch, enable_value, return_cost, H, return_sequence, Linv, Ac, ... */
  /* :              ywt, uwt, duwt, rhoeps, no_ywt, no_uwt, no_duwt, no_rhoeps,... */
  /* :              Wy, Wdu, Jm, SuJm, Su1, Sx, Hv, Wu, I1, ... */
  /* :              isAdaptive, isLTV, A, Bu, Bv, C, Dv, ... */
  /* :              Mrows, nCC, Ecc, Fcc, Scc, Gcc); */
  cost = 0.0;
  memset(&localB->useq[0], 0, 11U * sizeof(real_T));
  xQP[0] = 0.0;
  xQP[1] = 0.0;
  xQP[2] = 0.0;
  for (b_kidx = 0; b_kidx < 2; b_kidx++) {
    b_Kx = b_Kx_0[3 * b_kidx] * localB->xest[0];
    b_Kx += b_Kx_0[3 * b_kidx + 1] * localB->xest[1];
    b_Kx += b_Kx_0[3 * b_kidx + 2] * localB->xest[2];
    b_Kr = 0.0;
    for (ibmat = 0; ibmat < 10; ibmat++) {
      b_Kr += b_Kr_0[10 * b_kidx + ibmat] * aux3[ibmat];
    }

    xQP[b_kidx] = (-0.0024081921099217071 * (real_T)b_kidx +
                   0.023329153770445005) * rtu_old_u + (b_Kx + b_Kr);
  }

  for (b_kidx = 0; b_kidx < 24; b_kidx++) {
    iAnew[b_kidx] = rtu_iA[b_kidx];
    b_Sx = b_Mx[b_kidx] * localB->xest[0];
    b_Sx += b_Mx[b_kidx + 24] * localB->xest[1];
    b_Sx += b_Mx[b_kidx + 48] * localB->xest[2];
    b_Kx = ((real_T)b_Mlim_0[b_kidx] + b_Sx) + b_Mu1[b_kidx] * rtu_old_u;
    b_Mlim[b_kidx] = -b_Kx;
  }

  Comp_Control_qpkwik(b_Linv, b_Hinv, xQP, b_Ac, b_Mlim, iAnew, 120, 1.0E-6,
                      zopt, unusedU0, &b_Kr);
  if ((b_Kr < 0.0) || (b_Kr == 0.0)) {
    zopt[0] = 0.0;
    zopt[1] = 0.0;
    zopt[2] = 0.0;
  }

  b_Kx = rtu_old_u + zopt[0];
  if (b_Kr > 0.0) {
    aux[0] = zopt[0];
    aux[1] = zopt[1];
    aux[2] = zopt[2];
    cost = 0.0;
    for (ibmat = 0; ibmat < 10; ibmat++) {
      aux3_0 = aux3[ibmat];
      b_Sx = b_Sx_0[ibmat] * localB->xest[0];
      b_Sx += b_Sx_0[ibmat + 10] * localB->xest[1];
      b_Sx += b_Sx_0[ibmat + 20] * localB->xest[2];
      b_Sx += b_Su1[ibmat] * rtu_old_u;
      aux2[ibmat] = b_Sx - aux3_0;
      aux3_0 = rtu_old_u;
      cost += 0.0 * aux3_0 * aux3_0;
      aux3[ibmat] = aux3_0;
    }

    aux3_0 = 0.0;
    for (ibmat = 0; ibmat < 10; ibmat++) {
      b_Sx = aux2[ibmat];
      aux3_0 += b_Sx * b_Sx;
    }

    aux_0 = 0.0;
    for (ibmat = 0; ibmat < 3; ibmat++) {
      b_Sx = b_H[ibmat] * aux[0];
      b_Sx += b_H[ibmat + 3] * aux[1];
      b_Sx += b_H[ibmat + 6] * aux[2];
      b_Sx += 2.0 * xQP[ibmat];
      aux_0 += aux[ibmat] * b_Sx;
    }

    cost = (cost + aux3_0) + aux_0;
  }

  b_kidx = -1;
  for (ibmat = 0; ibmat < 10; ibmat++) {
    for (i1 = 0; i1 < 10; i1++) {
      b_kidx++;
      K[b_kidx] = b_A[10 * ibmat + i1];
    }
  }

  for (ibmat = 0; ibmat < 10; ibmat++) {
    b_Sx = 0.0;
    for (b_kidx = 0; b_kidx < 2; b_kidx++) {
      K_0[ibmat + 10 * b_kidx] = 0.0;
      for (i1 = 0; i1 < 10; i1++) {
        aux3_0 = K_0[10 * b_kidx + ibmat];
        aux3_0 += (real_T)(K[10 * i1 + ibmat] * b_Jm[10 * b_kidx + i1]);
        K_0[ibmat + 10 * b_kidx] = aux3_0;
      }

      b_Sx += K_0[10 * b_kidx + ibmat] * zopt[b_kidx];
    }

    localB->useq[ibmat] = b_Sx + rtu_old_u;
  }

  localB->useq[10] = localB->useq[9];
  localB->u = b_Kx;
  localB->cost = cost;
  localB->status = b_Kr;
  for (b_kidx = 0; b_kidx < 24; b_kidx++) {
    localB->iAout[b_kidx] = (iAnew[b_kidx] != 0);
  }

  /* :  if return_xseq || return_ovseq */
  /* :  [yseq, xseq] = mpc_computeSequence(isLTV, xest, useq, vseq, uoff, yoff, xoff, p, ny, nxQP, nv, A, Bu, Bv, C, Dv); */
  xQP[0] = localB->xest[0];
  xQP[1] = localB->xest[1];
  xQP[2] = localB->xest[2];
  memcpy(&aux3[0], &localB->useq[0], 10U * sizeof(real_T));
  memset(&localB->yseq[0], 0, 11U * sizeof(real_T));
  memset(&localB->xseq[0], 0, 33U * sizeof(real_T));
  for (b_kidx = 0; b_kidx < 11; b_kidx++) {
    b_Kr = xQP[0];
    localB->xseq[b_kidx] = b_Kr;
    cost = 0.99999999999999989 * b_Kr;
    b_Kr = xQP[1];
    localB->xseq[b_kidx + 11] = b_Kr;
    cost += 0.0 * b_Kr;
    b_Kr = xQP[2];
    localB->xseq[b_kidx + 22] = b_Kr;
    cost += b_Kr;
    localB->yseq[b_kidx] = cost;
    if (b_kidx < (int32_T)Comp_Control_p) {
      cost = aux3[b_kidx];
      for (ibmat = 0; ibmat < 3; ibmat++) {
        b_Sx = 0.0 * xQP[0];
        b_Sx += c_A[ibmat + 3] * xQP[1];
        b_Sx += c_A[ibmat + 6] * xQP[2];
        zopt[ibmat] = b_a[ibmat] * cost + b_Sx;
      }

      xQP[0] = zopt[0];
      xQP[1] = zopt[1];
      xQP[2] = zopt[2];
    }
  }

  /* :  if CustomEstimation==ONE */
  /* :  else */
  /* :  xk1 = A*xk + Bu*(u - uoff) + Bv*v + L*y_innov; */
  /* :  xk1 = xk1 + xoff; */
  /* :  xest = xest + xoff; */
  for (ibmat = 0; ibmat < 3; ibmat++) {
    b_Sx = 0.0 * xk_idx_0;
    b_Sx += c_A[ibmat + 3] * xk_idx_1;
    b_Sx += c_A[ibmat + 6] * xk;
    localB->xk1[ibmat] = (b_a[ibmat] * b_Kx + b_Sx) + d_a[ibmat] * y_innov;
  }
}

/* Function for MATLAB Function: '<S90>/optimizer' */
static void Comp_Control_Unconstrained_g(const real_T b_Hinv[9], const real_T f
  [3], real_T x[3], int16_T n)
{
  int32_T i;
  real_T b_Hinv_0;
  int32_T i_0;
  for (i = 1; i - 1 < n; i++) {
    i_0 = (int16_T)i;
    b_Hinv_0 = -b_Hinv[i_0 - 1] * f[0];
    b_Hinv_0 += -b_Hinv[i_0 + 2] * f[1];
    b_Hinv_0 += -b_Hinv[i_0 + 5] * f[2];
    x[(int16_T)i - 1] = b_Hinv_0;
  }
}

/* Function for MATLAB Function: '<S90>/optimizer' */
static real_T Comp_Control_norm_m(const real_T x[3])
{
  real_T y;
  real_T scale;
  real_T absxk;
  real_T t;
  scale = 3.3121686421112381E-170;
  absxk = fabs(x[0]);
  if (absxk > 3.3121686421112381E-170) {
    y = 1.0;
    scale = absxk;
  } else {
    t = absxk / 3.3121686421112381E-170;
    y = t * t;
  }

  absxk = fabs(x[1]);
  if (absxk > scale) {
    t = scale / absxk;
    y = y * t * t + 1.0;
    scale = absxk;
  } else {
    t = absxk / scale;
    y += t * t;
  }

  absxk = fabs(x[2]);
  if (absxk > scale) {
    t = scale / absxk;
    y = y * t * t + 1.0;
    scale = absxk;
  } else {
    t = absxk / scale;
    y += t * t;
  }

  return scale * sqrt(y);
}

/* Function for MATLAB Function: '<S90>/optimizer' */
static void Comp_Control_abs_d(const real_T x[3], real_T y[3])
{
  y[0] = fabs(x[0]);
  y[1] = fabs(x[1]);
  y[2] = fabs(x[2]);
}

/* Function for MATLAB Function: '<S90>/optimizer' */
static void Comp_Control_abs_dw(const real_T x[24], real_T y[24])
{
  int32_T k;
  for (k = 0; k < 24; k++) {
    y[k] = fabs(x[k]);
  }
}

/* Function for MATLAB Function: '<S90>/optimizer' */
static real_T Comp_Control_xnrm2_p(int32_T n, const real_T x[9], int32_T ix0)
{
  real_T y;
  real_T scale;
  int32_T kend;
  real_T absxk;
  real_T t;
  int32_T k;
  y = 0.0;
  if (n >= 1) {
    if (n == 1) {
      y = fabs(x[ix0 - 1]);
    } else {
      scale = 3.3121686421112381E-170;
      kend = (ix0 + n) - 1;
      for (k = ix0; k <= kend; k++) {
        absxk = fabs(x[k - 1]);
        if (absxk > scale) {
          t = scale / absxk;
          y = y * t * t + 1.0;
          scale = absxk;
        } else {
          t = absxk / scale;
          y += t * t;
        }
      }

      y = scale * sqrt(y);
    }
  }

  return y;
}

/* Function for MATLAB Function: '<S90>/optimizer' */
static void Comp_Control_xgemv_j(int32_T m, int32_T n, const real_T b_A[9],
  int32_T ia0, const real_T x[9], int32_T ix0, real_T y[3])
{
  int32_T ix;
  real_T c;
  int32_T b_iy;
  int32_T b;
  int32_T iac;
  int32_T d;
  int32_T ia;
  if ((m != 0) && (n != 0)) {
    for (b_iy = 0; b_iy < n; b_iy++) {
      y[b_iy] = 0.0;
    }

    b_iy = 0;
    b = (n - 1) * 3 + ia0;
    for (iac = ia0; iac <= b; iac += 3) {
      ix = ix0;
      c = 0.0;
      d = (iac + m) - 1;
      for (ia = iac; ia <= d; ia++) {
        c += b_A[ia - 1] * x[ix - 1];
        ix++;
      }

      y[b_iy] += c;
      b_iy++;
    }
  }
}

/* Function for MATLAB Function: '<S90>/optimizer' */
static void Comp_Control_xgerc_p(int32_T m, int32_T n, real_T alpha1, int32_T
  ix0, const real_T y[3], real_T b_A[9], int32_T ia0)
{
  int32_T jA;
  int32_T jy;
  real_T temp;
  int32_T ix;
  int32_T j;
  int32_T b;
  int32_T ijA;
  if (!(alpha1 == 0.0)) {
    jA = ia0 - 1;
    jy = 0;
    for (j = 0; j < n; j++) {
      if (y[jy] != 0.0) {
        temp = y[jy] * alpha1;
        ix = ix0;
        b = m + jA;
        for (ijA = jA; ijA < b; ijA++) {
          b_A[ijA] += b_A[ix - 1] * temp;
          ix++;
        }
      }

      jy++;
      jA += 3;
    }
  }
}

/* Function for MATLAB Function: '<S90>/optimizer' */
static void Comp_Control_qr_n(const real_T b_A[9], real_T Q[9], real_T R[9])
{
  real_T c_A[9];
  real_T work[3];
  real_T b;
  real_T b_atmp;
  real_T xnorm;
  int32_T knt;
  int32_T lastc;
  int32_T coltop;
  int32_T b_coltop;
  real_T tau_idx_0;
  int32_T exitg1;
  boolean_T exitg2;
  memcpy(&c_A[0], &b_A[0], 9U * sizeof(real_T));
  work[0] = 0.0;
  work[1] = 0.0;
  work[2] = 0.0;
  b_atmp = c_A[0];
  b = 0.0;
  xnorm = Comp_Control_xnrm2_p(2, c_A, 2);
  if (xnorm != 0.0) {
    xnorm = rt_hypotd_snf(c_A[0], xnorm);
    if (c_A[0] >= 0.0) {
      xnorm = -xnorm;
    }

    if (fabs(xnorm) < 1.0020841800044864E-292) {
      knt = -1;
      lastc = 0;
      do {
        knt++;
        for (coltop = 1; coltop < 3; coltop++) {
          c_A[coltop] *= 9.9792015476736E+291;
        }

        xnorm *= 9.9792015476736E+291;
        b_atmp *= 9.9792015476736E+291;
      } while (!(fabs(xnorm) >= 1.0020841800044864E-292));

      xnorm = rt_hypotd_snf(b_atmp, Comp_Control_xnrm2_p(2, c_A, 2));
      if (b_atmp >= 0.0) {
        xnorm = -xnorm;
      }

      b = (xnorm - b_atmp) / xnorm;
      b_atmp = 1.0 / (b_atmp - xnorm);
      for (coltop = 1; coltop < 3; coltop++) {
        c_A[coltop] *= b_atmp;
      }

      while (lastc <= knt) {
        xnorm *= 1.0020841800044864E-292;
        lastc++;
      }

      b_atmp = xnorm;
    } else {
      b = (xnorm - c_A[0]) / xnorm;
      b_atmp = 1.0 / (c_A[0] - xnorm);
      for (lastc = 1; lastc < 3; lastc++) {
        c_A[lastc] *= b_atmp;
      }

      b_atmp = xnorm;
    }
  }

  tau_idx_0 = b;
  c_A[0] = b_atmp;
  b_atmp = c_A[0];
  c_A[0] = 1.0;
  if (tau_idx_0 != 0.0) {
    knt = 3;
    lastc = 0;
    while ((knt > 0) && (c_A[lastc + 2] == 0.0)) {
      knt--;
      lastc--;
    }

    lastc = 2;
    exitg2 = false;
    while ((!exitg2) && (lastc > 0)) {
      coltop = (lastc - 1) * 3 + 3;
      b_coltop = coltop;
      do {
        exitg1 = 0;
        if (b_coltop + 1 <= coltop + knt) {
          if (c_A[b_coltop] != 0.0) {
            exitg1 = 1;
          } else {
            b_coltop++;
          }
        } else {
          lastc--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    Comp_Control_xgemv_j(knt, lastc, c_A, 4, c_A, 1, work);
    Comp_Control_xgerc_p(knt, lastc, -tau_idx_0, 1, work, c_A, 4);
  }

  c_A[0] = b_atmp;
  b_atmp = c_A[4];
  b = 0.0;
  xnorm = Comp_Control_xnrm2_p(1, c_A, 6);
  if (xnorm != 0.0) {
    xnorm = rt_hypotd_snf(c_A[4], xnorm);
    if (c_A[4] >= 0.0) {
      xnorm = -xnorm;
    }

    if (fabs(xnorm) < 1.0020841800044864E-292) {
      knt = -1;
      do {
        knt++;
        for (coltop = 5; coltop < 6; coltop++) {
          c_A[coltop] *= 9.9792015476736E+291;
        }

        xnorm *= 9.9792015476736E+291;
        b_atmp *= 9.9792015476736E+291;
      } while (!(fabs(xnorm) >= 1.0020841800044864E-292));

      xnorm = rt_hypotd_snf(b_atmp, Comp_Control_xnrm2_p(1, c_A, 6));
      if (b_atmp >= 0.0) {
        xnorm = -xnorm;
      }

      b = (xnorm - b_atmp) / xnorm;
      b_atmp = 1.0 / (b_atmp - xnorm);
      for (coltop = 5; coltop < 6; coltop++) {
        c_A[coltop] *= b_atmp;
      }

      for (lastc = 0; lastc <= knt; lastc++) {
        xnorm *= 1.0020841800044864E-292;
      }

      b_atmp = xnorm;
    } else {
      b = (xnorm - c_A[4]) / xnorm;
      b_atmp = 1.0 / (c_A[4] - xnorm);
      for (lastc = 5; lastc < 6; lastc++) {
        c_A[lastc] *= b_atmp;
      }

      b_atmp = xnorm;
    }
  }

  c_A[4] = b_atmp;
  b_atmp = c_A[4];
  c_A[4] = 1.0;
  if (b != 0.0) {
    knt = 2;
    lastc = 3;
    while ((knt > 0) && (c_A[lastc + 2] == 0.0)) {
      knt--;
      lastc--;
    }

    lastc = 1;
    b_coltop = 7;
    do {
      exitg1 = 0;
      if (b_coltop + 1 <= 7 + knt) {
        if (c_A[b_coltop] != 0.0) {
          exitg1 = 1;
        } else {
          b_coltop++;
        }
      } else {
        lastc = 0;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    Comp_Control_xgemv_j(knt, lastc, c_A, 8, c_A, 5, work);
    Comp_Control_xgerc_p(knt, lastc, -b, 5, work, c_A, 8);
  }

  c_A[4] = b_atmp;
  R[0] = c_A[0];
  for (lastc = 1; lastc + 1 < 4; lastc++) {
    R[lastc] = 0.0;
  }

  work[0] = 0.0;
  for (lastc = 0; lastc < 2; lastc++) {
    R[lastc + 3] = c_A[lastc + 3];
  }

  while (lastc + 1 < 4) {
    R[lastc + 3] = 0.0;
    lastc++;
  }

  work[1] = 0.0;
  for (lastc = 0; lastc < 3; lastc++) {
    R[lastc + 6] = c_A[lastc + 6];
  }

  work[2] = 0.0;
  c_A[8] = 1.0;
  for (lastc = 0; lastc < 2; lastc++) {
    c_A[7 - lastc] = 0.0;
  }

  c_A[4] = 1.0;
  if (b != 0.0) {
    coltop = 7;
    while ((lastc > 0) && (c_A[coltop - 2] == 0.0)) {
      lastc--;
      coltop--;
    }

    coltop = 1;
    knt = 8;
    do {
      exitg1 = 0;
      if (knt <= lastc + 7) {
        if (c_A[knt - 1] != 0.0) {
          exitg1 = 1;
        } else {
          knt++;
        }
      } else {
        coltop = 0;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    lastc = 0;
    coltop = 0;
  }

  if (lastc > 0) {
    Comp_Control_xgemv_j(lastc, coltop, c_A, 8, c_A, 5, work);
    Comp_Control_xgerc_p(lastc, coltop, -b, 5, work, c_A, 8);
  }

  for (coltop = 5; coltop < 6; coltop++) {
    c_A[coltop] *= -b;
  }

  c_A[4] = 1.0 - b;
  c_A[3] = 0.0;
  c_A[0] = 1.0;
  if (tau_idx_0 != 0.0) {
    lastc = 3;
    coltop = 4;
    while ((lastc > 0) && (c_A[coltop - 2] == 0.0)) {
      lastc--;
      coltop--;
    }

    coltop = 2;
    exitg2 = false;
    while ((!exitg2) && (coltop > 0)) {
      b_coltop = (coltop - 1) * 3 + 4;
      knt = b_coltop;
      do {
        exitg1 = 0;
        if (knt <= (b_coltop + lastc) - 1) {
          if (c_A[knt - 1] != 0.0) {
            exitg1 = 1;
          } else {
            knt++;
          }
        } else {
          coltop--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    lastc = 0;
    coltop = 0;
  }

  if (lastc > 0) {
    Comp_Control_xgemv_j(lastc, coltop, c_A, 4, c_A, 1, work);
    Comp_Control_xgerc_p(lastc, coltop, -tau_idx_0, 1, work, c_A, 4);
  }

  for (coltop = 1; coltop < 3; coltop++) {
    c_A[coltop] *= -tau_idx_0;
  }

  c_A[0] = 1.0 - tau_idx_0;
  for (lastc = 0; lastc < 3; lastc++) {
    Q[3 * lastc] = c_A[3 * lastc];
    Q[3 * lastc + 1] = c_A[3 * lastc + 1];
    Q[3 * lastc + 2] = c_A[3 * lastc + 2];
  }
}

/* Function for MATLAB Function: '<S90>/optimizer' */
static real_T Comp_Control_KWIKfactor_a(const real_T b_Ac[72], const int16_T iC
  [24], int16_T nA, const real_T b_Linv[9], real_T RLinv[9], real_T D[9], real_T
  b_H[9], int16_T n)
{
  real_T Status;
  real_T TL[9];
  real_T QQ[9];
  real_T RR[9];
  int32_T i;
  int16_T b_j;
  int16_T c_k;
  int32_T f_i;
  real_T b_Linv_0;
  int32_T i_0;
  int32_T f_i_0;
  int32_T exitg1;
  Status = 1.0;
  memset(&RLinv[0], 0, 9U * sizeof(real_T));
  for (i = 1; i - 1 < nA; i++) {
    f_i_0 = iC[(int16_T)i - 1];
    i_0 = (int16_T)i - 1;
    for (f_i = 0; f_i < 3; f_i++) {
      RLinv[f_i + 3 * i_0] = 0.0;
      RLinv[f_i + 3 * i_0] += b_Ac[f_i_0 - 1] * b_Linv[f_i];
      RLinv[f_i + 3 * i_0] += b_Linv[f_i + 3] * b_Ac[f_i_0 + 23];
      RLinv[f_i + 3 * i_0] += b_Linv[f_i + 6] * b_Ac[f_i_0 + 47];
    }
  }

  Comp_Control_qr_n(RLinv, QQ, RR);
  i = 1;
  do {
    exitg1 = 0;
    if (i - 1 <= nA - 1) {
      if (fabs(RR[(((int16_T)i - 1) * 3 + (int16_T)i) - 1]) < 1.0E-12) {
        Status = -2.0;
        exitg1 = 1;
      } else {
        i++;
      }
    } else {
      for (i = 1; i - 1 < n; i++) {
        for (f_i = 1; f_i - 1 < n; f_i++) {
          i_0 = (int16_T)i;
          f_i_0 = (int16_T)f_i;
          b_Linv_0 = b_Linv[(i_0 - 1) * 3] * QQ[(f_i_0 - 1) * 3];
          b_Linv_0 += b_Linv[(i_0 - 1) * 3 + 1] * QQ[(f_i_0 - 1) * 3 + 1];
          b_Linv_0 += b_Linv[(i_0 - 1) * 3 + 2] * QQ[(f_i_0 - 1) * 3 + 2];
          TL[((int16_T)i + 3 * ((int16_T)f_i - 1)) - 1] = b_Linv_0;
        }
      }

      memset(&RLinv[0], 0, 9U * sizeof(real_T));
      for (b_j = nA; b_j > 0; b_j--) {
        RLinv[(b_j + 3 * (b_j - 1)) - 1] = 1.0;
        for (c_k = b_j; c_k <= nA; c_k++) {
          RLinv[(b_j + 3 * (c_k - 1)) - 1] /= RR[((b_j - 1) * 3 + b_j) - 1];
        }

        if (b_j > 1) {
          for (i = 1; i - 1 <= b_j - 2; i++) {
            for (c_k = b_j; c_k <= nA; c_k++) {
              RLinv[((int16_T)i + 3 * (c_k - 1)) - 1] -= RR[((b_j - 1) * 3 +
                (int16_T)i) - 1] * RLinv[((c_k - 1) * 3 + b_j) - 1];
            }
          }
        }
      }

      for (i = 1; i - 1 < n; i++) {
        for (b_j = (int16_T)i; b_j <= n; b_j++) {
          b_H[((int16_T)i + 3 * (b_j - 1)) - 1] = 0.0;
          f_i = nA + 1;
          if (f_i > 32767) {
            f_i = 32767;
          }

          for (c_k = (int16_T)f_i; c_k <= n; c_k++) {
            b_H[((int16_T)i + 3 * (b_j - 1)) - 1] -= TL[((c_k - 1) * 3 +
              (int16_T)i) - 1] * TL[((c_k - 1) * 3 + b_j) - 1];
          }

          b_H[(b_j + 3 * ((int16_T)i - 1)) - 1] = b_H[((b_j - 1) * 3 + (int16_T)
            i) - 1];
        }
      }

      for (i = 1; i - 1 < nA; i++) {
        for (f_i = 1; f_i - 1 < n; f_i++) {
          D[((int16_T)f_i + 3 * ((int16_T)i - 1)) - 1] = 0.0;
          for (b_j = (int16_T)i; b_j <= nA; b_j++) {
            D[((int16_T)f_i + 3 * ((int16_T)i - 1)) - 1] += TL[((b_j - 1) * 3 +
              (int16_T)f_i) - 1] * RLinv[((b_j - 1) * 3 + (int16_T)i) - 1];
          }
        }
      }

      exitg1 = 1;
    }
  } while (exitg1 == 0);

  return Status;
}

/* Function for MATLAB Function: '<S90>/optimizer' */
static void Comp_Control_DropConstraint_p(int16_T kDrop, int16_T iA[24], int16_T
  *nA, int16_T iC[24])
{
  int16_T b;
  int16_T i;
  int32_T tmp;
  iA[iC[kDrop - 1] - 1] = 0;
  if (kDrop < *nA) {
    tmp = *nA - 1;
    if (tmp < -32768) {
      tmp = -32768;
    }

    b = (int16_T)tmp;
    for (i = kDrop; i <= b; i++) {
      iC[i - 1] = iC[i];
    }
  }

  iC[*nA - 1] = 0;
  tmp = *nA - 1;
  if (tmp < -32768) {
    tmp = -32768;
  }

  *nA = (int16_T)tmp;
}

/* Function for MATLAB Function: '<S90>/optimizer' */
static void Comp_Control_qpkwik_j(const real_T b_Linv[9], const real_T b_Hinv[9],
  const real_T f[3], const real_T b_Ac[72], const real_T b[24], int16_T iA[24],
  int16_T b_maxiter, real_T FeasTol, real_T x[3], real_T lambda[24], real_T
  *status)
{
  real_T r[3];
  real_T rMin;
  real_T RLinv[9];
  real_T D[9];
  real_T b_H[9];
  real_T U[9];
  real_T cTol[24];
  boolean_T cTolComputed;
  int16_T iC[24];
  int16_T nA;
  real_T Opt[6];
  real_T Rhs[6];
  boolean_T DualFeasible;
  boolean_T ColdReset;
  int16_T kDrop;
  real_T Xnorm0;
  real_T cMin;
  int16_T kNext;
  real_T cVal;
  real_T AcRow[3];
  real_T z[3];
  real_T t;
  int16_T iSave;
  real_T varargin_1[24];
  int32_T idx;
  uint16_T q;
  uint16_T b_x;
  int32_T i;
  int32_T i_0;
  int32_T tmp;
  int32_T tmp_0;
  int32_T exitg1;
  int32_T exitg2;
  int32_T exitg3;
  boolean_T exitg4;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  *status = 1.0;
  x[0] = 0.0;
  r[0] = 0.0;
  x[1] = 0.0;
  r[1] = 0.0;
  x[2] = 0.0;
  r[2] = 0.0;
  rMin = 0.0;
  cTolComputed = false;
  for (i = 0; i < 24; i++) {
    lambda[i] = 0.0;
    cTol[i] = 1.0;
    iC[i] = 0;
  }

  nA = 0;
  for (i = 0; i < 24; i++) {
    if (iA[i] == 1) {
      i_0 = nA + 1;
      if (i_0 > 32767) {
        i_0 = 32767;
      }

      nA = (int16_T)i_0;
      iC[nA - 1] = (int16_T)(i + 1);
    }
  }

  guard1 = false;
  if (nA > 0) {
    for (i = 0; i < 6; i++) {
      Opt[i] = 0.0;
    }

    Rhs[0] = f[0];
    Rhs[3] = 0.0;
    Rhs[1] = f[1];
    Rhs[4] = 0.0;
    Rhs[2] = f[2];
    Rhs[5] = 0.0;
    DualFeasible = false;
    i_0 = 3 * nA;
    if (i_0 > 32767) {
      i_0 = 32767;
    }

    kNext = (int16_T)i_0;
    if (kNext <= 50) {
      kNext = 50;
    }

    q = (uint16_T)(kNext / 10U);
    b_x = (uint16_T)((uint32_T)kNext - q * 10);
    if ((b_x > 0) && (b_x >= 5)) {
      q++;
    }

    ColdReset = false;
    do {
      exitg3 = 0;
      if ((!DualFeasible) && (nA > 0) && ((int32_T)*status <= b_maxiter)) {
        Xnorm0 = Comp_Control_KWIKfactor_a(b_Ac, iC, nA, b_Linv, RLinv, D, b_H,
          3);
        if (Xnorm0 < 0.0) {
          if (ColdReset) {
            *status = -2.0;
            exitg3 = 2;
          } else {
            nA = 0;
            for (i = 0; i < 24; i++) {
              iA[i] = 0;
              iC[i] = 0;
            }

            ColdReset = true;
          }
        } else {
          for (i = 1; i - 1 < nA; i++) {
            i_0 = (int16_T)i + 3;
            if (i_0 > 32767) {
              i_0 = 32767;
            }

            Rhs[i_0 - 1] = b[iC[(int16_T)i - 1] - 1];
            for (kNext = (int16_T)i; kNext <= nA; kNext++) {
              U[(kNext + 3 * ((int16_T)i - 1)) - 1] = 0.0;
              for (idx = 1; idx - 1 < nA; idx++) {
                U[(kNext + 3 * ((int16_T)i - 1)) - 1] += RLinv[(((int16_T)idx -
                  1) * 3 + kNext) - 1] * RLinv[(((int16_T)idx - 1) * 3 +
                  (int16_T)i) - 1];
              }

              U[((int16_T)i + 3 * (kNext - 1)) - 1] = U[(((int16_T)i - 1) * 3 +
                kNext) - 1];
            }
          }

          for (i = 0; i < 3; i++) {
            i_0 = i + 1;
            Xnorm0 = b_H[i_0 - 1] * Rhs[0];
            Xnorm0 += b_H[i_0 + 2] * Rhs[1];
            Xnorm0 += b_H[i_0 + 5] * Rhs[2];
            Opt[i] = Xnorm0;
            for (idx = 1; idx - 1 < nA; idx++) {
              i_0 = (int16_T)idx + 3;
              if (i_0 > 32767) {
                i_0 = 32767;
              }

              Opt[i] += D[((int16_T)idx - 1) * 3 + i] * Rhs[i_0 - 1];
            }
          }

          for (i = 1; i - 1 < nA; i++) {
            i_0 = (int16_T)i;
            Xnorm0 = D[(i_0 - 1) * 3] * Rhs[0];
            Xnorm0 += D[(i_0 - 1) * 3 + 1] * Rhs[1];
            Xnorm0 += D[(i_0 - 1) * 3 + 2] * Rhs[2];
            i_0 = (int16_T)i + 3;
            if (i_0 > 32767) {
              i_0 = 32767;
            }

            Opt[i_0 - 1] = Xnorm0;
            for (idx = 1; idx - 1 < nA; idx++) {
              i_0 = (int16_T)i + 3;
              if (i_0 > 32767) {
                i_0 = 32767;
              }

              tmp = (int16_T)i + 3;
              if (tmp > 32767) {
                tmp = 32767;
              }

              tmp_0 = (int16_T)idx + 3;
              if (tmp_0 > 32767) {
                tmp_0 = 32767;
              }

              Opt[i_0 - 1] = U[(((int16_T)idx - 1) * 3 + (int16_T)i) - 1] *
                Rhs[tmp_0 - 1] + Opt[tmp - 1];
            }
          }

          Xnorm0 = -1.0E-12;
          kDrop = 0;
          for (i = 1; i - 1 < nA; i++) {
            i_0 = (int16_T)i + 3;
            if (i_0 > 32767) {
              i_0 = 32767;
            }

            lambda[iC[(int16_T)i - 1] - 1] = Opt[i_0 - 1];
            i_0 = (int16_T)i + 3;
            if (i_0 > 32767) {
              i_0 = 32767;
            }

            if ((Opt[i_0 - 1] < Xnorm0) && ((int16_T)i <= nA)) {
              kDrop = (int16_T)i;
              i_0 = (int16_T)i + 3;
              if (i_0 > 32767) {
                i_0 = 32767;
              }

              Xnorm0 = Opt[i_0 - 1];
            }
          }

          if (kDrop <= 0) {
            DualFeasible = true;
            x[0] = Opt[0];
            x[1] = Opt[1];
            x[2] = Opt[2];
          } else {
            (*status)++;
            if ((int32_T)*status > q) {
              nA = 0;
              for (i = 0; i < 24; i++) {
                iA[i] = 0;
                iC[i] = 0;
              }

              ColdReset = true;
            } else {
              lambda[iC[kDrop - 1] - 1] = 0.0;
              Comp_Control_DropConstraint_p(kDrop, iA, &nA, iC);
            }
          }
        }
      } else {
        if (nA <= 0) {
          memset(&lambda[0], 0, 24U * sizeof(real_T));
          Comp_Control_Unconstrained_g(b_Hinv, f, x, 3);
        }

        exitg3 = 1;
      }
    } while (exitg3 == 0);

    if (exitg3 == 1) {
      guard1 = true;
    }
  } else {
    Comp_Control_Unconstrained_g(b_Hinv, f, x, 3);
    guard1 = true;
  }

  if (guard1) {
    Xnorm0 = Comp_Control_norm_m(x);
    do {
      exitg2 = 0;
      if ((int32_T)*status <= b_maxiter) {
        cMin = -FeasTol;
        kNext = 0;
        for (i = 0; i < 24; i++) {
          if (!cTolComputed) {
            i_0 = i + 1;
            z[0] = b_Ac[i_0 - 1] * x[0];
            z[1] = b_Ac[i_0 + 23] * x[1];
            z[2] = b_Ac[i_0 + 47] * x[2];
            Comp_Control_abs_d(z, AcRow);
            if (!rtIsNaN(AcRow[0])) {
              idx = 1;
            } else {
              idx = 0;
              i_0 = 2;
              exitg4 = false;
              while ((!exitg4) && (i_0 < 4)) {
                if (!rtIsNaN(AcRow[i_0 - 1])) {
                  idx = i_0;
                  exitg4 = true;
                } else {
                  i_0++;
                }
              }
            }

            if (idx == 0) {
              cVal = AcRow[0];
            } else {
              cVal = AcRow[idx - 1];
              while (idx + 1 <= 3) {
                if (cVal < AcRow[idx]) {
                  cVal = AcRow[idx];
                }

                idx++;
              }
            }

            cTol[i] = fmax(cTol[i], cVal);
          }

          if (iA[i] == 0) {
            i_0 = i + 1;
            cVal = b_Ac[i_0 - 1] * x[0];
            cVal += b_Ac[i_0 + 23] * x[1];
            cVal += b_Ac[i_0 + 47] * x[2];
            cVal = (cVal - b[i]) / cTol[i];
            if (cVal < cMin) {
              cMin = cVal;
              kNext = (int16_T)(i + 1);
            }
          }
        }

        cTolComputed = true;
        if (kNext <= 0) {
          exitg2 = 1;
        } else {
          do {
            exitg1 = 0;
            if ((kNext > 0) && ((int32_T)*status <= b_maxiter)) {
              i = kNext;
              AcRow[0] = b_Ac[i - 1];
              AcRow[1] = b_Ac[i + 23];
              AcRow[2] = b_Ac[i + 47];
              guard2 = false;
              if (nA == 0) {
                i = kNext;
                for (i_0 = 0; i_0 < 3; i_0++) {
                  cMin = b_Ac[i - 1] * b_Hinv[i_0];
                  cMin += b_Hinv[i_0 + 3] * b_Ac[i + 23];
                  cMin += b_Hinv[i_0 + 6] * b_Ac[i + 47];
                  z[i_0] = cMin;
                }

                guard2 = true;
              } else {
                cMin = Comp_Control_KWIKfactor_a(b_Ac, iC, nA, b_Linv, RLinv, D,
                  b_H, 3);
                if (cMin <= 0.0) {
                  *status = -2.0;
                  exitg1 = 1;
                } else {
                  for (i_0 = 0; i_0 < 9; i_0++) {
                    U[i_0] = -b_H[i_0];
                  }

                  for (i_0 = 0; i_0 < 3; i_0++) {
                    cMin = U[i_0] * AcRow[0];
                    cMin += U[i_0 + 3] * AcRow[1];
                    cMin += U[i_0 + 6] * AcRow[2];
                    z[i_0] = cMin;
                  }

                  for (i = 1; i - 1 < nA; i++) {
                    i_0 = (int16_T)i;
                    t = D[(i_0 - 1) * 3] * AcRow[0];
                    t += D[(i_0 - 1) * 3 + 1] * AcRow[1];
                    t += D[(i_0 - 1) * 3 + 2] * AcRow[2];
                    r[(int16_T)i - 1] = t;
                  }

                  guard2 = true;
                }
              }

              if (guard2) {
                kDrop = 0;
                cMin = 0.0;
                DualFeasible = true;
                ColdReset = true;
                if (nA > 0) {
                  i = 0;
                  exitg4 = false;
                  while ((!exitg4) && (i <= nA - 1)) {
                    if (r[i] >= 1.0E-12) {
                      ColdReset = false;
                      exitg4 = true;
                    } else {
                      i++;
                    }
                  }
                }

                ColdReset = ((nA == 0) || ColdReset);
                if (!ColdReset) {
                  for (i = 1; i - 1 < nA; i++) {
                    if (r[(int16_T)i - 1] > 1.0E-12) {
                      cVal = lambda[iC[(int16_T)i - 1] - 1] / r[(int16_T)i - 1];
                      if ((kDrop == 0) || (cVal < rMin)) {
                        rMin = cVal;
                        kDrop = (int16_T)i;
                      }
                    }
                  }

                  if (kDrop > 0) {
                    cMin = rMin;
                    DualFeasible = false;
                  }
                }

                cVal = z[0] * AcRow[0];
                cVal += z[1] * AcRow[1];
                cVal += z[2] * AcRow[2];
                if (cVal <= 0.0) {
                  cVal = 0.0;
                  ColdReset = true;
                } else {
                  t = AcRow[0] * x[0];
                  t += AcRow[1] * x[1];
                  t += AcRow[2] * x[2];
                  cVal = (b[kNext - 1] - t) / cVal;
                  ColdReset = false;
                }

                if (DualFeasible && ColdReset) {
                  *status = -1.0;
                  exitg1 = 1;
                } else {
                  if (ColdReset) {
                    t = cMin;
                  } else if (DualFeasible) {
                    t = cVal;
                  } else {
                    t = fmin(cMin, cVal);
                  }

                  for (i = 1; i - 1 < nA; i++) {
                    lambda[iC[(int16_T)i - 1] - 1] -= r[(int16_T)i - 1] * t;
                    if ((iC[(int16_T)i - 1] <= 24) && (lambda[iC[(int16_T)i - 1]
                         - 1] < 0.0)) {
                      lambda[iC[(int16_T)i - 1] - 1] = 0.0;
                    }
                  }

                  lambda[kNext - 1] += t;
                  if (t == cMin) {
                    Comp_Control_DropConstraint_p(kDrop, iA, &nA, iC);
                  }

                  if (!ColdReset) {
                    cMin = x[0];
                    cMin += t * z[0];
                    x[0] = cMin;
                    cMin = x[1];
                    cMin += t * z[1];
                    x[1] = cMin;
                    cMin = x[2];
                    cMin += t * z[2];
                    x[2] = cMin;
                    if (t == cVal) {
                      if (nA == 3) {
                        *status = -1.0;
                        exitg1 = 1;
                      } else {
                        i_0 = nA + 1;
                        if (i_0 > 32767) {
                          i_0 = 32767;
                        }

                        nA = (int16_T)i_0;
                        iC[nA - 1] = kNext;
                        kDrop = nA;
                        while ((kDrop > 1) && (iC[kDrop - 1] <= iC[kDrop - 2]))
                        {
                          iSave = iC[kDrop - 1];
                          iC[kDrop - 1] = iC[kDrop - 2];
                          iC[kDrop - 2] = iSave;
                          kDrop--;
                        }

                        iA[kNext - 1] = 1;
                        kNext = 0;
                        (*status)++;
                      }
                    } else {
                      (*status)++;
                    }
                  } else {
                    (*status)++;
                  }
                }
              }
            } else {
              cMin = Comp_Control_norm_m(x);
              if (fabs(cMin - Xnorm0) > 0.001) {
                Xnorm0 = cMin;
                Comp_Control_abs_dw(b, varargin_1);
                for (i = 0; i < 24; i++) {
                  cTol[i] = fmax(varargin_1[i], 1.0);
                }

                cTolComputed = false;
              }

              exitg1 = 2;
            }
          } while (exitg1 == 0);

          if (exitg1 == 1) {
            exitg2 = 1;
          }
        }
      } else {
        *status = 0.0;
        exitg2 = 1;
      }
    } while (exitg2 == 0);
  }
}

/*
 * Output and update for atomic system:
 *    '<S90>/optimizer'
 *    '<S187>/optimizer'
 */
void Comp_Control_optimizer_c(const real_T rtu_xk[5], real_T rtu_old_u, real_T
  rtu_ym, real_T rtu_ref, const real_T rtu_md[2], const boolean_T rtu_iA[24],
  B_optimizer_Comp_Control_a_T *localB)
{
  real_T xk[5];
  real_T y_innov;
  real_T rseq[10];
  real_T vseq[33];
  int32_T i;
  real_T f[3];
  real_T zopt[3];
  real_T unusedU0[24];
  int16_T iAnew[24];
  real_T b_Mlim[24];
  real_T b_Kx;
  real_T b_Kr;
  int32_T i_0;
  real_T xk_0;
  real_T v_idx_0;
  real_T v_idx_1;
  real_T v_idx_2;
  static const real_T b_a[5] = { 0.99999999999999989, 0.0, 0.0, 0.0, 1.0 };

  static const real_T a[5] = { 0.0034510115873759568, -1.4009380788911835E-5,
    -1.0131225650957897E-5, 9.4252874855921419E-7, 0.048679299725026673 };

  static const real_T b_Kx_0[10] = { 0.0, -29.177746679160023,
    44.164059329457515, -35.21271518885527, 0.65815460194207853, 0.0,
    -25.562116433963872, 39.202914860583689, -38.705985914613066,
    0.58782609502488825 };

  static const real_T b_Linv[9] = { 4.1255780767675327, -5.320947651988047, 0.0,
    0.0, 7.0356247114414536, 0.0, 0.0, 0.0, 0.003162277660168379 };

  static const real_T b_Hinv[9] = { 45.332878382702006, -37.43619078861348, 0.0,
    -37.43619078861348, 49.500015080245639, 0.0, 0.0, 0.0, 9.9999999999999974E-6
  };

  static const real_T b_Ac[72] = { -0.0, -0.0545654830511796,
    -0.0795907075229953, -0.08482280849415369, -0.081147681232561664,
    -0.075778248901605033, -0.071917007938315874, -0.070138403311193184,
    -0.069865754572883951, -0.070328506917190212, 0.0, 0.0545654830511796,
    0.0795907075229953, 0.08482280849415369, 0.081147681232561664,
    0.075778248901605033, 0.071917007938315874, 0.070138403311193184,
    0.069865754572883951, 0.070328506917190212, -1.0, -1.0, 1.0, 1.0, -0.0, -0.0,
    -0.0545654830511796, -0.0795907075229953, -0.08482280849415369,
    -0.081147681232561664, -0.075778248901605033, -0.071917007938315874,
    -0.070138403311193184, -0.069865754572883951, 0.0, 0.0, 0.0545654830511796,
    0.0795907075229953, 0.08482280849415369, 0.081147681232561664,
    0.075778248901605033, 0.071917007938315874, 0.070138403311193184,
    0.069865754572883951, -0.0, -1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0,
    0.0, 0.0, 0.0 };

  static const real_T b_Kr_0[20] = { -0.0, -0.0545654830511796,
    -0.0795907075229953, -0.08482280849415369, -0.081147681232561664,
    -0.075778248901605033, -0.071917007938315874, -0.070138403311193184,
    -0.069865754572883951, -0.070328506917190212, -0.0, -0.0,
    -0.0545654830511796, -0.0795907075229953, -0.08482280849415369,
    -0.081147681232561664, -0.075778248901605033, -0.071917007938315874,
    -0.070138403311193184, -0.069865754572883951 };

  static const int8_T b_Mlim_0[24] = { 90, 90, 90, 90, 90, 90, 90, 90, 90, 90,
    90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94, 94, 0, 0 };

  static const real_T b_Mu1[24] = { -0.0, -0.0545654830511796,
    -0.0795907075229953, -0.08482280849415369, -0.081147681232561664,
    -0.075778248901605033, -0.071917007938315874, -0.070138403311193184,
    -0.069865754572883951, -0.070328506917190212, 0.0, 0.0545654830511796,
    0.0795907075229953, 0.08482280849415369, 0.081147681232561664,
    0.075778248901605033, 0.071917007938315874, 0.070138403311193184,
    0.069865754572883951, 0.070328506917190212, -1.0, -1.0, 1.0, 1.0 };

  static const real_T b_Mx[120] = { -0.0, -0.0, -0.0, -0.0, -0.0, -0.0, -0.0,
    -0.0, -0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 100.39598901659738, 56.867838856975688, 38.566385159743987,
    35.9238228849646, 39.667832092501705, 44.105282842284794, 46.950658807513449,
    47.988254469043433, 47.820273559768182, 47.114557912554588,
    -100.39598901659738, -56.867838856975688, -38.566385159743987,
    -35.9238228849646, -39.667832092501705, -44.105282842284794,
    -46.950658807513449, -47.988254469043433, -47.820273559768182,
    -47.114557912554588, 0.0, 0.0, 0.0, 0.0, 5.65614143298188,
    -61.241423716208274, -84.761569343002549, -83.799470259514763,
    -74.258887209036786, -65.019722976594423, -59.133538344392051,
    -56.432957882346848, -55.666953182878352, -55.667271866932573,
    -5.65614143298188, 61.241423716208274, 84.761569343002549,
    83.799470259514763, 74.258887209036786, 65.019722976594423,
    59.133538344392051, 56.432957882346848, 55.666953182878352,
    55.667271866932573, 0.0, 0.0, 0.0, 0.0, -7.4903690759823016,
    -42.16248719802622, -8.4600853462338961, 36.667973394498446,
    68.6629878772011, 83.702341541799939, 86.780197763753421, 84.15944182405886,
    80.208293930530431, 76.983608117398788, 7.4903690759823016,
    42.16248719802622, 8.4600853462338961, -36.667973394498446,
    -68.6629878772011, -83.702341541799939, -86.780197763753421,
    -84.15944182405886, -80.208293930530431, -76.983608117398788, 0.0, 0.0, 0.0,
    0.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0 };

  static const real_T d_a[5] = { 0.0, -0.00051993101982499934,
    -0.00019191037104900985, 0.00017102253324726338, 0.0 };

  static const real_T c_a[25] = { 0.0, 0.0, 0.0, 0.0, 0.0, -100.3959890165974,
    0.58501173552845009, -0.16970355584202548, 0.12083858552430925, 0.0,
    -5.6561414329818813, -0.63657691046948539, 0.683080827366204,
    0.1595725073238935, 0.0, 7.4903690759823025, -0.33066698268625933,
    -0.65327569972915878, 0.70354726586229088, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0 };

  static const real_T e_a[5] = { 0.0014708491731755546, -2.058010982224954E-6,
    -5.1587353925967659E-6, -2.646425313945764E-6, 0.0486792997250266 };

  /* :  coder.extrinsic('mpcblock_optimizer_double_mex'); */
  /* :  coder.extrinsic('mpcblock_optimizer_single_mex'); */
  /* :  coder.extrinsic('mpcblock_refmd_double_mex'); */
  /* :  coder.extrinsic('mpcblock_refmd_single_mex'); */
  /* :  isSimulation = coder.target('Sfun') && ~coder.target('RtwForRapid') && ~coder.target('RtwForSim'); */
  /* :  isAdaptive = false; */
  /* :  isLTV = false; */
  /* :  isDouble = isa(ref,'double'); */
  /* :  ZERO = zeros('like',ref); */
  /* :  ONE = ones('like',ref); */
  /* :  if isSimulation */
  /* :  else */
  /* :  [rseq, vseq, v] = mpcblock_refmd(ref,md,nv,ny,p,yoff,voff,no_md,no_ref,openloopflag, RYscale, RMDscale); */
  memset(&vseq[0], 0, 33U * sizeof(real_T));
  for (i = 0; i < 11; i++) {
    vseq[(i * (int32_T)Comp_Control_nv_a + (int32_T)Comp_Control_nv_a) - 1] =
      1.0;
  }

  for (i = 0; i < 10; i++) {
    rseq[i] = rtu_ref;
  }

  for (i = 0; i < 11; i++) {
    vseq[i * (int32_T)Comp_Control_nv_a] = rtu_md[0] - 36.0;
    vseq[i * (int32_T)Comp_Control_nv_a + 1] = rtu_md[1] - 39.0;
  }

  v_idx_0 = vseq[0];
  v_idx_1 = vseq[1];
  v_idx_2 = vseq[2];

  /* :  old_u = old_u - uoff; */
  /* :  if no_mv==ONE */
  /* :  delmv = zeros(nu,1,'like',ref); */
  /* :  xk = xk - xoff; */
  /* :  if CustomEstimation==ONE */
  /* :  else */
  /* :  ym = ym.*RYscale(myindex) - myoff; */
  /* :  xk = xk + Bu*delmv; */
  /* :  ym_est = C(myindex,:)*xk + Dv(myindex,:)*v; */
  /* :  y_innov = ym - ym_est; */
  y_innov = 0.0;
  for (i = 0; i < 5; i++) {
    xk_0 = rtu_xk[i];
    y_innov += b_a[i] * xk_0;
    xk[i] = xk_0;
  }

  xk_0 = 0.0 * v_idx_0;
  xk_0 += 0.0 * v_idx_1;
  xk_0 += 0.0 * v_idx_2;
  y_innov = rtu_ym - (y_innov + xk_0);

  /* :  xest = xk + M*y_innov; */
  for (i = 0; i < 5; i++) {
    localB->xest[i] = a[i] * y_innov + xk[i];
  }

  /* :  if no_uref==ONE */
  /* :  utargetValue = utarget; */
  /* :  if no_cc~=ONE */
  /* :  return_sequence = (return_mvseq || return_xseq || return_ovseq)*ONE; */
  /* :  if isSimulation */
  /* :  else */
  /* :  [u, cost, useq, status, iAout] = mpcblock_optimizer(... */
  /* :              rseq, vseq, umin, umax, ymin, ymax, switch_in, xest, old_u, iA, ... */
  /* :              isQP, nu, ny, degrees, Hinv, Kx, Ku1, Kut, Kr, Kv, Mlim, ... */
  /* :              Mx, Mu1, Mv, z_degrees, utargetValue, p, uoff, voff, yoff, maxiter, ... */
  /* :              false, CustomSolverCodeGen, UseWarmStart, UseSuboptimalSolution, nxQP, openloopflag, ... */
  /* :              no_umin, no_umax, no_ymin, no_ymax, no_cc, switch_inport, ... */
  /* :              no_switch, enable_value, return_cost, H, return_sequence, Linv, Ac, ... */
  /* :              ywt, uwt, duwt, rhoeps, no_ywt, no_uwt, no_duwt, no_rhoeps,... */
  /* :              Wy, Wdu, Jm, SuJm, Su1, Sx, Hv, Wu, I1, ... */
  /* :              isAdaptive, isLTV, A, Bu, Bv, C, Dv, ... */
  /* :              Mrows, nCC, Ecc, Fcc, Scc, Gcc); */
  f[0] = 0.0;
  f[1] = 0.0;
  f[2] = 0.0;
  for (i = 0; i < 2; i++) {
    b_Kx = 0.0;
    for (i_0 = 0; i_0 < 5; i_0++) {
      b_Kx += b_Kx_0[5 * i + i_0] * localB->xest[i_0];
    }

    b_Kr = 0.0;
    for (i_0 = 0; i_0 < 10; i_0++) {
      b_Kr += b_Kr_0[10 * i + i_0] * rseq[i_0];
    }

    xk_0 = 0.0;
    for (i_0 = 0; i_0 < 33; i_0++) {
      xk_0 += 0.0 * vseq[i_0];
    }

    f[i] = ((-0.0043189130117277444 * (real_T)i + 0.048753044878553572) *
            rtu_old_u + (b_Kx + b_Kr)) + xk_0;
  }

  for (i = 0; i < 24; i++) {
    iAnew[i] = rtu_iA[i];
    xk_0 = 0.0;
    for (i_0 = 0; i_0 < 5; i_0++) {
      xk_0 += b_Mx[24 * i_0 + i] * localB->xest[i_0];
    }

    b_Kx = ((real_T)b_Mlim_0[i] + xk_0) + b_Mu1[i] * rtu_old_u;
    unusedU0[i] = 0.0;
    for (i_0 = 0; i_0 < 33; i_0++) {
      xk_0 = unusedU0[i];
      xk_0 += -0.0 * vseq[i_0];
      unusedU0[i] = xk_0;
    }

    b_Mlim[i] = -(b_Kx + unusedU0[i]);
  }

  Comp_Control_qpkwik_j(b_Linv, b_Hinv, f, b_Ac, b_Mlim, iAnew, 120, 1.0E-6,
                        zopt, unusedU0, &xk_0);
  if ((xk_0 < 0.0) || (xk_0 == 0.0)) {
    zopt[0] = 0.0;
  }

  b_Kx = rtu_old_u + zopt[0];
  localB->u = b_Kx;
  localB->cost = 0.0;
  memset(&localB->useq[0], 0, 11U * sizeof(real_T));
  localB->status = xk_0;
  for (i = 0; i < 24; i++) {
    localB->iAout[i] = (iAnew[i] != 0);
  }

  /* :  if return_xseq || return_ovseq */
  /* :  else */
  /* :  yseq = zeros(p+1,ny,'like',rseq); */
  memset(&localB->yseq[0], 0, 11U * sizeof(real_T));

  /* :  xseq = zeros(p+1,nxQP,'like',rseq); */
  memset(&localB->xseq[0], 0, 55U * sizeof(real_T));

  /* :  if CustomEstimation==ONE */
  /* :  else */
  /* :  xk1 = A*xk + Bu*(u - uoff) + Bv*v + L*y_innov; */
  /* :  xk1 = xk1 + xoff; */
  /* :  xest = xest + xoff; */
  for (i_0 = 0; i_0 < 5; i_0++) {
    xk_0 = 0.0;
    for (i = 0; i < 5; i++) {
      xk_0 += c_a[5 * i + i_0] * xk[i];
    }

    b_Kr = d_a[i_0] * b_Kx + xk_0;
    xk_0 = 0.0 * v_idx_0;
    xk_0 += 0.0 * v_idx_1;
    xk_0 += 0.0 * v_idx_2;
    localB->xk1[i_0] = (b_Kr + xk_0) + e_a[i_0] * y_innov;
  }
}

/* SetupRuntimeResources for function-call system: '<S2>/Heating_DHW_Ctrl' */
void Comp__Heating_DHW_Ctrl_SetupRTR(RT_MODEL_Comp_Control_T * const
  Comp_Control_M, DW_Heating_DHW_Ctrl_Comp_Cont_T *localDW)
{
  /* SetupRuntimeResources for ToWorkspace: '<S9>/To Workspace' */
  {
    static int_T rt_ToWksWidths[] = { 4 };

    static int_T rt_ToWksNumDimensions[] = { 1 };

    static int_T rt_ToWksDimensions[] = { 4 };

    static boolean_T rt_ToWksIsVarDims[] = { 0 };

    static void *rt_ToWksCurrSigDims[] = { (NULL) };

    static int_T rt_ToWksCurrSigDimsSize[] = { 4 };

    static BuiltInDTypeId rt_ToWksDataTypeIds[] = { SS_DOUBLE };

    static int_T rt_ToWksComplexSignals[] = { 0 };

    static int_T rt_ToWksFrameData[] = { 0 };

    static RTWPreprocessingFcnPtr rt_ToWksLoggingPreprocessingFcnPtrs[] = {
      (NULL)
    };

    static const char_T *rt_ToWksLabels[] = { "" };

    static RTWLogSignalInfo rt_ToWksSignalInfo = {
      1,
      rt_ToWksWidths,
      rt_ToWksNumDimensions,
      rt_ToWksDimensions,
      rt_ToWksIsVarDims,
      rt_ToWksCurrSigDims,
      rt_ToWksCurrSigDimsSize,
      rt_ToWksDataTypeIds,
      rt_ToWksComplexSignals,
      rt_ToWksFrameData,
      rt_ToWksLoggingPreprocessingFcnPtrs,

      { rt_ToWksLabels },
      (NULL),
      (NULL),
      (NULL),

      { (NULL) },

      { (NULL) },
      (NULL),
      (NULL)
    };

    static const char_T rt_ToWksBlockName[] =
      "Comp_Control/Comp_Control/CTRL_Compressor/Heating_DHW_Ctrl/To Workspace";
    localDW->ToWorkspace_PWORK.LoggedData = rt_CreateStructLogVar(
      Comp_Control_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(Comp_Control_M),
      Comp_Control_M->Timing.stepSize0,
      (&rtmGetErrorStatus(Comp_Control_M)),
      "simout_DHW",
      1,
      0,
      1,
      -1.0,
      &rt_ToWksSignalInfo,
      rt_ToWksBlockName);
    if (localDW->ToWorkspace_PWORK.LoggedData == (NULL))
      return;
  }

  /* SetupRuntimeResources for ToWorkspace: '<S9>/To Workspace1' */
  {
    static int_T rt_ToWksWidths[] = { 1 };

    static int_T rt_ToWksNumDimensions[] = { 1 };

    static int_T rt_ToWksDimensions[] = { 1 };

    static boolean_T rt_ToWksIsVarDims[] = { 0 };

    static void *rt_ToWksCurrSigDims[] = { (NULL) };

    static int_T rt_ToWksCurrSigDimsSize[] = { 4 };

    static BuiltInDTypeId rt_ToWksDataTypeIds[] = { SS_DOUBLE };

    static int_T rt_ToWksComplexSignals[] = { 0 };

    static int_T rt_ToWksFrameData[] = { 0 };

    static RTWPreprocessingFcnPtr rt_ToWksLoggingPreprocessingFcnPtrs[] = {
      (NULL)
    };

    static const char_T *rt_ToWksLabels[] = { "u" };

    static RTWLogSignalInfo rt_ToWksSignalInfo = {
      1,
      rt_ToWksWidths,
      rt_ToWksNumDimensions,
      rt_ToWksDimensions,
      rt_ToWksIsVarDims,
      rt_ToWksCurrSigDims,
      rt_ToWksCurrSigDimsSize,
      rt_ToWksDataTypeIds,
      rt_ToWksComplexSignals,
      rt_ToWksFrameData,
      rt_ToWksLoggingPreprocessingFcnPtrs,

      { rt_ToWksLabels },
      (NULL),
      (NULL),
      (NULL),

      { (NULL) },

      { (NULL) },
      (NULL),
      (NULL)
    };

    static const char_T rt_ToWksBlockName[] =
      "Comp_Control/Comp_Control/CTRL_Compressor/Heating_DHW_Ctrl/To Workspace1";
    localDW->ToWorkspace1_PWORK.LoggedData = rt_CreateStructLogVar(
      Comp_Control_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(Comp_Control_M),
      Comp_Control_M->Timing.stepSize0,
      (&rtmGetErrorStatus(Comp_Control_M)),
      "compfreq_DHW",
      1,
      0,
      1,
      -1.0,
      &rt_ToWksSignalInfo,
      rt_ToWksBlockName);
    if (localDW->ToWorkspace1_PWORK.LoggedData == (NULL))
      return;
  }

  /* SetupRuntimeResources for ToWorkspace: '<S45>/To Workspace' */
  {
    int_T dimensions[1] = { 1 };

    localDW->ToWorkspace_PWORK_e.LoggedData = rt_CreateLogVar(
      Comp_Control_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(Comp_Control_M),
      Comp_Control_M->Timing.stepSize0,
      (&rtmGetErrorStatus(Comp_Control_M)),
      "u_DHW",
      SS_DOUBLE,
      0,
      0,
      0,
      1,
      1,
      dimensions,
      NO_LOGVALDIMS,
      (NULL),
      (NULL),
      0,
      1,
      -1.0,
      1);
    if (localDW->ToWorkspace_PWORK_e.LoggedData == (NULL))
      return;
  }
}

/* System initialize for function-call system: '<S2>/Heating_DHW_Ctrl' */
void Comp_Cont_Heating_DHW_Ctrl_Init(DW_Heating_DHW_Ctrl_Comp_Cont_T *localDW)
{
  int32_T i;

  /* InitializeConditions for DiscreteStateSpace: '<S46>/Discrete State-Space' */
  localDW->DiscreteStateSpace_DSTATE = 0.0;

  /* InitializeConditions for DiscreteStateSpace: '<S47>/Discrete State-Space' */
  localDW->DiscreteStateSpace_DSTATE_b = 0.0;

  /* InitializeConditions for Memory: '<S48>/last_x' */
  localDW->last_x_PreviousInput[0] = 0.0;
  localDW->last_x_PreviousInput[1] = 0.0;
  localDW->last_x_PreviousInput[2] = 0.0;

  /* InitializeConditions for UnitDelay: '<S48>/last_mv' */
  localDW->last_mv_DSTATE = 0.0;

  /* InitializeConditions for Delay: '<S9>/Delay' */
  localDW->Delay_DSTATE = 0.0;

  /* InitializeConditions for Memory: '<S48>/Memory' */
  for (i = 0; i < 24; i++) {
    localDW->Memory_PreviousInput[i] = false;
  }

  /* End of InitializeConditions for Memory: '<S48>/Memory' */

  /* InitializeConditions for Memory: '<S70>/last_x' */
  for (i = 0; i < 5; i++) {
    localDW->last_x_PreviousInput_e[i] = 0.0;
  }

  /* End of InitializeConditions for Memory: '<S70>/last_x' */

  /* InitializeConditions for UnitDelay: '<S70>/last_mv' */
  localDW->last_mv_DSTATE_f = 0.0;

  /* InitializeConditions for Delay: '<S9>/Delay2' */
  localDW->Delay2_DSTATE = 0.0;

  /* InitializeConditions for Memory: '<S70>/Memory' */
  for (i = 0; i < 24; i++) {
    localDW->Memory_PreviousInput_d[i] = false;
  }

  /* End of InitializeConditions for Memory: '<S70>/Memory' */

  /* InitializeConditions for Delay: '<S9>/Delay1' */
  localDW->Delay1_DSTATE = 0.0;

  /* InitializeConditions for DiscreteIntegrator: '<S45>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_DSTATE = 0.0;
  localDW->DiscreteTimeIntegrator1_PREV_U = 0.0;

  /* InitializeConditions for UnitDelay: '<S92>/UD' */
  localDW->UD_DSTATE = 0.0;
}

/* Enable for function-call system: '<S2>/Heating_DHW_Ctrl' */
void Comp_Co_Heating_DHW_Ctrl_Enable(DW_Heating_DHW_Ctrl_Comp_Cont_T *localDW)
{
  localDW->Heating_DHW_Ctrl_RESET_ELAPS_T = true;

  /* Enable for DiscreteIntegrator: '<S45>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_SYSTEM_ = 1U;
}

/* Output and update for function-call system: '<S2>/Heating_DHW_Ctrl' */
void Comp_Control_Heating_DHW_Ctrl(RT_MODEL_Comp_Control_T * const
  Comp_Control_M, real_T rtu_yref, real_T rtu_WT_WEx_Out, const real_T
  rtu_Temp_Vect[2], real_T rtu_WT_WEx_In, real_T *rty_Comp_Freq,
  B_Heating_DHW_Ctrl_Comp_Contr_T *localB, DW_Heating_DHW_Ctrl_Comp_Cont_T
  *localDW)
{
  real_T elapseTime;
  int32_T i;
  uint32_T prevT_idx_0;
  uint32_T elapseTime_idx_0;
  uint32_T prevT_idx_1;
  if (localDW->Heating_DHW_Ctrl_RESET_ELAPS_T) {
    localDW->Heating_DHW_Ctrl_ELAPS_T[0] = 0U;
    localDW->Heating_DHW_Ctrl_ELAPS_T[1] = 0U;
  } else {
    prevT_idx_0 = localDW->Heating_DHW_Ctrl_PREV_T[0];
    prevT_idx_1 = localDW->Heating_DHW_Ctrl_PREV_T[1];
    elapseTime_idx_0 = Comp_Control_M->Timing.clockTick0 - prevT_idx_0;
    prevT_idx_1 = Comp_Control_M->Timing.clockTickH0 - prevT_idx_1;
    if (prevT_idx_0 > Comp_Control_M->Timing.clockTick0) {
      prevT_idx_1--;
    }

    localDW->Heating_DHW_Ctrl_ELAPS_T[0] = elapseTime_idx_0;
    localDW->Heating_DHW_Ctrl_ELAPS_T[1] = prevT_idx_1;
  }

  prevT_idx_0 = Comp_Control_M->Timing.clockTick0;
  prevT_idx_1 = Comp_Control_M->Timing.clockTickH0;
  localDW->Heating_DHW_Ctrl_PREV_T[0] = prevT_idx_0;
  localDW->Heating_DHW_Ctrl_PREV_T[1] = prevT_idx_1;
  localDW->Heating_DHW_Ctrl_RESET_ELAPS_T = false;

  /* DiscreteStateSpace: '<S46>/Discrete State-Space' */
  {
    localB->y = (-46.338838950170377)*localDW->DiscreteStateSpace_DSTATE;
  }

  /* Sum: '<S9>/Add4' */
  localB->y_siso = localB->y + rtu_WT_WEx_In;

  /* DiscreteStateSpace: '<S47>/Discrete State-Space' */
  {
    localB->y_i = (-46.338838950170377)*localDW->DiscreteStateSpace_DSTATE_b;
  }

  /* Sum: '<S9>/Add3' */
  localB->y_pid = rtu_WT_WEx_In + localB->y_i;

  /* SignalConversion generated from: '<S9>/To Workspace' */
  localB->TmpSignalConversionAtToWorkspac[0] = rtu_WT_WEx_Out;
  localB->TmpSignalConversionAtToWorkspac[1] = localB->y_siso;
  localB->TmpSignalConversionAtToWorkspac[2] = localB->y_pid;
  localB->TmpSignalConversionAtToWorkspac[3] = rtu_yref;

  /* Memory: '<S48>/last_x' */
  localB->last_x[0] = localDW->last_x_PreviousInput[0];
  localB->last_x[1] = localDW->last_x_PreviousInput[1];
  localB->last_x[2] = localDW->last_x_PreviousInput[2];

  /* UnitDelay: '<S48>/last_mv' */
  localB->last_mv = localDW->last_mv_DSTATE;

  /* Delay: '<S9>/Delay' */
  localB->Delay = localDW->Delay_DSTATE;

  /* Sum: '<S9>/Add2' */
  localB->yref = rtu_yref - rtu_WT_WEx_In;

  /* Memory: '<S48>/Memory' */
  for (i = 0; i < 24; i++) {
    localB->Memory[i] = localDW->Memory_PreviousInput[i];
  }

  /* End of Memory: '<S48>/Memory' */

  /* MATLAB Function: '<S68>/optimizer' */
  Comp_Control_optimizer(localB->last_x, localB->last_mv, localB->Delay,
    localB->yref, localB->Memory, &localB->sf_optimizer);

  /* ToWorkspace: '<S9>/To Workspace' */
  {
    double locTime = Comp_Control_M->Timing.taskTime0;
    ;
    rt_UpdateStructLogVar((StructLogVar *)localDW->ToWorkspace_PWORK.LoggedData,
                          &locTime, &localB->TmpSignalConversionAtToWorkspac[0]);
  }

  /* Memory: '<S70>/last_x' */
  for (i = 0; i < 5; i++) {
    localB->last_x_o[i] = localDW->last_x_PreviousInput_e[i];
  }

  /* End of Memory: '<S70>/last_x' */

  /* UnitDelay: '<S70>/last_mv' */
  localB->last_mv_i = localDW->last_mv_DSTATE_f;

  /* Delay: '<S9>/Delay2' */
  localB->WT_WEx_Out = localDW->Delay2_DSTATE;

  /* Memory: '<S70>/Memory' */
  for (i = 0; i < 24; i++) {
    localB->Memory_m[i] = localDW->Memory_PreviousInput_d[i];
  }

  /* End of Memory: '<S70>/Memory' */

  /* MATLAB Function: '<S90>/optimizer' */
  Comp_Control_optimizer_c(localB->last_x_o, localB->last_mv_i,
    localB->WT_WEx_Out, rtu_yref, rtu_Temp_Vect, localB->Memory_m,
    &localB->sf_optimizer_c);

  /* ToWorkspace: '<S9>/To Workspace1' */
  {
    double locTime = Comp_Control_M->Timing.taskTime0;
    ;
    rt_UpdateStructLogVar((StructLogVar *)localDW->ToWorkspace1_PWORK.LoggedData,
                          &locTime, &localB->sf_optimizer_c.u);
  }

  /* Delay: '<S9>/Delay1' */
  localB->Delay1 = localDW->Delay1_DSTATE;

  /* SignalConversion generated from: '<S9>/Comp_Freq' */
  *rty_Comp_Freq = localB->sf_optimizer_c.u;

  /* RelationalOperator: '<S94>/LowerRelop1' incorporates:
   *  Constant: '<S45>/Constant2'
   */
  localB->LowerRelop1 = (localB->Delay1 > 2000.0);

  /* Switch: '<S94>/Switch2' incorporates:
   *  Constant: '<S45>/Constant2'
   */
  if (localB->LowerRelop1) {
    localB->Switch2 = 2000.0;
  } else {
    /* RelationalOperator: '<S94>/UpperRelop' incorporates:
     *  Constant: '<S45>/Constant3'
     */
    localB->UpperRelop_p = (localB->Delay1 < -2000.0);

    /* Switch: '<S94>/Switch' incorporates:
     *  Constant: '<S45>/Constant3'
     */
    if (localB->UpperRelop_p) {
      localB->Switch_k = -2000.0;
    } else {
      localB->Switch_k = localB->Delay1;
    }

    /* End of Switch: '<S94>/Switch' */
    localB->Switch2 = localB->Switch_k;
  }

  /* End of Switch: '<S94>/Switch2' */

  /* Sum: '<S45>/Sum' */
  localB->Sum = localB->yref - localB->Switch2;

  /* Gain: '<S45>/Kp1' */
  localB->Kp1 = 0.15 * localB->Sum;

  /* DiscreteIntegrator: '<S45>/Discrete-Time Integrator1' */
  if (localDW->DiscreteTimeIntegrator1_SYSTEM_ != 0) {
    localB->DiscreteTimeIntegrator1 = localDW->DiscreteTimeIntegrator1_DSTATE;
  } else {
    localB->DiscreteTimeIntegrator1 = 0.05 * (real_T)
      localDW->Heating_DHW_Ctrl_ELAPS_T[0] *
      localDW->DiscreteTimeIntegrator1_PREV_U +
      localDW->DiscreteTimeIntegrator1_DSTATE;
  }

  /* End of DiscreteIntegrator: '<S45>/Discrete-Time Integrator1' */

  /* Gain: '<S45>/Kd1' */
  localB->Kd1 = 0.001 * localB->Sum;

  /* SampleTimeMath: '<S92>/TSamp'
   *
   * About '<S92>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  elapseTime = (real_T)localDW->Heating_DHW_Ctrl_ELAPS_T[0] * 0.05 + (real_T)
    localDW->Heating_DHW_Ctrl_ELAPS_T[1] * 2.147483648E+8;
  localB->TSamp = localB->Kd1 / elapseTime;

  /* UnitDelay: '<S92>/UD' */
  localB->Uk1 = localDW->UD_DSTATE;

  /* Sum: '<S92>/Diff' */
  localB->Diff = localB->TSamp - localB->Uk1;

  /* Sum: '<S45>/Sum1' */
  localB->u = (localB->Kp1 + localB->DiscreteTimeIntegrator1) + localB->Diff;

  /* ToWorkspace: '<S45>/To Workspace' */
  rt_UpdateLogVar((LogVar *)(LogVar*) (localDW->ToWorkspace_PWORK_e.LoggedData),
                  &localB->u, 0);

  /* Gain: '<S45>/Ki1' */
  localB->Ki1 = 6.1 * localB->Sum;

  /* RelationalOperator: '<S95>/LowerRelop1' incorporates:
   *  Constant: '<S45>/Constant1'
   */
  localB->LowerRelop1_o = (localB->u > 100000.0);

  /* Switch: '<S95>/Switch2' incorporates:
   *  Constant: '<S45>/Constant1'
   */
  if (localB->LowerRelop1_o) {
    localB->Switch2_p = 100000.0;
  } else {
    /* RelationalOperator: '<S95>/UpperRelop' incorporates:
     *  Constant: '<S45>/Constant'
     */
    localB->UpperRelop = (localB->u < -100000.0);

    /* Switch: '<S95>/Switch' incorporates:
     *  Constant: '<S45>/Constant'
     */
    if (localB->UpperRelop) {
      localB->Switch = -100000.0;
    } else {
      localB->Switch = localB->u;
    }

    /* End of Switch: '<S95>/Switch' */
    localB->Switch2_p = localB->Switch;
  }

  /* End of Switch: '<S95>/Switch2' */

  /* Update for DiscreteStateSpace: '<S46>/Discrete State-Space' */
  {
    real_T xnew[1];
    xnew[0] = 0.73080054751891255*localDW->DiscreteStateSpace_DSTATE;
    xnew[0] += (-0.00039541623019055547)*localB->sf_optimizer.u;
    (void) memcpy(&localDW->DiscreteStateSpace_DSTATE, xnew,
                  sizeof(real_T)*1);
  }

  /* Update for DiscreteStateSpace: '<S47>/Discrete State-Space' */
  {
    real_T xnew[1];
    xnew[0] = 0.73080054751891255*localDW->DiscreteStateSpace_DSTATE_b;
    xnew[0] += (-0.00039541623019055547)*localB->Switch2_p;
    (void) memcpy(&localDW->DiscreteStateSpace_DSTATE_b, xnew,
                  sizeof(real_T)*1);
  }

  /* Update for Memory: '<S48>/last_x' */
  localDW->last_x_PreviousInput[0] = localB->sf_optimizer.xk1[0];
  localDW->last_x_PreviousInput[1] = localB->sf_optimizer.xk1[1];
  localDW->last_x_PreviousInput[2] = localB->sf_optimizer.xk1[2];

  /* Update for UnitDelay: '<S48>/last_mv' */
  localDW->last_mv_DSTATE = localB->sf_optimizer.u;

  /* Update for Delay: '<S9>/Delay' */
  localDW->Delay_DSTATE = localB->y;

  /* Update for Memory: '<S48>/Memory' */
  for (i = 0; i < 24; i++) {
    localDW->Memory_PreviousInput[i] = localB->sf_optimizer.iAout[i];
  }

  /* End of Update for Memory: '<S48>/Memory' */

  /* Update for Memory: '<S70>/last_x' */
  for (i = 0; i < 5; i++) {
    localDW->last_x_PreviousInput_e[i] = localB->sf_optimizer_c.xk1[i];
  }

  /* End of Update for Memory: '<S70>/last_x' */

  /* Update for UnitDelay: '<S70>/last_mv' */
  localDW->last_mv_DSTATE_f = localB->sf_optimizer_c.u;

  /* Update for Delay: '<S9>/Delay2' */
  localDW->Delay2_DSTATE = rtu_WT_WEx_Out;

  /* Update for Memory: '<S70>/Memory' */
  for (i = 0; i < 24; i++) {
    localDW->Memory_PreviousInput_d[i] = localB->sf_optimizer_c.iAout[i];
  }

  /* End of Update for Memory: '<S70>/Memory' */

  /* Update for Delay: '<S9>/Delay1' */
  localDW->Delay1_DSTATE = localB->y_i;

  /* Update for DiscreteIntegrator: '<S45>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_SYSTEM_ = 0U;
  localDW->DiscreteTimeIntegrator1_DSTATE = localB->DiscreteTimeIntegrator1;
  localDW->DiscreteTimeIntegrator1_PREV_U = localB->Ki1;

  /* Update for UnitDelay: '<S92>/UD' */
  localDW->UD_DSTATE = localB->TSamp;
}

/* SetupRuntimeResources for function-call system: '<S2>/Heating_Plant_Ctrl' */
void Com_Heating_Plant_Ctrl_SetupRTR(RT_MODEL_Comp_Control_T * const
  Comp_Control_M, DW_Heating_Plant_Ctrl_Comp_Co_T *localDW)
{
  /* SetupRuntimeResources for ToWorkspace: '<S10>/To Workspace' */
  {
    static int_T rt_ToWksWidths[] = { 4 };

    static int_T rt_ToWksNumDimensions[] = { 1 };

    static int_T rt_ToWksDimensions[] = { 4 };

    static boolean_T rt_ToWksIsVarDims[] = { 0 };

    static void *rt_ToWksCurrSigDims[] = { (NULL) };

    static int_T rt_ToWksCurrSigDimsSize[] = { 4 };

    static BuiltInDTypeId rt_ToWksDataTypeIds[] = { SS_DOUBLE };

    static int_T rt_ToWksComplexSignals[] = { 0 };

    static int_T rt_ToWksFrameData[] = { 0 };

    static RTWPreprocessingFcnPtr rt_ToWksLoggingPreprocessingFcnPtrs[] = {
      (NULL)
    };

    static const char_T *rt_ToWksLabels[] = { "" };

    static RTWLogSignalInfo rt_ToWksSignalInfo = {
      1,
      rt_ToWksWidths,
      rt_ToWksNumDimensions,
      rt_ToWksDimensions,
      rt_ToWksIsVarDims,
      rt_ToWksCurrSigDims,
      rt_ToWksCurrSigDimsSize,
      rt_ToWksDataTypeIds,
      rt_ToWksComplexSignals,
      rt_ToWksFrameData,
      rt_ToWksLoggingPreprocessingFcnPtrs,

      { rt_ToWksLabels },
      (NULL),
      (NULL),
      (NULL),

      { (NULL) },

      { (NULL) },
      (NULL),
      (NULL)
    };

    static const char_T rt_ToWksBlockName[] =
      "Comp_Control/Comp_Control/CTRL_Compressor/Heating_Plant_Ctrl/To Workspace";
    localDW->ToWorkspace_PWORK.LoggedData = rt_CreateStructLogVar(
      Comp_Control_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(Comp_Control_M),
      Comp_Control_M->Timing.stepSize0,
      (&rtmGetErrorStatus(Comp_Control_M)),
      "simout_HPlant",
      1,
      0,
      1,
      -1.0,
      &rt_ToWksSignalInfo,
      rt_ToWksBlockName);
    if (localDW->ToWorkspace_PWORK.LoggedData == (NULL))
      return;
  }

  /* SetupRuntimeResources for ToWorkspace: '<S10>/To Workspace1' */
  {
    static int_T rt_ToWksWidths[] = { 1 };

    static int_T rt_ToWksNumDimensions[] = { 1 };

    static int_T rt_ToWksDimensions[] = { 1 };

    static boolean_T rt_ToWksIsVarDims[] = { 0 };

    static void *rt_ToWksCurrSigDims[] = { (NULL) };

    static int_T rt_ToWksCurrSigDimsSize[] = { 4 };

    static BuiltInDTypeId rt_ToWksDataTypeIds[] = { SS_DOUBLE };

    static int_T rt_ToWksComplexSignals[] = { 0 };

    static int_T rt_ToWksFrameData[] = { 0 };

    static RTWPreprocessingFcnPtr rt_ToWksLoggingPreprocessingFcnPtrs[] = {
      (NULL)
    };

    static const char_T *rt_ToWksLabels[] = { "u" };

    static RTWLogSignalInfo rt_ToWksSignalInfo = {
      1,
      rt_ToWksWidths,
      rt_ToWksNumDimensions,
      rt_ToWksDimensions,
      rt_ToWksIsVarDims,
      rt_ToWksCurrSigDims,
      rt_ToWksCurrSigDimsSize,
      rt_ToWksDataTypeIds,
      rt_ToWksComplexSignals,
      rt_ToWksFrameData,
      rt_ToWksLoggingPreprocessingFcnPtrs,

      { rt_ToWksLabels },
      (NULL),
      (NULL),
      (NULL),

      { (NULL) },

      { (NULL) },
      (NULL),
      (NULL)
    };

    static const char_T rt_ToWksBlockName[] =
      "Comp_Control/Comp_Control/CTRL_Compressor/Heating_Plant_Ctrl/To Workspace1";
    localDW->ToWorkspace1_PWORK.LoggedData = rt_CreateStructLogVar(
      Comp_Control_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(Comp_Control_M),
      Comp_Control_M->Timing.stepSize0,
      (&rtmGetErrorStatus(Comp_Control_M)),
      "compfreq1",
      1,
      0,
      1,
      -1.0,
      &rt_ToWksSignalInfo,
      rt_ToWksBlockName);
    if (localDW->ToWorkspace1_PWORK.LoggedData == (NULL))
      return;
  }

  /* SetupRuntimeResources for ToWorkspace: '<S142>/To Workspace' */
  {
    int_T dimensions[1] = { 1 };

    localDW->ToWorkspace_PWORK_g.LoggedData = rt_CreateLogVar(
      Comp_Control_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(Comp_Control_M),
      Comp_Control_M->Timing.stepSize0,
      (&rtmGetErrorStatus(Comp_Control_M)),
      "u",
      SS_DOUBLE,
      0,
      0,
      0,
      1,
      1,
      dimensions,
      NO_LOGVALDIMS,
      (NULL),
      (NULL),
      0,
      1,
      -1.0,
      1);
    if (localDW->ToWorkspace_PWORK_g.LoggedData == (NULL))
      return;
  }
}

/* System initialize for function-call system: '<S2>/Heating_Plant_Ctrl' */
void Comp_Co_Heating_Plant_Ctrl_Init(DW_Heating_Plant_Ctrl_Comp_Co_T *localDW)
{
  int32_T i;

  /* InitializeConditions for DiscreteStateSpace: '<S143>/Discrete State-Space' */
  localDW->DiscreteStateSpace_DSTATE = 0.0;

  /* InitializeConditions for DiscreteStateSpace: '<S144>/Discrete State-Space' */
  localDW->DiscreteStateSpace_DSTATE_a = 0.0;

  /* InitializeConditions for Memory: '<S145>/last_x' */
  localDW->last_x_PreviousInput[0] = 0.0;
  localDW->last_x_PreviousInput[1] = 0.0;
  localDW->last_x_PreviousInput[2] = 0.0;

  /* InitializeConditions for UnitDelay: '<S145>/last_mv' */
  localDW->last_mv_DSTATE = 0.0;

  /* InitializeConditions for Delay: '<S10>/Delay' */
  localDW->Delay_DSTATE = 0.0;

  /* InitializeConditions for Memory: '<S145>/Memory' */
  for (i = 0; i < 24; i++) {
    localDW->Memory_PreviousInput[i] = false;
  }

  /* End of InitializeConditions for Memory: '<S145>/Memory' */

  /* InitializeConditions for Memory: '<S167>/last_x' */
  for (i = 0; i < 5; i++) {
    localDW->last_x_PreviousInput_m[i] = 0.0;
  }

  /* End of InitializeConditions for Memory: '<S167>/last_x' */

  /* InitializeConditions for UnitDelay: '<S167>/last_mv' */
  localDW->last_mv_DSTATE_j = 0.0;

  /* InitializeConditions for Delay: '<S10>/Delay2' */
  localDW->Delay2_DSTATE = 0.0;

  /* InitializeConditions for Memory: '<S167>/Memory' */
  for (i = 0; i < 24; i++) {
    localDW->Memory_PreviousInput_p[i] = false;
  }

  /* End of InitializeConditions for Memory: '<S167>/Memory' */

  /* InitializeConditions for Delay: '<S10>/Delay1' */
  localDW->Delay1_DSTATE = 0.0;

  /* InitializeConditions for DiscreteIntegrator: '<S142>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_DSTATE = 0.0;
  localDW->DiscreteTimeIntegrator1_PREV_U = 0.0;

  /* InitializeConditions for UnitDelay: '<S189>/UD' */
  localDW->UD_DSTATE = 0.0;
}

/* Enable for function-call system: '<S2>/Heating_Plant_Ctrl' */
void Comp__Heating_Plant_Ctrl_Enable(DW_Heating_Plant_Ctrl_Comp_Co_T *localDW)
{
  localDW->Heating_Plant_Ctrl_RESET_ELAPS_ = true;

  /* Enable for DiscreteIntegrator: '<S142>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_SYSTEM_ = 1U;
}

/* Output and update for function-call system: '<S2>/Heating_Plant_Ctrl' */
void Comp_Control_Heating_Plant_Ctrl(RT_MODEL_Comp_Control_T * const
  Comp_Control_M, real_T rtu_yref, real_T rtu_WT_WEx_Out, const real_T
  rtu_Temp_Vect[2], real_T rtu_WT_WEx_In, real_T *rty_Comp_Freq,
  B_Heating_Plant_Ctrl_Comp_Con_T *localB, DW_Heating_Plant_Ctrl_Comp_Co_T
  *localDW)
{
  real_T elapseTime;
  int32_T i;
  uint32_T prevT_idx_0;
  uint32_T elapseTime_idx_0;
  uint32_T prevT_idx_1;
  if (localDW->Heating_Plant_Ctrl_RESET_ELAPS_) {
    localDW->Heating_Plant_Ctrl_ELAPS_T[0] = 0U;
    localDW->Heating_Plant_Ctrl_ELAPS_T[1] = 0U;
  } else {
    prevT_idx_0 = localDW->Heating_Plant_Ctrl_PREV_T[0];
    prevT_idx_1 = localDW->Heating_Plant_Ctrl_PREV_T[1];
    elapseTime_idx_0 = Comp_Control_M->Timing.clockTick0 - prevT_idx_0;
    prevT_idx_1 = Comp_Control_M->Timing.clockTickH0 - prevT_idx_1;
    if (prevT_idx_0 > Comp_Control_M->Timing.clockTick0) {
      prevT_idx_1--;
    }

    localDW->Heating_Plant_Ctrl_ELAPS_T[0] = elapseTime_idx_0;
    localDW->Heating_Plant_Ctrl_ELAPS_T[1] = prevT_idx_1;
  }

  prevT_idx_0 = Comp_Control_M->Timing.clockTick0;
  prevT_idx_1 = Comp_Control_M->Timing.clockTickH0;
  localDW->Heating_Plant_Ctrl_PREV_T[0] = prevT_idx_0;
  localDW->Heating_Plant_Ctrl_PREV_T[1] = prevT_idx_1;
  localDW->Heating_Plant_Ctrl_RESET_ELAPS_ = false;

  /* DiscreteStateSpace: '<S143>/Discrete State-Space' */
  {
    localB->y = (-46.338838950170377)*localDW->DiscreteStateSpace_DSTATE;
  }

  /* Sum: '<S10>/Add4' */
  localB->WT_WEx_Out_b = localB->y + rtu_WT_WEx_In;

  /* DiscreteStateSpace: '<S144>/Discrete State-Space' */
  {
    localB->y_i = (-46.338838950170377)*localDW->DiscreteStateSpace_DSTATE_a;
  }

  /* Sum: '<S10>/Add3' */
  localB->WT_WEx_Out_c = rtu_WT_WEx_In + localB->y_i;

  /* SignalConversion generated from: '<S10>/To Workspace' */
  localB->TmpSignalConversionAtToWorkspac[0] = rtu_WT_WEx_Out;
  localB->TmpSignalConversionAtToWorkspac[1] = localB->WT_WEx_Out_b;
  localB->TmpSignalConversionAtToWorkspac[2] = localB->WT_WEx_Out_c;
  localB->TmpSignalConversionAtToWorkspac[3] = rtu_yref;

  /* Memory: '<S145>/last_x' */
  localB->last_x[0] = localDW->last_x_PreviousInput[0];
  localB->last_x[1] = localDW->last_x_PreviousInput[1];
  localB->last_x[2] = localDW->last_x_PreviousInput[2];

  /* UnitDelay: '<S145>/last_mv' */
  localB->last_mv = localDW->last_mv_DSTATE;

  /* Delay: '<S10>/Delay' */
  localB->Delay = localDW->Delay_DSTATE;

  /* Sum: '<S10>/Add2' */
  localB->yref = rtu_yref - rtu_WT_WEx_In;

  /* Memory: '<S145>/Memory' */
  for (i = 0; i < 24; i++) {
    localB->Memory[i] = localDW->Memory_PreviousInput[i];
  }

  /* End of Memory: '<S145>/Memory' */

  /* MATLAB Function: '<S165>/optimizer' */
  Comp_Control_optimizer(localB->last_x, localB->last_mv, localB->Delay,
    localB->yref, localB->Memory, &localB->sf_optimizer);

  /* ToWorkspace: '<S10>/To Workspace' */
  {
    double locTime = Comp_Control_M->Timing.taskTime0;
    ;
    rt_UpdateStructLogVar((StructLogVar *)localDW->ToWorkspace_PWORK.LoggedData,
                          &locTime, &localB->TmpSignalConversionAtToWorkspac[0]);
  }

  /* Memory: '<S167>/last_x' */
  for (i = 0; i < 5; i++) {
    localB->last_x_p[i] = localDW->last_x_PreviousInput_m[i];
  }

  /* End of Memory: '<S167>/last_x' */

  /* UnitDelay: '<S167>/last_mv' */
  localB->last_mv_i = localDW->last_mv_DSTATE_j;

  /* Delay: '<S10>/Delay2' */
  localB->WT_WEx_Out = localDW->Delay2_DSTATE;

  /* Memory: '<S167>/Memory' */
  for (i = 0; i < 24; i++) {
    localB->Memory_c[i] = localDW->Memory_PreviousInput_p[i];
  }

  /* End of Memory: '<S167>/Memory' */

  /* MATLAB Function: '<S187>/optimizer' */
  Comp_Control_optimizer_c(localB->last_x_p, localB->last_mv_i,
    localB->WT_WEx_Out, rtu_yref, rtu_Temp_Vect, localB->Memory_c,
    &localB->sf_optimizer_o);

  /* ToWorkspace: '<S10>/To Workspace1' */
  {
    double locTime = Comp_Control_M->Timing.taskTime0;
    ;
    rt_UpdateStructLogVar((StructLogVar *)localDW->ToWorkspace1_PWORK.LoggedData,
                          &locTime, &localB->sf_optimizer_o.u);
  }

  /* Delay: '<S10>/Delay1' */
  localB->Delay1 = localDW->Delay1_DSTATE;

  /* SignalConversion generated from: '<S10>/Comp_Freq' */
  *rty_Comp_Freq = localB->sf_optimizer_o.u;

  /* RelationalOperator: '<S191>/LowerRelop1' incorporates:
   *  Constant: '<S142>/Constant2'
   */
  localB->LowerRelop1 = (localB->Delay1 > 2000.0);

  /* Switch: '<S191>/Switch2' incorporates:
   *  Constant: '<S142>/Constant2'
   */
  if (localB->LowerRelop1) {
    localB->Switch2 = 2000.0;
  } else {
    /* RelationalOperator: '<S191>/UpperRelop' incorporates:
     *  Constant: '<S142>/Constant3'
     */
    localB->UpperRelop_h = (localB->Delay1 < -2000.0);

    /* Switch: '<S191>/Switch' incorporates:
     *  Constant: '<S142>/Constant3'
     */
    if (localB->UpperRelop_h) {
      localB->Switch_f = -2000.0;
    } else {
      localB->Switch_f = localB->Delay1;
    }

    /* End of Switch: '<S191>/Switch' */
    localB->Switch2 = localB->Switch_f;
  }

  /* End of Switch: '<S191>/Switch2' */

  /* Sum: '<S142>/Sum' */
  localB->Sum = localB->yref - localB->Switch2;

  /* Gain: '<S142>/Kp1' */
  localB->Kp1 = 0.15 * localB->Sum;

  /* DiscreteIntegrator: '<S142>/Discrete-Time Integrator1' */
  if (localDW->DiscreteTimeIntegrator1_SYSTEM_ != 0) {
    localB->DiscreteTimeIntegrator1 = localDW->DiscreteTimeIntegrator1_DSTATE;
  } else {
    localB->DiscreteTimeIntegrator1 = 0.05 * (real_T)
      localDW->Heating_Plant_Ctrl_ELAPS_T[0] *
      localDW->DiscreteTimeIntegrator1_PREV_U +
      localDW->DiscreteTimeIntegrator1_DSTATE;
  }

  /* End of DiscreteIntegrator: '<S142>/Discrete-Time Integrator1' */

  /* Gain: '<S142>/Kd1' */
  localB->Kd1 = 0.001 * localB->Sum;

  /* SampleTimeMath: '<S189>/TSamp'
   *
   * About '<S189>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  elapseTime = (real_T)localDW->Heating_Plant_Ctrl_ELAPS_T[0] * 0.05 + (real_T)
    localDW->Heating_Plant_Ctrl_ELAPS_T[1] * 2.147483648E+8;
  localB->TSamp = localB->Kd1 / elapseTime;

  /* UnitDelay: '<S189>/UD' */
  localB->Uk1 = localDW->UD_DSTATE;

  /* Sum: '<S189>/Diff' */
  localB->Diff = localB->TSamp - localB->Uk1;

  /* Sum: '<S142>/Sum1' */
  localB->u = (localB->Kp1 + localB->DiscreteTimeIntegrator1) + localB->Diff;

  /* ToWorkspace: '<S142>/To Workspace' */
  rt_UpdateLogVar((LogVar *)(LogVar*) (localDW->ToWorkspace_PWORK_g.LoggedData),
                  &localB->u, 0);

  /* Gain: '<S142>/Ki1' */
  localB->Ki1 = 6.1 * localB->Sum;

  /* RelationalOperator: '<S192>/LowerRelop1' incorporates:
   *  Constant: '<S142>/Constant1'
   */
  localB->LowerRelop1_f = (localB->u > 100000.0);

  /* Switch: '<S192>/Switch2' incorporates:
   *  Constant: '<S142>/Constant1'
   */
  if (localB->LowerRelop1_f) {
    localB->Switch2_i = 100000.0;
  } else {
    /* RelationalOperator: '<S192>/UpperRelop' incorporates:
     *  Constant: '<S142>/Constant'
     */
    localB->UpperRelop = (localB->u < -100000.0);

    /* Switch: '<S192>/Switch' incorporates:
     *  Constant: '<S142>/Constant'
     */
    if (localB->UpperRelop) {
      localB->Switch = -100000.0;
    } else {
      localB->Switch = localB->u;
    }

    /* End of Switch: '<S192>/Switch' */
    localB->Switch2_i = localB->Switch;
  }

  /* End of Switch: '<S192>/Switch2' */

  /* Update for DiscreteStateSpace: '<S143>/Discrete State-Space' */
  {
    real_T xnew[1];
    xnew[0] = 0.73080054751891255*localDW->DiscreteStateSpace_DSTATE;
    xnew[0] += (-0.00039541623019055547)*localB->sf_optimizer.u;
    (void) memcpy(&localDW->DiscreteStateSpace_DSTATE, xnew,
                  sizeof(real_T)*1);
  }

  /* Update for DiscreteStateSpace: '<S144>/Discrete State-Space' */
  {
    real_T xnew[1];
    xnew[0] = 0.73080054751891255*localDW->DiscreteStateSpace_DSTATE_a;
    xnew[0] += (-0.00039541623019055547)*localB->Switch2_i;
    (void) memcpy(&localDW->DiscreteStateSpace_DSTATE_a, xnew,
                  sizeof(real_T)*1);
  }

  /* Update for Memory: '<S145>/last_x' */
  localDW->last_x_PreviousInput[0] = localB->sf_optimizer.xk1[0];
  localDW->last_x_PreviousInput[1] = localB->sf_optimizer.xk1[1];
  localDW->last_x_PreviousInput[2] = localB->sf_optimizer.xk1[2];

  /* Update for UnitDelay: '<S145>/last_mv' */
  localDW->last_mv_DSTATE = localB->sf_optimizer.u;

  /* Update for Delay: '<S10>/Delay' */
  localDW->Delay_DSTATE = localB->y;

  /* Update for Memory: '<S145>/Memory' */
  for (i = 0; i < 24; i++) {
    localDW->Memory_PreviousInput[i] = localB->sf_optimizer.iAout[i];
  }

  /* End of Update for Memory: '<S145>/Memory' */

  /* Update for Memory: '<S167>/last_x' */
  for (i = 0; i < 5; i++) {
    localDW->last_x_PreviousInput_m[i] = localB->sf_optimizer_o.xk1[i];
  }

  /* End of Update for Memory: '<S167>/last_x' */

  /* Update for UnitDelay: '<S167>/last_mv' */
  localDW->last_mv_DSTATE_j = localB->sf_optimizer_o.u;

  /* Update for Delay: '<S10>/Delay2' */
  localDW->Delay2_DSTATE = rtu_WT_WEx_Out;

  /* Update for Memory: '<S167>/Memory' */
  for (i = 0; i < 24; i++) {
    localDW->Memory_PreviousInput_p[i] = localB->sf_optimizer_o.iAout[i];
  }

  /* End of Update for Memory: '<S167>/Memory' */

  /* Update for Delay: '<S10>/Delay1' */
  localDW->Delay1_DSTATE = localB->y_i;

  /* Update for DiscreteIntegrator: '<S142>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_SYSTEM_ = 0U;
  localDW->DiscreteTimeIntegrator1_DSTATE = localB->DiscreteTimeIntegrator1;
  localDW->DiscreteTimeIntegrator1_PREV_U = localB->Ki1;

  /* Update for UnitDelay: '<S189>/UD' */
  localDW->UD_DSTATE = localB->TSamp;
}

/* SetupRuntimeResources for function-call system: '<S2>/Cooling_Plant_Ctrl' */
void Com_Cooling_Plant_Ctrl_SetupRTR(RT_MODEL_Comp_Control_T * const
  Comp_Control_M, DW_Cooling_Plant_Ctrl_Comp_Co_T *localDW)
{
  /* SetupRuntimeResources for ToWorkspace: '<S5>/To Workspace' */
  {
    static int_T rt_ToWksWidths[] = { 4 };

    static int_T rt_ToWksNumDimensions[] = { 1 };

    static int_T rt_ToWksDimensions[] = { 4 };

    static boolean_T rt_ToWksIsVarDims[] = { 0 };

    static void *rt_ToWksCurrSigDims[] = { (NULL) };

    static int_T rt_ToWksCurrSigDimsSize[] = { 4 };

    static BuiltInDTypeId rt_ToWksDataTypeIds[] = { SS_DOUBLE };

    static int_T rt_ToWksComplexSignals[] = { 0 };

    static int_T rt_ToWksFrameData[] = { 0 };

    static RTWPreprocessingFcnPtr rt_ToWksLoggingPreprocessingFcnPtrs[] = {
      (NULL)
    };

    static const char_T *rt_ToWksLabels[] = { "" };

    static RTWLogSignalInfo rt_ToWksSignalInfo = {
      1,
      rt_ToWksWidths,
      rt_ToWksNumDimensions,
      rt_ToWksDimensions,
      rt_ToWksIsVarDims,
      rt_ToWksCurrSigDims,
      rt_ToWksCurrSigDimsSize,
      rt_ToWksDataTypeIds,
      rt_ToWksComplexSignals,
      rt_ToWksFrameData,
      rt_ToWksLoggingPreprocessingFcnPtrs,

      { rt_ToWksLabels },
      (NULL),
      (NULL),
      (NULL),

      { (NULL) },

      { (NULL) },
      (NULL),
      (NULL)
    };

    static const char_T rt_ToWksBlockName[] =
      "Comp_Control/Comp_Control/CTRL_Compressor/Cooling_Plant_Ctrl/To Workspace";
    localDW->ToWorkspace_PWORK.LoggedData = rt_CreateStructLogVar(
      Comp_Control_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(Comp_Control_M),
      Comp_Control_M->Timing.stepSize0,
      (&rtmGetErrorStatus(Comp_Control_M)),
      "simout_Cooling",
      1,
      0,
      1,
      -1.0,
      &rt_ToWksSignalInfo,
      rt_ToWksBlockName);
    if (localDW->ToWorkspace_PWORK.LoggedData == (NULL))
      return;
  }

  /* SetupRuntimeResources for ToWorkspace: '<S5>/To Workspace1' */
  {
    static int_T rt_ToWksWidths[] = { 1 };

    static int_T rt_ToWksNumDimensions[] = { 1 };

    static int_T rt_ToWksDimensions[] = { 1 };

    static boolean_T rt_ToWksIsVarDims[] = { 0 };

    static void *rt_ToWksCurrSigDims[] = { (NULL) };

    static int_T rt_ToWksCurrSigDimsSize[] = { 4 };

    static BuiltInDTypeId rt_ToWksDataTypeIds[] = { SS_DOUBLE };

    static int_T rt_ToWksComplexSignals[] = { 0 };

    static int_T rt_ToWksFrameData[] = { 0 };

    static RTWPreprocessingFcnPtr rt_ToWksLoggingPreprocessingFcnPtrs[] = {
      (NULL)
    };

    static const char_T *rt_ToWksLabels[] = { "u" };

    static RTWLogSignalInfo rt_ToWksSignalInfo = {
      1,
      rt_ToWksWidths,
      rt_ToWksNumDimensions,
      rt_ToWksDimensions,
      rt_ToWksIsVarDims,
      rt_ToWksCurrSigDims,
      rt_ToWksCurrSigDimsSize,
      rt_ToWksDataTypeIds,
      rt_ToWksComplexSignals,
      rt_ToWksFrameData,
      rt_ToWksLoggingPreprocessingFcnPtrs,

      { rt_ToWksLabels },
      (NULL),
      (NULL),
      (NULL),

      { (NULL) },

      { (NULL) },
      (NULL),
      (NULL)
    };

    static const char_T rt_ToWksBlockName[] =
      "Comp_Control/Comp_Control/CTRL_Compressor/Cooling_Plant_Ctrl/To Workspace1";
    localDW->ToWorkspace1_PWORK.LoggedData = rt_CreateStructLogVar(
      Comp_Control_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(Comp_Control_M),
      Comp_Control_M->Timing.stepSize0,
      (&rtmGetErrorStatus(Comp_Control_M)),
      "compfreq",
      1,
      0,
      1,
      -1.0,
      &rt_ToWksSignalInfo,
      rt_ToWksBlockName);
    if (localDW->ToWorkspace1_PWORK.LoggedData == (NULL))
      return;
  }
}

/* System initialize for function-call system: '<S2>/Cooling_Plant_Ctrl' */
void Comp_Co_Cooling_Plant_Ctrl_Init(DW_Cooling_Plant_Ctrl_Comp_Co_T *localDW)
{
  int32_T i;

  /* InitializeConditions for DiscreteStateSpace: '<S15>/Discrete State-Space' */
  localDW->DiscreteStateSpace_DSTATE[0] = 0.0;
  localDW->DiscreteStateSpace_DSTATE[1] = 0.0;
  localDW->DiscreteStateSpace_DSTATE[2] = 0.0;

  /* InitializeConditions for Memory: '<S16>/last_x' */
  for (i = 0; i < 5; i++) {
    localDW->last_x_PreviousInput[i] = 0.0;
  }

  /* End of InitializeConditions for Memory: '<S16>/last_x' */

  /* InitializeConditions for UnitDelay: '<S16>/last_mv' */
  localDW->last_mv_DSTATE = 0.0;

  /* InitializeConditions for Delay: '<S5>/Delay2' */
  localDW->Delay2_DSTATE = 0.0;

  /* InitializeConditions for Memory: '<S16>/Memory' */
  localDW->Memory_PreviousInput = false;
}

/* Output and update for function-call system: '<S2>/Cooling_Plant_Ctrl' */
void Comp_Control_Cooling_Plant_Ctrl(RT_MODEL_Comp_Control_T * const
  Comp_Control_M, real_T *rty_Comp_Freq_Cooling, B_Cooling_Plant_Ctrl_Comp_Con_T
  *localB, const ConstB_Cooling_Plant_Ctrl_Com_T *localC,
  DW_Cooling_Plant_Ctrl_Comp_Co_T *localDW)
{
  real_T xk[5];
  real_T y_innov;
  real_T rseq[10];
  real_T vseq[33];
  real_T zopt[2];
  real_T f[2];
  int32_T i;
  real_T b_Kx;
  real_T b_Kr;
  int32_T i_0;
  real_T xk_0;
  real_T v_idx_0;
  real_T v_idx_1;
  real_T v_idx_2;
  static const real_T b_a[5] = { 0.99999999999999989, 0.0, 0.0, 0.0, 1.0 };

  static const real_T a[5] = { 0.0028474967200876103, -0.00013503062820355866,
    0.00059325638637163847, 0.00021959847429569627, 0.048694406675820569 };

  static const real_T b_Kx_0[10] = { 0.0, 0.59511841056060577,
    -0.5707045052389047, 0.23731187094707357, -0.7650996636050128, 0.0,
    0.47685359243006792, -0.46497673130430184, 0.20845649231550475,
    -0.65025420675735113 };

  static const real_T b_Kr_0[20] = { -0.0, 0.052367636631078261,
    0.056714697356347446, 0.068693701412871316, 0.0783878387637067,
    0.08729598607839878, 0.095294479764713572, 0.10250338827597824,
    0.10899647847425685, 0.11484545684766168, -0.0, -0.0, 0.052367636631078261,
    0.056714697356347446, 0.068693701412871316, 0.0783878387637067,
    0.08729598607839878, 0.095294479764713572, 0.10250338827597824,
    0.10899647847425685 };

  static const real_T d_a[5] = { 0.0, 0.027171632774449218, 0.032948320745139328,
    0.034545399826917435, 0.0 };

  static const real_T c_a[25] = { 0.0, 0.0, 0.0, 0.0, 0.0, -2.255430721229,
    0.55477375014492214, -0.32014124051160769, 0.076708530627088364, 0.0,
    0.2125343203229825, -0.44942925160725433, 0.41619189365469061,
    -0.054458491766760708, 0.0, 0.055389421705998206, 0.016133837569780839,
    -0.44921122711126626, -0.14280292414053328, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0 };

  static const real_T e_a[5] = { 0.00044280300251068244, -0.00033799525561628531,
    0.0001914912715767811, -7.4025153378171109E-5, 0.048694406675820624 };

  /* DiscreteStateSpace: '<S15>/Discrete State-Space' */
  {
    localB->y = (-2.2554307212290006)*localDW->DiscreteStateSpace_DSTATE[0] +
      (0.21253432032298253)*localDW->DiscreteStateSpace_DSTATE[1]
      + (0.055389421705998212)*localDW->DiscreteStateSpace_DSTATE[2];
  }

  /* Step: '<S5>/Step1' */
  y_innov = Comp_Control_M->Timing.taskTime0;
  if (y_innov < 50.0) {
    localB->y_step = 18.0;
  } else {
    localB->y_step = 10.0;
  }

  /* End of Step: '<S5>/Step1' */

  /* SignalConversion generated from: '<S5>/To Workspace' */
  localB->TmpSignalConversionAtToWorkspac[0] = localB->y;
  localB->TmpSignalConversionAtToWorkspac[1] = 0.0;
  localB->TmpSignalConversionAtToWorkspac[2] = 0.0;
  localB->TmpSignalConversionAtToWorkspac[3] = localB->y_step;

  /* ToWorkspace: '<S5>/To Workspace' */
  {
    double locTime = Comp_Control_M->Timing.taskTime0;
    ;
    rt_UpdateStructLogVar((StructLogVar *)localDW->ToWorkspace_PWORK.LoggedData,
                          &locTime, &localB->TmpSignalConversionAtToWorkspac[0]);
  }

  /* Memory: '<S16>/last_x' */
  for (i = 0; i < 5; i++) {
    localB->last_x[i] = localDW->last_x_PreviousInput[i];
  }

  /* End of Memory: '<S16>/last_x' */

  /* UnitDelay: '<S16>/last_mv' */
  localB->last_mv = localDW->last_mv_DSTATE;

  /* Delay: '<S5>/Delay2' */
  localB->Delay2 = localDW->Delay2_DSTATE;

  /* Sum: '<S5>/Add' */
  localB->yref = localB->y_step;

  /* Memory: '<S16>/Memory' */
  localB->Memory = localDW->Memory_PreviousInput;

  /* SignalConversion generated from: '<S37>/ SFunction ' incorporates:
   *  MATLAB Function: '<S36>/optimizer'
   */
  localB->TmpSignalConversionAtSFunctionI[0] = localC->WT_WEx_In;
  localB->TmpSignalConversionAtSFunctionI[1] = localC->T_Air;

  /* MATLAB Function: '<S36>/optimizer' */
  /* :  coder.extrinsic('mpcblock_optimizer_double_mex'); */
  /* :  coder.extrinsic('mpcblock_optimizer_single_mex'); */
  /* :  coder.extrinsic('mpcblock_refmd_double_mex'); */
  /* :  coder.extrinsic('mpcblock_refmd_single_mex'); */
  /* :  isSimulation = coder.target('Sfun') && ~coder.target('RtwForRapid') && ~coder.target('RtwForSim'); */
  /* :  isAdaptive = false; */
  /* :  isLTV = false; */
  /* :  isDouble = isa(ref,'double'); */
  /* :  ZERO = zeros('like',ref); */
  /* :  ONE = ones('like',ref); */
  /* :  if isSimulation */
  /* :  else */
  /* :  [rseq, vseq, v] = mpcblock_refmd(ref,md,nv,ny,p,yoff,voff,no_md,no_ref,openloopflag, RYscale, RMDscale); */
  memset(&vseq[0], 0, 33U * sizeof(real_T));
  for (i = 0; i < 11; i++) {
    vseq[(i * (int32_T)Comp_Control_nv_aa + (int32_T)Comp_Control_nv_aa) - 1] =
      1.0;
  }

  for (i = 0; i < 10; i++) {
    rseq[i] = localB->yref;
  }

  for (i = 0; i < 11; i++) {
    vseq[i * (int32_T)Comp_Control_nv_aa] =
      localB->TmpSignalConversionAtSFunctionI[0] - 18.0;
    vseq[i * (int32_T)Comp_Control_nv_aa + 1] =
      localB->TmpSignalConversionAtSFunctionI[1] - 2.0;
  }

  v_idx_0 = vseq[0];
  v_idx_1 = vseq[1];
  v_idx_2 = vseq[2];

  /* :  old_u = old_u - uoff; */
  /* :  if no_mv==ONE */
  /* :  delmv = zeros(nu,1,'like',ref); */
  /* :  xk = xk - xoff; */
  /* :  if CustomEstimation==ONE */
  /* :  else */
  /* :  ym = ym.*RYscale(myindex) - myoff; */
  /* :  xk = xk + Bu*delmv; */
  /* :  ym_est = C(myindex,:)*xk + Dv(myindex,:)*v; */
  /* :  y_innov = ym - ym_est; */
  y_innov = 0.0;
  for (i = 0; i < 5; i++) {
    xk_0 = localB->last_x[i];
    y_innov += b_a[i] * xk_0;
    xk[i] = xk_0;
  }

  xk_0 = 0.0 * v_idx_0;
  xk_0 += 0.0 * v_idx_1;
  xk_0 += 0.0 * v_idx_2;
  y_innov = localB->Delay2 - (y_innov + xk_0);

  /* :  xest = xk + M*y_innov; */
  for (i = 0; i < 5; i++) {
    localB->xest[i] = a[i] * y_innov + xk[i];
  }

  /* :  if no_uref==ONE */
  /* :  utargetValue = utarget; */
  /* :  if no_cc~=ONE */
  /* :  return_sequence = (return_mvseq || return_xseq || return_ovseq)*ONE; */
  /* :  if isSimulation */
  /* :  else */
  /* :  [u, cost, useq, status, iAout] = mpcblock_optimizer(... */
  /* :              rseq, vseq, umin, umax, ymin, ymax, switch_in, xest, old_u, iA, ... */
  /* :              isQP, nu, ny, degrees, Hinv, Kx, Ku1, Kut, Kr, Kv, Mlim, ... */
  /* :              Mx, Mu1, Mv, z_degrees, utargetValue, p, uoff, voff, yoff, maxiter, ... */
  /* :              false, CustomSolverCodeGen, UseWarmStart, UseSuboptimalSolution, nxQP, openloopflag, ... */
  /* :              no_umin, no_umax, no_ymin, no_ymax, no_cc, switch_inport, ... */
  /* :              no_switch, enable_value, return_cost, H, return_sequence, Linv, Ac, ... */
  /* :              ywt, uwt, duwt, rhoeps, no_ywt, no_uwt, no_duwt, no_rhoeps,... */
  /* :              Wy, Wdu, Jm, SuJm, Su1, Sx, Hv, Wu, I1, ... */
  /* :              isAdaptive, isLTV, A, Bu, Bv, C, Dv, ... */
  /* :              Mrows, nCC, Ecc, Fcc, Scc, Gcc); */
  for (i = 0; i < 2; i++) {
    b_Kx = 0.0;
    for (i_0 = 0; i_0 < 5; i_0++) {
      b_Kx += b_Kx_0[5 * i + i_0] * localB->xest[i_0];
    }

    b_Kr = 0.0;
    for (i_0 = 0; i_0 < 10; i_0++) {
      b_Kr += b_Kr_0[10 * i + i_0] * rseq[i_0];
    }

    xk_0 = 0.0;
    for (i_0 = 0; i_0 < 33; i_0++) {
      xk_0 += 0.0 * vseq[i_0];
    }

    f[i] = ((-0.0082299441095372988 * (real_T)i + 0.069100687087812931) *
            localB->last_mv + (b_Kx + b_Kr)) + xk_0;
  }

  xk_0 = 0.0 - 43.696845955185523 * f[0];
  zopt[0] = xk_0;
  xk_0 = zopt[0];
  xk_0 -= -40.355192304818537 * f[1];
  zopt[0] = xk_0;
  b_Kx = localB->last_mv + zopt[0];
  localB->u = b_Kx;
  localB->cost = 0.0;
  localB->status = 1.0;
  localB->iAout = localB->Memory;

  /* :  if return_xseq || return_ovseq */
  /* :  else */
  /* :  yseq = zeros(p+1,ny,'like',rseq); */
  memset(&localB->useq[0], 0, 11U * sizeof(real_T));
  memset(&localB->yseq[0], 0, 11U * sizeof(real_T));

  /* :  xseq = zeros(p+1,nxQP,'like',rseq); */
  memset(&localB->xseq[0], 0, 55U * sizeof(real_T));

  /* :  if CustomEstimation==ONE */
  /* :  else */
  /* :  xk1 = A*xk + Bu*(u - uoff) + Bv*v + L*y_innov; */
  /* :  xk1 = xk1 + xoff; */
  /* :  xest = xest + xoff; */
  for (i_0 = 0; i_0 < 5; i_0++) {
    xk_0 = 0.0;
    for (i = 0; i < 5; i++) {
      xk_0 += c_a[5 * i + i_0] * xk[i];
    }

    b_Kr = d_a[i_0] * b_Kx + xk_0;
    xk_0 = 0.0 * v_idx_0;
    xk_0 += 0.0 * v_idx_1;
    xk_0 += 0.0 * v_idx_2;
    localB->xk1[i_0] = (b_Kr + xk_0) + e_a[i_0] * y_innov;
  }

  /* ToWorkspace: '<S5>/To Workspace1' */
  {
    double locTime = Comp_Control_M->Timing.taskTime0;
    ;
    rt_UpdateStructLogVar((StructLogVar *)localDW->ToWorkspace1_PWORK.LoggedData,
                          &locTime, &localB->u);
  }

  /* SignalConversion generated from: '<S5>/Comp_Freq_Cooling' */
  *rty_Comp_Freq_Cooling = localB->u;

  /* Update for DiscreteStateSpace: '<S15>/Discrete State-Space' */
  {
    real_T xnew[3];
    xnew[0] = (0.55477375014492214)*localDW->DiscreteStateSpace_DSTATE[0] +
      (-0.44942925160725433)*localDW->DiscreteStateSpace_DSTATE[1]
      + (0.016133837569780839)*localDW->DiscreteStateSpace_DSTATE[2];
    xnew[0] += (0.027171632774449218)*localB->u + (-0.272300711422784)*
      localC->WT_WEx_In
      + (-0.021058523201084357)*localC->T_Air;
    xnew[1] = (-0.32014124051160769)*localDW->DiscreteStateSpace_DSTATE[0] +
      (0.41619189365469061)*localDW->DiscreteStateSpace_DSTATE[1]
      + (-0.44921122711126626)*localDW->DiscreteStateSpace_DSTATE[2];
    xnew[1] += (0.032948320745139328)*localB->u + (-0.77393930587166571)*
      localC->WT_WEx_In
      + (-0.043624832679741279)*localC->T_Air;
    xnew[2] = (0.076708530627088364)*localDW->DiscreteStateSpace_DSTATE[0] +
      (-0.054458491766760708)*localDW->DiscreteStateSpace_DSTATE[1]
      + (-0.14280292414053328)*localDW->DiscreteStateSpace_DSTATE[2];
    xnew[2] += (0.034545399826917435)*localB->u + (-1.0907059133333239)*
      localC->WT_WEx_In
      + (-0.13897790000714016)*localC->T_Air;
    (void) memcpy(&localDW->DiscreteStateSpace_DSTATE[0], xnew,
                  sizeof(real_T)*3);
  }

  /* Update for Memory: '<S16>/last_x' */
  for (i = 0; i < 5; i++) {
    localDW->last_x_PreviousInput[i] = localB->xk1[i];
  }

  /* End of Update for Memory: '<S16>/last_x' */

  /* Update for UnitDelay: '<S16>/last_mv' */
  localDW->last_mv_DSTATE = localB->u;

  /* Update for Delay: '<S5>/Delay2' */
  localDW->Delay2_DSTATE = localB->y;

  /* Update for Memory: '<S16>/Memory' */
  localDW->Memory_PreviousInput = localB->iAout;
}

/* Output and update for function-call system: '<S2>/Off_by_user' */
void Comp_Control_Off_by_user(real_T *rty_Out_Off_by_User)
{
  /* Gain: '<S13>/Gain' */
  *rty_Out_Off_by_User = 0.0;
}

/* Output and update for function-call system: '<S2>/Off_by_Alarm' */
void Comp_Control_Off_by_Alarm(real_T *rty_Out_Off_by_Alarm)
{
  /* Gain: '<S12>/Gain' */
  *rty_Out_Off_by_Alarm = 0.0;
}

/* Output and update for function-call system: '<S2>/Off_ThermoOff' */
void Comp_Control_Off_ThermoOff(real_T *rty_Out_Off_ThermoOff)
{
  /* Gain: '<S11>/Gain' */
  *rty_Out_Off_ThermoOff = 0.0;
}

/* System initialize for function-call system: '<S2>/Defrost_Ctrl' */
void Comp_Control_Defrost_Ctrl_Init(DW_Defrost_Ctrl_Comp_Control_T *localDW)
{
  /* InitializeConditions for DiscreteIntegrator: '<S39>/Discrete-Time Integrator2' */
  localDW->DiscreteTimeIntegrator2_DSTATE = 0.0;
  localDW->DiscreteTimeIntegrator2_PREV_U = 0.0;
}

/* Enable for function-call system: '<S2>/Defrost_Ctrl' */
void Comp_Contro_Defrost_Ctrl_Enable(DW_Defrost_Ctrl_Comp_Control_T *localDW)
{
  localDW->Defrost_Ctrl_RESET_ELAPS_T = true;

  /* Enable for DiscreteIntegrator: '<S39>/Discrete-Time Integrator2' */
  localDW->DiscreteTimeIntegrator2_SYSTEM_ = 1U;
}

/* Output and update for function-call system: '<S2>/Defrost_Ctrl' */
void Comp_Control_Defrost_Ctrl(RT_MODEL_Comp_Control_T * const Comp_Control_M,
  real_T rtu_Comp_Freq_Act, real_T rtu_StS_4WV, real_T *rty_Defrost,
  B_Defrost_Ctrl_Comp_Control_T *localB, DW_Defrost_Ctrl_Comp_Control_T *localDW)
{
  uint32_T prevT_idx_0;
  uint32_T elapseTime_idx_0;
  uint32_T prevT_idx_1;
  if (localDW->Defrost_Ctrl_RESET_ELAPS_T) {
    localDW->Defrost_Ctrl_ELAPS_T[0] = 0U;
    localDW->Defrost_Ctrl_ELAPS_T[1] = 0U;
  } else {
    prevT_idx_0 = localDW->Defrost_Ctrl_PREV_T[0];
    prevT_idx_1 = localDW->Defrost_Ctrl_PREV_T[1];
    elapseTime_idx_0 = Comp_Control_M->Timing.clockTick0 - prevT_idx_0;
    prevT_idx_1 = Comp_Control_M->Timing.clockTickH0 - prevT_idx_1;
    if (prevT_idx_0 > Comp_Control_M->Timing.clockTick0) {
      prevT_idx_1--;
    }

    localDW->Defrost_Ctrl_ELAPS_T[0] = elapseTime_idx_0;
    localDW->Defrost_Ctrl_ELAPS_T[1] = prevT_idx_1;
  }

  prevT_idx_0 = Comp_Control_M->Timing.clockTick0;
  prevT_idx_1 = Comp_Control_M->Timing.clockTickH0;
  localDW->Defrost_Ctrl_PREV_T[0] = prevT_idx_0;
  localDW->Defrost_Ctrl_PREV_T[1] = prevT_idx_1;
  localDW->Defrost_Ctrl_RESET_ELAPS_T = false;

  /* Switch: '<S6>/Switch' incorporates:
   *  Constant: '<S6>/Freq_Min'
   *  Constant: '<S6>/Freq_Min1'
   */
  if (rtu_StS_4WV != 0.0) {
    localB->Switch = 50.0;
  } else {
    localB->Switch = 5.0;
  }

  /* End of Switch: '<S6>/Switch' */

  /* RelationalOperator: '<S41>/LowerRelop1' incorporates:
   *  Constant: '<S39>/Constant2'
   */
  localB->LowerRelop1 = (rtu_Comp_Freq_Act > 150.0);

  /* Switch: '<S41>/Switch2' incorporates:
   *  Constant: '<S39>/Constant2'
   */
  if (localB->LowerRelop1) {
    localB->Switch2 = 150.0;
  } else {
    /* RelationalOperator: '<S41>/UpperRelop' incorporates:
     *  Constant: '<S39>/Constant3'
     */
    localB->UpperRelop_i = (rtu_Comp_Freq_Act < 0.0);

    /* Switch: '<S41>/Switch' incorporates:
     *  Constant: '<S39>/Constant3'
     */
    if (localB->UpperRelop_i) {
      localB->Switch_k = 0.0;
    } else {
      localB->Switch_k = rtu_Comp_Freq_Act;
    }

    /* End of Switch: '<S41>/Switch' */
    localB->Switch2 = localB->Switch_k;
  }

  /* End of Switch: '<S41>/Switch2' */

  /* Sum: '<S39>/Sum' */
  localB->Sum = localB->Switch - localB->Switch2;

  /* Gain: '<S39>/Gain' */
  localB->Gain = 0.1 * localB->Sum;

  /* DiscreteIntegrator: '<S39>/Discrete-Time Integrator2' */
  if (localDW->DiscreteTimeIntegrator2_SYSTEM_ != 0) {
    localB->DiscreteTimeIntegrator2 = localDW->DiscreteTimeIntegrator2_DSTATE;
  } else {
    localB->DiscreteTimeIntegrator2 = 0.05 * (real_T)
      localDW->Defrost_Ctrl_ELAPS_T[0] * localDW->DiscreteTimeIntegrator2_PREV_U
      + localDW->DiscreteTimeIntegrator2_DSTATE;
  }

  /* End of DiscreteIntegrator: '<S39>/Discrete-Time Integrator2' */

  /* Sum: '<S39>/Sum2' */
  localB->u = localB->Gain + localB->DiscreteTimeIntegrator2;

  /* RelationalOperator: '<S42>/LowerRelop1' incorporates:
   *  Constant: '<S39>/Constant1'
   */
  localB->LowerRelop1_o = (localB->u > 150.0);

  /* Switch: '<S42>/Switch2' incorporates:
   *  Constant: '<S39>/Constant1'
   */
  if (localB->LowerRelop1_o) {
    localB->Switch2_b = 150.0;
  } else {
    /* RelationalOperator: '<S42>/UpperRelop' incorporates:
     *  Constant: '<S39>/Constant4'
     */
    localB->UpperRelop = (localB->u < 0.0);

    /* Switch: '<S42>/Switch' incorporates:
     *  Constant: '<S39>/Constant4'
     */
    if (localB->UpperRelop) {
      localB->Switch_e = 0.0;
    } else {
      localB->Switch_e = localB->u;
    }

    /* End of Switch: '<S42>/Switch' */
    localB->Switch2_b = localB->Switch_e;
  }

  /* End of Switch: '<S42>/Switch2' */
  /* Gain: '<S39>/Gain1' */
  localB->Gain1 = 5.0 * localB->Sum;

  /* SignalConversion generated from: '<S6>/Defrost' */
  *rty_Defrost = localB->Switch2_b;

  /* Update for DiscreteIntegrator: '<S39>/Discrete-Time Integrator2' */
  localDW->DiscreteTimeIntegrator2_SYSTEM_ = 0U;
  localDW->DiscreteTimeIntegrator2_DSTATE = localB->DiscreteTimeIntegrator2;
  localDW->DiscreteTimeIntegrator2_PREV_U = localB->Gain1;
}

/* Function for Chart: '<S2>/Final' */
static void Comp_Co_enter_internal_HeatCool(void)
{
  Comp_Control_DW.Plant_need_heat = 1;

  /* Inport: '<Root>/logsigs_comp' */
  if (((Comp_Control_U.logsigs_comp[0] == Comp_Control_DW.Plant_need_heat) &&
       (Comp_Control_U.logsigs_comp[6] == 0) && (Comp_Control_U.logsigs_comp[1] ==
        0) && (Comp_Control_U.logsigs_comp[5] == 0)) ||
      ((Comp_Control_U.logsigs_comp[0] == Comp_Control_DW.Plant_need_heat) &&
       (Comp_Control_U.logsigs_comp[6] == 0) && (Comp_Control_U.logsigs_comp[1] ==
        1))) {
    Comp_Control_DW.bitsForTID0.is_HeatCool = Comp_Control_IN_Heating_Plant;

    /* Outputs for Function Call SubSystem: '<S2>/Heating_Plant_Ctrl' */
    /* Inport: '<Root>/yref' incorporates:
     *  Inport: '<Root>/Temp_Vect'
     *  Inport: '<Root>/WT_WEx'
     */
    Comp_Control_Heating_Plant_Ctrl(Comp_Control_M, Comp_Control_U.yref,
      Comp_Control_U.WT_WEx[0], Comp_Control_U.Temp_Vect, Comp_Control_U.WT_WEx
      [1], &Comp_Control_B.Comp_Freq_merged, &Comp_Control_B.Heating_Plant_Ctrl,
      &Comp_Control_DW.Heating_Plant_Ctrl);

    /* End of Outputs for SubSystem: '<S2>/Heating_Plant_Ctrl' */
  } else {
    /*   */
    if (((Comp_Control_U.logsigs_comp[0] == 2) && (Comp_Control_U.logsigs_comp[6]
          == 1) && (Comp_Control_U.logsigs_comp[1] == 0) &&
         (Comp_Control_U.logsigs_comp[5] == 0)) ||
        ((Comp_Control_U.logsigs_comp[0] == 2) && (Comp_Control_U.logsigs_comp[6]
          == 1) && (Comp_Control_U.logsigs_comp[1] == 1))) {
      Comp_Control_DW.bitsForTID0.is_HeatCool = Comp_Control_IN_Cooling_Plant;

      /* Outputs for Function Call SubSystem: '<S2>/Cooling_Plant_Ctrl' */
      Comp_Control_Cooling_Plant_Ctrl(Comp_Control_M,
        &Comp_Control_B.Comp_Freq_merged, &Comp_Control_B.Cooling_Plant_Ctrl,
        &Comp_Control_ConstB.Cooling_Plant_Ctrl,
        &Comp_Control_DW.Cooling_Plant_Ctrl);

      /* End of Outputs for SubSystem: '<S2>/Cooling_Plant_Ctrl' */
    } else {
      /*   */
      if (((Comp_Control_U.logsigs_comp[5] == 1) &&
           (Comp_Control_U.logsigs_comp[1] == 0) &&
           (Comp_Control_U.logsigs_comp[6] == 2)) ||
          ((Comp_Control_U.logsigs_comp[5] == 1) &&
           (Comp_Control_U.logsigs_comp[1] == 1) &&
           (Comp_Control_U.logsigs_comp[0] == 2) &&
           (Comp_Control_U.logsigs_comp[6] == 2))) {
        Comp_Control_DW.bitsForTID0.is_HeatCool = Comp_Control_IN_Heating_DHW;

        /* Outputs for Function Call SubSystem: '<S2>/Heating_DHW_Ctrl' */
        /* Inport: '<Root>/yref' incorporates:
         *  Inport: '<Root>/Temp_Vect'
         *  Inport: '<Root>/WT_WEx'
         */
        Comp_Control_Heating_DHW_Ctrl(Comp_Control_M, Comp_Control_U.yref,
          Comp_Control_U.WT_WEx[0], Comp_Control_U.Temp_Vect,
          Comp_Control_U.WT_WEx[1], &Comp_Control_B.Comp_Freq_merged,
          &Comp_Control_B.Heating_DHW_Ctrl, &Comp_Control_DW.Heating_DHW_Ctrl);

        /* End of Outputs for SubSystem: '<S2>/Heating_DHW_Ctrl' */
      } else {
        Comp_Control_DW.bitsForTID0.is_HeatCool = Comp_Control_IN_Exit_state;
      }
    }
  }

  /* End of Inport: '<Root>/logsigs_comp' */
}

/* Function for Chart: '<S2>/Final' */
static void Comp_Control_Defrost(void)
{
  /* Inport: '<Root>/logsigs_comp' */
  if (((Comp_Control_U.logsigs_comp[0] == 1) && (Comp_Control_U.logsigs_comp[6] ==
        0) && (Comp_Control_U.logsigs_comp[1] == 0) &&
       (Comp_Control_U.logsigs_comp[5] == 0)) || ((Comp_Control_U.logsigs_comp[0]
        == 1) && (Comp_Control_U.logsigs_comp[6] == 0) &&
       (Comp_Control_U.logsigs_comp[1] == 1)) || ((Comp_Control_U.logsigs_comp[5]
        == 1) && (Comp_Control_U.logsigs_comp[1] == 0) &&
       (Comp_Control_U.logsigs_comp[6] == 2)) || ((Comp_Control_U.logsigs_comp[5]
        == 1) && (Comp_Control_U.logsigs_comp[1] == 1) &&
       (Comp_Control_U.logsigs_comp[0] == 2) && (Comp_Control_U.logsigs_comp[6] ==
        2)) || ((Comp_Control_U.logsigs_comp[0] == 2) &&
                (Comp_Control_U.logsigs_comp[6] == 1) &&
                (Comp_Control_U.logsigs_comp[1] == 0) &&
                (Comp_Control_U.logsigs_comp[5] == 0)) ||
      ((Comp_Control_U.logsigs_comp[0] == 2) && (Comp_Control_U.logsigs_comp[6] ==
        1) && (Comp_Control_U.logsigs_comp[1] == 1))) {
    /* Outputs for Function Call SubSystem: '<S2>/Defrost_Ctrl' */
    /* Inport: '<Root>/Sts_4WV' */
    Comp_Control_Defrost_Ctrl(Comp_Control_M, Comp_Control_B.Delay,
      Comp_Control_U.Sts_4WV, &Comp_Control_B.Comp_Freq_merged,
      &Comp_Control_B.Defrost_Ctrl, &Comp_Control_DW.Defrost_Ctrl);

    /* End of Outputs for SubSystem: '<S2>/Defrost_Ctrl' */
    Comp_Control_DW.bitsForTID0.is_c7_Comp_Control = Comp_Control_IN_HeatCool;
    Comp_Co_enter_internal_HeatCool();
  } else {
    /*    */
    if (((Comp_Control_U.logsigs_comp[5] == 0) && (Comp_Control_U.logsigs_comp[0]
          == 0)) || ((Comp_Control_U.logsigs_comp[6] == 2) &&
                     (Comp_Control_U.logsigs_comp[5] == 0))) {
      /* Outputs for Function Call SubSystem: '<S2>/Defrost_Ctrl' */
      /* Inport: '<Root>/Sts_4WV' */
      Comp_Control_Defrost_Ctrl(Comp_Control_M, Comp_Control_B.Delay,
        Comp_Control_U.Sts_4WV, &Comp_Control_B.Comp_Freq_merged,
        &Comp_Control_B.Defrost_Ctrl, &Comp_Control_DW.Defrost_Ctrl);

      /* End of Outputs for SubSystem: '<S2>/Defrost_Ctrl' */
      Comp_Control_DW.bitsForTID0.is_c7_Comp_Control = Comp_Control_IN_OffAlarm;
      if ((Comp_Control_U.logsigs_comp[5] == 0) && (Comp_Control_U.logsigs_comp
           [0] == 0)) {
        Comp_Control_DW.bitsForTID0.is_OffAlarm = Comp_Control_IN_ThermoOff;

        /* Outputs for Function Call SubSystem: '<S2>/Off_ThermoOff' */
        Comp_Control_Off_ThermoOff(&Comp_Control_B.Comp_Freq_merged);

        /* End of Outputs for SubSystem: '<S2>/Off_ThermoOff' */
      } else if (Comp_Control_U.logsigs_comp[6] == 2) {
        Comp_Control_DW.bitsForTID0.is_OffAlarm =
          Comp_Contro_IN_Unit_Off_by_User;

        /* Outputs for Function Call SubSystem: '<S2>/Off_by_user' */
        Comp_Control_Off_by_user(&Comp_Control_B.Comp_Freq_merged);

        /* End of Outputs for SubSystem: '<S2>/Off_by_user' */
      } else {
        Comp_Control_DW.bitsForTID0.is_OffAlarm = Comp_Control_IN_Exit_state2;
      }
    } else {
      /* Outputs for Function Call SubSystem: '<S2>/Defrost_Ctrl' */
      /* Inport: '<Root>/Sts_4WV' */
      Comp_Control_Defrost_Ctrl(Comp_Control_M, Comp_Control_B.Delay,
        Comp_Control_U.Sts_4WV, &Comp_Control_B.Comp_Freq_merged,
        &Comp_Control_B.Defrost_Ctrl, &Comp_Control_DW.Defrost_Ctrl);

      /* End of Outputs for SubSystem: '<S2>/Defrost_Ctrl' */
    }
  }

  /* End of Inport: '<Root>/logsigs_comp' */
}

/* Model step function */
void Comp_Control_step(void)
{
  /* Delay: '<S2>/Delay' */
  Comp_Control_B.Delay = Comp_Control_DW.Delay_DSTATE;

  /* Chart: '<S2>/Final' incorporates:
   *  Inport: '<Root>/Temp_Vect'
   *  Inport: '<Root>/WT_WEx'
   *  Inport: '<Root>/logsigs_comp'
   *  Inport: '<Root>/yref'
   */
  if (Comp_Control_DW.bitsForTID0.is_active_c7_Comp_Control == 0U) {
    Comp_Control_DW.bitsForTID0.is_active_c7_Comp_Control = 1U;
    Comp_Control_DW.bitsForTID0.is_c7_Comp_Control =
      Comp_Contro_IN_Initial_OffAlarm;

    /* events should be inserted in the Drawio. cofficients to be created. Structure to be changed.
       Defrost_need = 0;   % switch to zero No need to defrost, switch to one if Defrost needed but not yet started, switch to two if it is in Defrost
       Sanit_need =0;       % switch to one to need to heat DHW, switch to Zero for no need to heat DHW
       Plant_need = 0;      % switch to one to need to heat the plant, two for need to cool, zero for no heat and no cool
       Season = 0;            % switch to zero for winter, switch to one for summer operation, to two for standby
       Plant_first = 0 ;       % switch to zero if DHW has the priority to the plant, switch to one for plant priority
       Alarm_must_off = 1;
       Alarm_force_stop_comp = 0;
       Defrost
       Defrost_need = 2; Sanit_need =0;  */
    Comp_Control_DW.Plant_need_cool = 2;

    /* HPL1 = 0;
       Def = (Defrost_need ==2) && (Alarm_must_off ==0) && (Alarm_force_stop_comp ==0);
       CondOffAlarm = AL1 || AL2 || TrmOff || UsrOff ;
       (Alarm_must_off ==1) || (Alarm_force_stop_comp ==1) || ((Sanit_need ==0) && (Plant_need ==0) && (Defrost_need ==0 ||  Defrost_need ==1)) || ((Season == 2) && (Defrost_need ==0 ||  Defrost_need ==1))
       CondHeatCool = HPL1 || HPL2 || HDHW1 || HDHW2 || CL1 || CL2 ;
       ((Plant_need==1) && (Season==0) && (Plant_first==0) && (Sanit_need==0) && ( (Defrost_need==0) || (Defrost_need ==1) )  )
       ((Plant_need==1) && (Season==0) && (Plant_first==1) && ( (Defrost_need==0) || (Defrost_need ==1) )  ) */
  } else {
    switch (Comp_Control_DW.bitsForTID0.is_c7_Comp_Control) {
     case Comp_Control_IN_Defrost:
      Comp_Control_Defrost();
      break;

     case Comp_Control_IN_HeatCool:
      /*    */
      if (((Comp_Control_U.logsigs_comp[5] == 0) &&
           (Comp_Control_U.logsigs_comp[0] == 0)) ||
          ((Comp_Control_U.logsigs_comp[6] == 2) &&
           (Comp_Control_U.logsigs_comp[5] == 0))) {
        switch (Comp_Control_DW.bitsForTID0.is_HeatCool) {
         case Comp_Control_IN_Cooling_Plant:
          /* Outputs for Function Call SubSystem: '<S2>/Cooling_Plant_Ctrl' */
          Comp_Control_Cooling_Plant_Ctrl(Comp_Control_M,
            &Comp_Control_B.Comp_Freq_merged, &Comp_Control_B.Cooling_Plant_Ctrl,
            &Comp_Control_ConstB.Cooling_Plant_Ctrl,
            &Comp_Control_DW.Cooling_Plant_Ctrl);

          /* End of Outputs for SubSystem: '<S2>/Cooling_Plant_Ctrl' */
          Comp_Control_DW.bitsForTID0.is_HeatCool =
            Comp_Control_IN_NO_ACTIVE_CHILD;
          break;

         case Comp_Control_IN_Heating_DHW:
          /* Outputs for Function Call SubSystem: '<S2>/Heating_DHW_Ctrl' */
          Comp_Control_Heating_DHW_Ctrl(Comp_Control_M, Comp_Control_U.yref,
            Comp_Control_U.WT_WEx[0], Comp_Control_U.Temp_Vect,
            Comp_Control_U.WT_WEx[1], &Comp_Control_B.Comp_Freq_merged,
            &Comp_Control_B.Heating_DHW_Ctrl, &Comp_Control_DW.Heating_DHW_Ctrl);

          /* End of Outputs for SubSystem: '<S2>/Heating_DHW_Ctrl' */
          Comp_Control_DW.bitsForTID0.is_HeatCool =
            Comp_Control_IN_NO_ACTIVE_CHILD;
          break;

         case Comp_Control_IN_Heating_Plant:
          /* Outputs for Function Call SubSystem: '<S2>/Heating_Plant_Ctrl' */
          Comp_Control_Heating_Plant_Ctrl(Comp_Control_M, Comp_Control_U.yref,
            Comp_Control_U.WT_WEx[0], Comp_Control_U.Temp_Vect,
            Comp_Control_U.WT_WEx[1], &Comp_Control_B.Comp_Freq_merged,
            &Comp_Control_B.Heating_Plant_Ctrl,
            &Comp_Control_DW.Heating_Plant_Ctrl);

          /* End of Outputs for SubSystem: '<S2>/Heating_Plant_Ctrl' */
          Comp_Control_DW.bitsForTID0.is_HeatCool =
            Comp_Control_IN_NO_ACTIVE_CHILD;
          break;

         default:
          Comp_Control_DW.bitsForTID0.is_HeatCool =
            Comp_Control_IN_NO_ACTIVE_CHILD;
          break;
        }

        Comp_Control_DW.bitsForTID0.is_c7_Comp_Control =
          Comp_Control_IN_OffAlarm;
        if ((Comp_Control_U.logsigs_comp[5] == 0) &&
            (Comp_Control_U.logsigs_comp[0] == 0)) {
          Comp_Control_DW.bitsForTID0.is_OffAlarm = Comp_Control_IN_ThermoOff;

          /* Outputs for Function Call SubSystem: '<S2>/Off_ThermoOff' */
          Comp_Control_Off_ThermoOff(&Comp_Control_B.Comp_Freq_merged);

          /* End of Outputs for SubSystem: '<S2>/Off_ThermoOff' */
        } else if (Comp_Control_U.logsigs_comp[6] == 2) {
          Comp_Control_DW.bitsForTID0.is_OffAlarm =
            Comp_Contro_IN_Unit_Off_by_User;

          /* Outputs for Function Call SubSystem: '<S2>/Off_by_user' */
          Comp_Control_Off_by_user(&Comp_Control_B.Comp_Freq_merged);

          /* End of Outputs for SubSystem: '<S2>/Off_by_user' */
        } else {
          Comp_Control_DW.bitsForTID0.is_OffAlarm = Comp_Control_IN_Exit_state2;
        }
      } else {
        /*   */
        switch (Comp_Control_DW.bitsForTID0.is_HeatCool) {
         case Comp_Control_IN_Cooling_Plant:
          if (((Comp_Control_U.logsigs_comp[0] == 1) &&
               (Comp_Control_U.logsigs_comp[6] == 0) &&
               (Comp_Control_U.logsigs_comp[1] == 0) &&
               (Comp_Control_U.logsigs_comp[5] == 0)) ||
              ((Comp_Control_U.logsigs_comp[0] == 1) &&
               (Comp_Control_U.logsigs_comp[6] == 0) &&
               (Comp_Control_U.logsigs_comp[1] == 1))) {
            /* Outputs for Function Call SubSystem: '<S2>/Cooling_Plant_Ctrl' */
            Comp_Control_Cooling_Plant_Ctrl(Comp_Control_M,
              &Comp_Control_B.Comp_Freq_merged,
              &Comp_Control_B.Cooling_Plant_Ctrl,
              &Comp_Control_ConstB.Cooling_Plant_Ctrl,
              &Comp_Control_DW.Cooling_Plant_Ctrl);

            /* End of Outputs for SubSystem: '<S2>/Cooling_Plant_Ctrl' */
            Comp_Control_DW.bitsForTID0.is_HeatCool =
              Comp_Control_IN_Heating_Plant;

            /* Outputs for Function Call SubSystem: '<S2>/Heating_Plant_Ctrl' */
            Comp_Control_Heating_Plant_Ctrl(Comp_Control_M, Comp_Control_U.yref,
              Comp_Control_U.WT_WEx[0], Comp_Control_U.Temp_Vect,
              Comp_Control_U.WT_WEx[1], &Comp_Control_B.Comp_Freq_merged,
              &Comp_Control_B.Heating_Plant_Ctrl,
              &Comp_Control_DW.Heating_Plant_Ctrl);

            /* End of Outputs for SubSystem: '<S2>/Heating_Plant_Ctrl' */
          } else {
            /*   */
            if (((Comp_Control_U.logsigs_comp[5] == 1) &&
                 (Comp_Control_U.logsigs_comp[1] == 0) &&
                 (Comp_Control_U.logsigs_comp[6] == 2)) ||
                ((Comp_Control_U.logsigs_comp[5] == 1) &&
                 (Comp_Control_U.logsigs_comp[1] == 1) &&
                 (Comp_Control_U.logsigs_comp[0] == 2) &&
                 (Comp_Control_U.logsigs_comp[6] == 2))) {
              /* Outputs for Function Call SubSystem: '<S2>/Cooling_Plant_Ctrl' */
              Comp_Control_Cooling_Plant_Ctrl(Comp_Control_M,
                &Comp_Control_B.Comp_Freq_merged,
                &Comp_Control_B.Cooling_Plant_Ctrl,
                &Comp_Control_ConstB.Cooling_Plant_Ctrl,
                &Comp_Control_DW.Cooling_Plant_Ctrl);

              /* End of Outputs for SubSystem: '<S2>/Cooling_Plant_Ctrl' */
              Comp_Control_DW.bitsForTID0.is_HeatCool =
                Comp_Control_IN_Heating_DHW;

              /* Outputs for Function Call SubSystem: '<S2>/Heating_DHW_Ctrl' */
              Comp_Control_Heating_DHW_Ctrl(Comp_Control_M, Comp_Control_U.yref,
                Comp_Control_U.WT_WEx[0], Comp_Control_U.Temp_Vect,
                Comp_Control_U.WT_WEx[1], &Comp_Control_B.Comp_Freq_merged,
                &Comp_Control_B.Heating_DHW_Ctrl,
                &Comp_Control_DW.Heating_DHW_Ctrl);

              /* End of Outputs for SubSystem: '<S2>/Heating_DHW_Ctrl' */
            } else if (((Comp_Control_U.logsigs_comp[0] != 2) ||
                        (Comp_Control_U.logsigs_comp[6] != 1) ||
                        (Comp_Control_U.logsigs_comp[1] != 0) ||
                        (Comp_Control_U.logsigs_comp[5] != 0)) &&
                       ((Comp_Control_U.logsigs_comp[0] != 2) ||
                        (Comp_Control_U.logsigs_comp[6] != 1) ||
                        (Comp_Control_U.logsigs_comp[1] != 1)) &&
                       ((Comp_Control_U.logsigs_comp[5] != 1) ||
                        (Comp_Control_U.logsigs_comp[1] != 0) ||
                        (Comp_Control_U.logsigs_comp[6] != 2)) &&
                       ((Comp_Control_U.logsigs_comp[5] != 1) ||
                        (Comp_Control_U.logsigs_comp[1] != 1) ||
                        (Comp_Control_U.logsigs_comp[0] != 2) ||
                        (Comp_Control_U.logsigs_comp[6] != 2)) &&
                       ((Comp_Control_U.logsigs_comp[0] != 1) ||
                        (Comp_Control_U.logsigs_comp[6] != 0) ||
                        (Comp_Control_U.logsigs_comp[1] != 0) ||
                        (Comp_Control_U.logsigs_comp[5] != 0)) &&
                       ((Comp_Control_U.logsigs_comp[0] != 1) ||
                        (Comp_Control_U.logsigs_comp[6] != 0) ||
                        (Comp_Control_U.logsigs_comp[1] != 1))) {
              /* Outputs for Function Call SubSystem: '<S2>/Cooling_Plant_Ctrl' */
              Comp_Control_Cooling_Plant_Ctrl(Comp_Control_M,
                &Comp_Control_B.Comp_Freq_merged,
                &Comp_Control_B.Cooling_Plant_Ctrl,
                &Comp_Control_ConstB.Cooling_Plant_Ctrl,
                &Comp_Control_DW.Cooling_Plant_Ctrl);

              /* End of Outputs for SubSystem: '<S2>/Cooling_Plant_Ctrl' */
              Comp_Control_DW.bitsForTID0.is_HeatCool =
                Comp_Control_IN_Exit_state;
            } else {
              /* Outputs for Function Call SubSystem: '<S2>/Cooling_Plant_Ctrl' */
              Comp_Control_Cooling_Plant_Ctrl(Comp_Control_M,
                &Comp_Control_B.Comp_Freq_merged,
                &Comp_Control_B.Cooling_Plant_Ctrl,
                &Comp_Control_ConstB.Cooling_Plant_Ctrl,
                &Comp_Control_DW.Cooling_Plant_Ctrl);

              /* End of Outputs for SubSystem: '<S2>/Cooling_Plant_Ctrl' */
            }
          }
          break;

         case Comp_Control_IN_Exit_state:
          Comp_Control_DW.bitsForTID0.is_HeatCool =
            Comp_Control_IN_NO_ACTIVE_CHILD;
          Comp_Co_enter_internal_HeatCool();
          break;

         case Comp_Control_IN_Heating_DHW:
          /*   */
          if (((Comp_Control_U.logsigs_comp[0] == 2) &&
               (Comp_Control_U.logsigs_comp[6] == 1) &&
               (Comp_Control_U.logsigs_comp[1] == 0) &&
               (Comp_Control_U.logsigs_comp[5] == 0)) ||
              ((Comp_Control_U.logsigs_comp[0] == 2) &&
               (Comp_Control_U.logsigs_comp[6] == 1) &&
               (Comp_Control_U.logsigs_comp[1] == 1))) {
            /* Outputs for Function Call SubSystem: '<S2>/Heating_DHW_Ctrl' */
            Comp_Control_Heating_DHW_Ctrl(Comp_Control_M, Comp_Control_U.yref,
              Comp_Control_U.WT_WEx[0], Comp_Control_U.Temp_Vect,
              Comp_Control_U.WT_WEx[1], &Comp_Control_B.Comp_Freq_merged,
              &Comp_Control_B.Heating_DHW_Ctrl,
              &Comp_Control_DW.Heating_DHW_Ctrl);

            /* End of Outputs for SubSystem: '<S2>/Heating_DHW_Ctrl' */
            Comp_Control_DW.bitsForTID0.is_HeatCool =
              Comp_Control_IN_Cooling_Plant;

            /* Outputs for Function Call SubSystem: '<S2>/Cooling_Plant_Ctrl' */
            Comp_Control_Cooling_Plant_Ctrl(Comp_Control_M,
              &Comp_Control_B.Comp_Freq_merged,
              &Comp_Control_B.Cooling_Plant_Ctrl,
              &Comp_Control_ConstB.Cooling_Plant_Ctrl,
              &Comp_Control_DW.Cooling_Plant_Ctrl);

            /* End of Outputs for SubSystem: '<S2>/Cooling_Plant_Ctrl' */
          } else if (((Comp_Control_U.logsigs_comp[0] == 1) &&
                      (Comp_Control_U.logsigs_comp[6] == 0) &&
                      (Comp_Control_U.logsigs_comp[1] == 0) &&
                      (Comp_Control_U.logsigs_comp[5] == 0)) ||
                     ((Comp_Control_U.logsigs_comp[0] == 1) &&
                      (Comp_Control_U.logsigs_comp[6] == 0) &&
                      (Comp_Control_U.logsigs_comp[1] == 1))) {
            /* Outputs for Function Call SubSystem: '<S2>/Heating_DHW_Ctrl' */
            Comp_Control_Heating_DHW_Ctrl(Comp_Control_M, Comp_Control_U.yref,
              Comp_Control_U.WT_WEx[0], Comp_Control_U.Temp_Vect,
              Comp_Control_U.WT_WEx[1], &Comp_Control_B.Comp_Freq_merged,
              &Comp_Control_B.Heating_DHW_Ctrl,
              &Comp_Control_DW.Heating_DHW_Ctrl);

            /* End of Outputs for SubSystem: '<S2>/Heating_DHW_Ctrl' */
            Comp_Control_DW.bitsForTID0.is_HeatCool =
              Comp_Control_IN_Heating_Plant;

            /* Outputs for Function Call SubSystem: '<S2>/Heating_Plant_Ctrl' */
            Comp_Control_Heating_Plant_Ctrl(Comp_Control_M, Comp_Control_U.yref,
              Comp_Control_U.WT_WEx[0], Comp_Control_U.Temp_Vect,
              Comp_Control_U.WT_WEx[1], &Comp_Control_B.Comp_Freq_merged,
              &Comp_Control_B.Heating_Plant_Ctrl,
              &Comp_Control_DW.Heating_Plant_Ctrl);

            /* End of Outputs for SubSystem: '<S2>/Heating_Plant_Ctrl' */
          } else if (((Comp_Control_U.logsigs_comp[0] != 2) ||
                      (Comp_Control_U.logsigs_comp[6] != 1) ||
                      (Comp_Control_U.logsigs_comp[1] != 0) ||
                      (Comp_Control_U.logsigs_comp[5] != 0)) &&
                     ((Comp_Control_U.logsigs_comp[0] != 2) ||
                      (Comp_Control_U.logsigs_comp[6] != 1) ||
                      (Comp_Control_U.logsigs_comp[1] != 1)) &&
                     ((Comp_Control_U.logsigs_comp[5] != 1) ||
                      (Comp_Control_U.logsigs_comp[1] != 0) ||
                      (Comp_Control_U.logsigs_comp[6] != 2)) &&
                     ((Comp_Control_U.logsigs_comp[5] != 1) ||
                      (Comp_Control_U.logsigs_comp[1] != 1) ||
                      (Comp_Control_U.logsigs_comp[0] != 2) ||
                      (Comp_Control_U.logsigs_comp[6] != 2)) &&
                     ((Comp_Control_U.logsigs_comp[0] != 1) ||
                      (Comp_Control_U.logsigs_comp[6] != 0) ||
                      (Comp_Control_U.logsigs_comp[1] != 0) ||
                      (Comp_Control_U.logsigs_comp[5] != 0)) &&
                     ((Comp_Control_U.logsigs_comp[0] != 1) ||
                      (Comp_Control_U.logsigs_comp[6] != 0) ||
                      (Comp_Control_U.logsigs_comp[1] != 1))) {
            /* Outputs for Function Call SubSystem: '<S2>/Heating_DHW_Ctrl' */
            Comp_Control_Heating_DHW_Ctrl(Comp_Control_M, Comp_Control_U.yref,
              Comp_Control_U.WT_WEx[0], Comp_Control_U.Temp_Vect,
              Comp_Control_U.WT_WEx[1], &Comp_Control_B.Comp_Freq_merged,
              &Comp_Control_B.Heating_DHW_Ctrl,
              &Comp_Control_DW.Heating_DHW_Ctrl);

            /* End of Outputs for SubSystem: '<S2>/Heating_DHW_Ctrl' */
            Comp_Control_DW.bitsForTID0.is_HeatCool = Comp_Control_IN_Exit_state;
          } else {
            /* Outputs for Function Call SubSystem: '<S2>/Heating_DHW_Ctrl' */
            Comp_Control_Heating_DHW_Ctrl(Comp_Control_M, Comp_Control_U.yref,
              Comp_Control_U.WT_WEx[0], Comp_Control_U.Temp_Vect,
              Comp_Control_U.WT_WEx[1], &Comp_Control_B.Comp_Freq_merged,
              &Comp_Control_B.Heating_DHW_Ctrl,
              &Comp_Control_DW.Heating_DHW_Ctrl);

            /* End of Outputs for SubSystem: '<S2>/Heating_DHW_Ctrl' */
          }
          break;

         default:
          /* case IN_Heating_Plant: */
          /*   */
          if (((Comp_Control_U.logsigs_comp[5] == 1) &&
               (Comp_Control_U.logsigs_comp[1] == 0) &&
               (Comp_Control_U.logsigs_comp[6] == 2)) ||
              ((Comp_Control_U.logsigs_comp[5] == 1) &&
               (Comp_Control_U.logsigs_comp[1] == 1) &&
               (Comp_Control_U.logsigs_comp[0] == 2) &&
               (Comp_Control_U.logsigs_comp[6] == 2))) {
            /* Outputs for Function Call SubSystem: '<S2>/Heating_Plant_Ctrl' */
            Comp_Control_Heating_Plant_Ctrl(Comp_Control_M, Comp_Control_U.yref,
              Comp_Control_U.WT_WEx[0], Comp_Control_U.Temp_Vect,
              Comp_Control_U.WT_WEx[1], &Comp_Control_B.Comp_Freq_merged,
              &Comp_Control_B.Heating_Plant_Ctrl,
              &Comp_Control_DW.Heating_Plant_Ctrl);

            /* End of Outputs for SubSystem: '<S2>/Heating_Plant_Ctrl' */
            Comp_Control_DW.bitsForTID0.is_HeatCool =
              Comp_Control_IN_Heating_DHW;

            /* Outputs for Function Call SubSystem: '<S2>/Heating_DHW_Ctrl' */
            Comp_Control_Heating_DHW_Ctrl(Comp_Control_M, Comp_Control_U.yref,
              Comp_Control_U.WT_WEx[0], Comp_Control_U.Temp_Vect,
              Comp_Control_U.WT_WEx[1], &Comp_Control_B.Comp_Freq_merged,
              &Comp_Control_B.Heating_DHW_Ctrl,
              &Comp_Control_DW.Heating_DHW_Ctrl);

            /* End of Outputs for SubSystem: '<S2>/Heating_DHW_Ctrl' */
          } else {
            /*   */
            if (((Comp_Control_U.logsigs_comp[0] ==
                  Comp_Control_DW.Plant_need_cool) &&
                 (Comp_Control_U.logsigs_comp[6] == 1) &&
                 (Comp_Control_U.logsigs_comp[1] == 0) &&
                 (Comp_Control_U.logsigs_comp[5] == 0)) ||
                ((Comp_Control_U.logsigs_comp[0] == 2) &&
                 (Comp_Control_U.logsigs_comp[6] == 1) &&
                 (Comp_Control_U.logsigs_comp[1] == 1))) {
              /* Outputs for Function Call SubSystem: '<S2>/Heating_Plant_Ctrl' */
              Comp_Control_Heating_Plant_Ctrl(Comp_Control_M,
                Comp_Control_U.yref, Comp_Control_U.WT_WEx[0],
                Comp_Control_U.Temp_Vect, Comp_Control_U.WT_WEx[1],
                &Comp_Control_B.Comp_Freq_merged,
                &Comp_Control_B.Heating_Plant_Ctrl,
                &Comp_Control_DW.Heating_Plant_Ctrl);

              /* End of Outputs for SubSystem: '<S2>/Heating_Plant_Ctrl' */
              Comp_Control_DW.bitsForTID0.is_HeatCool =
                Comp_Control_IN_Cooling_Plant;

              /* Outputs for Function Call SubSystem: '<S2>/Cooling_Plant_Ctrl' */
              Comp_Control_Cooling_Plant_Ctrl(Comp_Control_M,
                &Comp_Control_B.Comp_Freq_merged,
                &Comp_Control_B.Cooling_Plant_Ctrl,
                &Comp_Control_ConstB.Cooling_Plant_Ctrl,
                &Comp_Control_DW.Cooling_Plant_Ctrl);

              /* End of Outputs for SubSystem: '<S2>/Cooling_Plant_Ctrl' */
            } else if (((Comp_Control_U.logsigs_comp[0] !=
                         Comp_Control_DW.Plant_need_cool) ||
                        (Comp_Control_U.logsigs_comp[6] != 1) ||
                        (Comp_Control_U.logsigs_comp[1] != 0) ||
                        (Comp_Control_U.logsigs_comp[5] != 0)) &&
                       ((Comp_Control_U.logsigs_comp[0] !=
                         Comp_Control_DW.Plant_need_cool) ||
                        (Comp_Control_U.logsigs_comp[6] != 1) ||
                        (Comp_Control_U.logsigs_comp[1] != 1)) &&
                       ((Comp_Control_U.logsigs_comp[5] !=
                         Comp_Control_DW.Plant_need_heat) ||
                        (Comp_Control_U.logsigs_comp[1] != 0) ||
                        (Comp_Control_U.logsigs_comp[6] != 2)) &&
                       ((Comp_Control_U.logsigs_comp[5] !=
                         Comp_Control_DW.Plant_need_heat) ||
                        (Comp_Control_U.logsigs_comp[1] != 1) ||
                        (Comp_Control_U.logsigs_comp[0] != 2) ||
                        (Comp_Control_U.logsigs_comp[6] != 2)) &&
                       ((Comp_Control_U.logsigs_comp[0] !=
                         Comp_Control_DW.Plant_need_heat) ||
                        (Comp_Control_U.logsigs_comp[6] != 0) ||
                        (Comp_Control_U.logsigs_comp[1] != 0) ||
                        (Comp_Control_U.logsigs_comp[5] != 0)) &&
                       ((Comp_Control_U.logsigs_comp[0] !=
                         Comp_Control_DW.Plant_need_heat) ||
                        (Comp_Control_U.logsigs_comp[6] != 0) ||
                        (Comp_Control_U.logsigs_comp[1] != 1))) {
              /* Outputs for Function Call SubSystem: '<S2>/Heating_Plant_Ctrl' */
              Comp_Control_Heating_Plant_Ctrl(Comp_Control_M,
                Comp_Control_U.yref, Comp_Control_U.WT_WEx[0],
                Comp_Control_U.Temp_Vect, Comp_Control_U.WT_WEx[1],
                &Comp_Control_B.Comp_Freq_merged,
                &Comp_Control_B.Heating_Plant_Ctrl,
                &Comp_Control_DW.Heating_Plant_Ctrl);

              /* End of Outputs for SubSystem: '<S2>/Heating_Plant_Ctrl' */
              Comp_Control_DW.bitsForTID0.is_HeatCool =
                Comp_Control_IN_Exit_state;
            } else {
              /* Outputs for Function Call SubSystem: '<S2>/Heating_Plant_Ctrl' */
              Comp_Control_Heating_Plant_Ctrl(Comp_Control_M,
                Comp_Control_U.yref, Comp_Control_U.WT_WEx[0],
                Comp_Control_U.Temp_Vect, Comp_Control_U.WT_WEx[1],
                &Comp_Control_B.Comp_Freq_merged,
                &Comp_Control_B.Heating_Plant_Ctrl,
                &Comp_Control_DW.Heating_Plant_Ctrl);

              /* End of Outputs for SubSystem: '<S2>/Heating_Plant_Ctrl' */
            }
          }
          break;
        }
      }
      break;

     case Comp_Contro_IN_Initial_OffAlarm:
      /*    */
      if (((Comp_Control_U.logsigs_comp[5] == 0) &&
           (Comp_Control_U.logsigs_comp[0] == 0)) ||
          ((Comp_Control_U.logsigs_comp[6] == 2) &&
           (Comp_Control_U.logsigs_comp[5] == 0))) {
        Comp_Control_DW.bitsForTID0.is_c7_Comp_Control =
          Comp_Control_IN_OffAlarm;
        if ((Comp_Control_U.logsigs_comp[5] == 0) &&
            (Comp_Control_U.logsigs_comp[0] == 0)) {
          Comp_Control_DW.bitsForTID0.is_OffAlarm = Comp_Control_IN_ThermoOff;

          /* Outputs for Function Call SubSystem: '<S2>/Off_ThermoOff' */
          Comp_Control_Off_ThermoOff(&Comp_Control_B.Comp_Freq_merged);

          /* End of Outputs for SubSystem: '<S2>/Off_ThermoOff' */
        } else if (Comp_Control_U.logsigs_comp[6] == 2) {
          Comp_Control_DW.bitsForTID0.is_OffAlarm =
            Comp_Contro_IN_Unit_Off_by_User;

          /* Outputs for Function Call SubSystem: '<S2>/Off_by_user' */
          Comp_Control_Off_by_user(&Comp_Control_B.Comp_Freq_merged);

          /* End of Outputs for SubSystem: '<S2>/Off_by_user' */
        } else {
          Comp_Control_DW.bitsForTID0.is_OffAlarm = Comp_Control_IN_Exit_state2;
        }
      } else {
        /*   */
        if (((Comp_Control_U.logsigs_comp[0] == 1) &&
             (Comp_Control_U.logsigs_comp[6] == 0) &&
             (Comp_Control_U.logsigs_comp[1] == 0) &&
             (Comp_Control_U.logsigs_comp[5] == 0)) ||
            ((Comp_Control_U.logsigs_comp[0] == 1) &&
             (Comp_Control_U.logsigs_comp[6] == 0) &&
             (Comp_Control_U.logsigs_comp[1] == 1)) ||
            ((Comp_Control_U.logsigs_comp[5] == 1) &&
             (Comp_Control_U.logsigs_comp[1] == 0) &&
             (Comp_Control_U.logsigs_comp[6] == 2)) ||
            ((Comp_Control_U.logsigs_comp[5] == 1) &&
             (Comp_Control_U.logsigs_comp[1] == 1) &&
             (Comp_Control_U.logsigs_comp[0] == 2) &&
             (Comp_Control_U.logsigs_comp[6] == 2)) ||
            ((Comp_Control_U.logsigs_comp[0] == 2) &&
             (Comp_Control_U.logsigs_comp[6] == 1) &&
             (Comp_Control_U.logsigs_comp[1] == 0) &&
             (Comp_Control_U.logsigs_comp[5] == 0)) ||
            ((Comp_Control_U.logsigs_comp[0] == 2) &&
             (Comp_Control_U.logsigs_comp[6] == 1) &&
             (Comp_Control_U.logsigs_comp[1] == 1))) {
          Comp_Control_DW.bitsForTID0.is_c7_Comp_Control =
            Comp_Control_IN_HeatCool;
          Comp_Co_enter_internal_HeatCool();
        }
      }
      break;

     default:
      /* case IN_OffAlarm: */
      if (((Comp_Control_U.logsigs_comp[0] == 1) &&
           (Comp_Control_U.logsigs_comp[6] == 0) &&
           (Comp_Control_U.logsigs_comp[1] == 0) &&
           (Comp_Control_U.logsigs_comp[5] == 0)) ||
          ((Comp_Control_U.logsigs_comp[0] == 1) &&
           (Comp_Control_U.logsigs_comp[6] == 0) &&
           (Comp_Control_U.logsigs_comp[1] == 1)) ||
          ((Comp_Control_U.logsigs_comp[5] == 1) &&
           (Comp_Control_U.logsigs_comp[1] == 0) &&
           (Comp_Control_U.logsigs_comp[6] == 2)) ||
          ((Comp_Control_U.logsigs_comp[5] == 1) &&
           (Comp_Control_U.logsigs_comp[1] == 1) &&
           (Comp_Control_U.logsigs_comp[0] == 2) &&
           (Comp_Control_U.logsigs_comp[6] == 2)) ||
          ((Comp_Control_U.logsigs_comp[0] == 2) &&
           (Comp_Control_U.logsigs_comp[6] == 1) &&
           (Comp_Control_U.logsigs_comp[1] == 0) &&
           (Comp_Control_U.logsigs_comp[5] == 0)) ||
          ((Comp_Control_U.logsigs_comp[0] == 2) &&
           (Comp_Control_U.logsigs_comp[6] == 1) &&
           (Comp_Control_U.logsigs_comp[1] == 1))) {
        switch (Comp_Control_DW.bitsForTID0.is_OffAlarm) {
         case Comp_Control_IN_ThermoOff:
          /* Outputs for Function Call SubSystem: '<S2>/Off_ThermoOff' */
          Comp_Control_Off_ThermoOff(&Comp_Control_B.Comp_Freq_merged);

          /* End of Outputs for SubSystem: '<S2>/Off_ThermoOff' */
          Comp_Control_DW.bitsForTID0.is_OffAlarm =
            Comp_Control_IN_NO_ACTIVE_CHILD;
          break;

         case Comp_Contr_IN_Unit_Off_by_Alarm:
          /* Outputs for Function Call SubSystem: '<S2>/Off_by_Alarm' */
          Comp_Control_Off_by_Alarm(&Comp_Control_B.Comp_Freq_merged);

          /* End of Outputs for SubSystem: '<S2>/Off_by_Alarm' */
          Comp_Control_DW.bitsForTID0.is_OffAlarm =
            Comp_Control_IN_NO_ACTIVE_CHILD;
          break;

         default:
          Comp_Control_DW.bitsForTID0.is_OffAlarm =
            Comp_Control_IN_NO_ACTIVE_CHILD;
          break;
        }

        Comp_Control_DW.bitsForTID0.is_c7_Comp_Control =
          Comp_Control_IN_HeatCool;
        Comp_Co_enter_internal_HeatCool();
      } else {
        switch (Comp_Control_DW.bitsForTID0.is_OffAlarm) {
         case Comp_Control_IN_Exit_state2:
          Comp_Control_DW.bitsForTID0.is_OffAlarm =
            Comp_Control_IN_NO_ACTIVE_CHILD;
          if ((Comp_Control_U.logsigs_comp[5] == 0) &&
              (Comp_Control_U.logsigs_comp[0] == 0)) {
            Comp_Control_DW.bitsForTID0.is_OffAlarm = Comp_Control_IN_ThermoOff;

            /* Outputs for Function Call SubSystem: '<S2>/Off_ThermoOff' */
            Comp_Control_Off_ThermoOff(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_ThermoOff' */
          } else if (Comp_Control_U.logsigs_comp[6] == 2) {
            Comp_Control_DW.bitsForTID0.is_OffAlarm =
              Comp_Contro_IN_Unit_Off_by_User;

            /* Outputs for Function Call SubSystem: '<S2>/Off_by_user' */
            Comp_Control_Off_by_user(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_by_user' */
          } else {
            Comp_Control_DW.bitsForTID0.is_OffAlarm =
              Comp_Control_IN_Exit_state2;
          }
          break;

         case Comp_Control_IN_ThermoOff:
          if ((Comp_Control_U.logsigs_comp[6] != 2) &&
              ((Comp_Control_U.logsigs_comp[5] != 0) ||
               (Comp_Control_U.logsigs_comp[0] != 0))) {
            /* Outputs for Function Call SubSystem: '<S2>/Off_ThermoOff' */
            Comp_Control_Off_ThermoOff(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_ThermoOff' */
            Comp_Control_DW.bitsForTID0.is_OffAlarm =
              Comp_Control_IN_Exit_state2;
          } else if (Comp_Control_U.logsigs_comp[6] == 2) {
            /* Outputs for Function Call SubSystem: '<S2>/Off_ThermoOff' */
            Comp_Control_Off_ThermoOff(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_ThermoOff' */
            Comp_Control_DW.bitsForTID0.is_OffAlarm =
              Comp_Contro_IN_Unit_Off_by_User;

            /* Outputs for Function Call SubSystem: '<S2>/Off_by_user' */
            Comp_Control_Off_by_user(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_by_user' */
          } else {
            /* Outputs for Function Call SubSystem: '<S2>/Off_ThermoOff' */
            Comp_Control_Off_ThermoOff(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_ThermoOff' */
          }
          break;

         case Comp_Contr_IN_Unit_Off_by_Alarm:
          if ((Comp_Control_U.logsigs_comp[6] != 2) &&
              ((Comp_Control_U.logsigs_comp[5] != 0) ||
               (Comp_Control_U.logsigs_comp[0] != 0))) {
            /* Outputs for Function Call SubSystem: '<S2>/Off_by_Alarm' */
            Comp_Control_Off_by_Alarm(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_by_Alarm' */
            Comp_Control_DW.bitsForTID0.is_OffAlarm =
              Comp_Control_IN_Exit_state2;
          } else if ((Comp_Control_U.logsigs_comp[5] == 0) &&
                     (Comp_Control_U.logsigs_comp[0] == 0)) {
            /* Outputs for Function Call SubSystem: '<S2>/Off_by_Alarm' */
            Comp_Control_Off_by_Alarm(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_by_Alarm' */
            Comp_Control_DW.bitsForTID0.is_OffAlarm = Comp_Control_IN_ThermoOff;

            /* Outputs for Function Call SubSystem: '<S2>/Off_ThermoOff' */
            Comp_Control_Off_ThermoOff(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_ThermoOff' */
          } else if (Comp_Control_U.logsigs_comp[6] == 2) {
            /* Outputs for Function Call SubSystem: '<S2>/Off_by_Alarm' */
            Comp_Control_Off_by_Alarm(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_by_Alarm' */
            Comp_Control_DW.bitsForTID0.is_OffAlarm =
              Comp_Contro_IN_Unit_Off_by_User;

            /* Outputs for Function Call SubSystem: '<S2>/Off_by_user' */
            Comp_Control_Off_by_user(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_by_user' */
          } else {
            /* Outputs for Function Call SubSystem: '<S2>/Off_by_Alarm' */
            Comp_Control_Off_by_Alarm(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_by_Alarm' */
          }
          break;

         default:
          /* case IN_Unit_Off_by_User: */
          if ((Comp_Control_U.logsigs_comp[6] != 2) &&
              ((Comp_Control_U.logsigs_comp[5] != 0) ||
               (Comp_Control_U.logsigs_comp[0] != 0))) {
            Comp_Control_DW.bitsForTID0.is_OffAlarm =
              Comp_Control_IN_Exit_state2;
          } else if ((Comp_Control_U.logsigs_comp[5] == 0) &&
                     (Comp_Control_U.logsigs_comp[0] == 0)) {
            Comp_Control_DW.bitsForTID0.is_OffAlarm = Comp_Control_IN_ThermoOff;

            /* Outputs for Function Call SubSystem: '<S2>/Off_ThermoOff' */
            Comp_Control_Off_ThermoOff(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_ThermoOff' */
          } else {
            /* Outputs for Function Call SubSystem: '<S2>/Off_by_user' */
            Comp_Control_Off_by_user(&Comp_Control_B.Comp_Freq_merged);

            /* End of Outputs for SubSystem: '<S2>/Off_by_user' */
          }
          break;
        }
      }
      break;
    }
  }

  /* End of Chart: '<S2>/Final' */

  /* Outport: '<Root>/U_Control' */
  Comp_Control_Y.U_Control = Comp_Control_B.Comp_Freq_merged;

  /* Update for Delay: '<S2>/Delay' */
  Comp_Control_DW.Delay_DSTATE = Comp_Control_B.Comp_Freq_merged;

  /* Matfile logging */
  rt_UpdateTXYLogVars(Comp_Control_M->rtwLogInfo,
                      (&Comp_Control_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.05s, 0.0s] */
    if ((rtmGetTFinal(Comp_Control_M)!=-1) &&
        !((rtmGetTFinal(Comp_Control_M)-Comp_Control_M->Timing.taskTime0) >
          Comp_Control_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(Comp_Control_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Comp_Control_M->Timing.clockTick0)) {
    ++Comp_Control_M->Timing.clockTickH0;
  }

  Comp_Control_M->Timing.taskTime0 = Comp_Control_M->Timing.clockTick0 *
    Comp_Control_M->Timing.stepSize0 + Comp_Control_M->Timing.clockTickH0 *
    Comp_Control_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void Comp_Control_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Comp_Control_M, 0,
                sizeof(RT_MODEL_Comp_Control_T));
  rtmSetTFinal(Comp_Control_M, 100.0);
  Comp_Control_M->Timing.stepSize0 = 0.05;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    Comp_Control_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(Comp_Control_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(Comp_Control_M->rtwLogInfo, (NULL));
    rtliSetLogT(Comp_Control_M->rtwLogInfo, "tout");
    rtliSetLogX(Comp_Control_M->rtwLogInfo, "");
    rtliSetLogXFinal(Comp_Control_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(Comp_Control_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(Comp_Control_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(Comp_Control_M->rtwLogInfo, 0);
    rtliSetLogDecimation(Comp_Control_M->rtwLogInfo, 1);
    rtliSetLogY(Comp_Control_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(Comp_Control_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(Comp_Control_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &Comp_Control_B), 0,
                sizeof(B_Comp_Control_T));

  /* states (dwork) */
  (void) memset((void *)&Comp_Control_DW, 0,
                sizeof(DW_Comp_Control_T));

  /* external inputs */
  (void)memset(&Comp_Control_U, 0, sizeof(ExtU_Comp_Control_T));

  /* external outputs */
  (void) memset((void *)&Comp_Control_Y, 0,
                sizeof(ExtY_Comp_Control_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(Comp_Control_M->rtwLogInfo, 0.0, rtmGetTFinal
    (Comp_Control_M), Comp_Control_M->Timing.stepSize0, (&rtmGetErrorStatus
    (Comp_Control_M)));

  {
    int32_T i;

    /* SetupRuntimeResources for Chart: '<S2>/Final' incorporates:
     *  SubSystem: '<S2>/Heating_DHW_Ctrl'
     */
    /* SetupRuntimeResources for Inport: '<Root>/Temp_Vect' */
    Comp__Heating_DHW_Ctrl_SetupRTR(Comp_Control_M,
      &Comp_Control_DW.Heating_DHW_Ctrl);

    /* SetupRuntimeResources for Chart: '<S2>/Final' incorporates:
     *  SubSystem: '<S2>/Heating_Plant_Ctrl'
     */
    /* SetupRuntimeResources for Inport: '<Root>/WT_WEx' */
    Com_Heating_Plant_Ctrl_SetupRTR(Comp_Control_M,
      &Comp_Control_DW.Heating_Plant_Ctrl);

    /* SetupRuntimeResources for Chart: '<S2>/Final' incorporates:
     *  SubSystem: '<S2>/Cooling_Plant_Ctrl'
     */
    Com_Cooling_Plant_Ctrl_SetupRTR(Comp_Control_M,
      &Comp_Control_DW.Cooling_Plant_Ctrl);

    /* ConstCode for Outport: '<Root>/Ev' */
    for (i = 0; i < 7; i++) {
      Comp_Control_Y.Ev[i] = 0.0;
    }

    /* End of ConstCode for Outport: '<Root>/Ev' */
  }

  /* InitializeConditions for Delay: '<S2>/Delay' */
  Comp_Control_DW.Delay_DSTATE = 0.0;
  Comp_Control_DW.bitsForTID0.is_HeatCool = Comp_Control_IN_NO_ACTIVE_CHILD;
  Comp_Control_DW.bitsForTID0.is_OffAlarm = Comp_Control_IN_NO_ACTIVE_CHILD;
  Comp_Control_DW.bitsForTID0.is_active_c7_Comp_Control = 0U;
  Comp_Control_DW.bitsForTID0.is_c7_Comp_Control =
    Comp_Control_IN_NO_ACTIVE_CHILD;
  Comp_Control_DW.Plant_need_cool = 0;
  Comp_Control_DW.Plant_need_heat = 0;

  /* SystemInitialize for Chart: '<S2>/Final' incorporates:
   *  SubSystem: '<S2>/Heating_DHW_Ctrl'
   */
  Comp_Cont_Heating_DHW_Ctrl_Init(&Comp_Control_DW.Heating_DHW_Ctrl);

  /* SystemInitialize for Chart: '<S2>/Final' incorporates:
   *  SubSystem: '<S2>/Heating_Plant_Ctrl'
   */
  Comp_Co_Heating_Plant_Ctrl_Init(&Comp_Control_DW.Heating_Plant_Ctrl);

  /* SystemInitialize for Chart: '<S2>/Final' incorporates:
   *  SubSystem: '<S2>/Cooling_Plant_Ctrl'
   */
  Comp_Co_Cooling_Plant_Ctrl_Init(&Comp_Control_DW.Cooling_Plant_Ctrl);

  /* SystemInitialize for Chart: '<S2>/Final' incorporates:
   *  SubSystem: '<S2>/Defrost_Ctrl'
   */
  Comp_Control_Defrost_Ctrl_Init(&Comp_Control_DW.Defrost_Ctrl);

  /* SystemInitialize for Merge: '<S2>/Merge' */
  Comp_Control_B.Comp_Freq_merged = 0.0;

  /* SystemInitialize for Outport: '<Root>/U_Control' */
  Comp_Control_Y.U_Control = Comp_Control_B.Comp_Freq_merged;

  /* Enable for Chart: '<S2>/Final' incorporates:
   *  SubSystem: '<S2>/Heating_DHW_Ctrl'
   */
  Comp_Co_Heating_DHW_Ctrl_Enable(&Comp_Control_DW.Heating_DHW_Ctrl);

  /* Enable for Chart: '<S2>/Final' incorporates:
   *  SubSystem: '<S2>/Heating_Plant_Ctrl'
   */
  Comp__Heating_Plant_Ctrl_Enable(&Comp_Control_DW.Heating_Plant_Ctrl);

  /* Enable for Chart: '<S2>/Final' incorporates:
   *  SubSystem: '<S2>/Defrost_Ctrl'
   */
  Comp_Contro_Defrost_Ctrl_Enable(&Comp_Control_DW.Defrost_Ctrl);
}

/* Model terminate function */
void Comp_Control_terminate(void)
{
  /* (no terminate code required) */
}
