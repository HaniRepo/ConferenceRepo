


Compfreq_min    = 0;   Compfreq_Max = 94;  % Min Max comp Freq -- ManipulatedVariables
WTWexOut_min = -10; WTWexOut_max =  80;  % Min and Max Water Temp in WEx outlet
ref_cnst = 1; % 0 or 1 or 2


load mpf.mat;
load mpc1.mat;

MPCCompWExlim = parammpc(Compfreq_min, Compfreq_Max, WTWexOut_min, WTWexOut_max); % Constraints
run("MPC.m");


%% Params


function [MPCCompWExlim, mpf, mpc1, ref_cnst] = parammpc(Compfreq_min, Compfreq_Max, WTWexOut_min, WTWexOut_max, mpf, mpc1, ref_cnst)

MPCCompWExlim.MV_min    = Compfreq_min;   MPCCompWExlim.MV_Max = Compfreq_Max;      % Min Max comp Freq -- ManipulatedVariables
MPCCompWExlim.OutVarMin = WTWexOut_min;   MPCCompWExlim.OutVarMax =  WTWexOut_max;  % Min and Max Water Temp in WEx outlet


end


%MPCfun_compwex = MPC_compwex(MPCCompWExlim, Ts);
%mpc1 = MPCfun_compwex;


