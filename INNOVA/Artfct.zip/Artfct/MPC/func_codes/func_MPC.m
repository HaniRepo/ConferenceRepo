%% internal param

Ts = .05; %Sampling time
MVScFactor = 1;
assignin('base', 'ref_cnst', ref_cnst);

MPC_ManipulatedVariablesRate = .1;   %ManipulatedVariablesRate
MPC_OutputVariables          = 1 ;    %OutputVariables
MPC_PredictionHorizon        = 10;   %PredictionHorizon
MPC_ControlHorizon           = 2 ;    %ControlHorizon


%%  ManipulatedVariables

mpc1.MV(1).Min = MPCCompWExlim.MV_min;       mpc1.ManipulatedVariables.Min  = MPCCompWExlim.MV_min; % Minimum Comp Freq
mpc1.MV(1).Max = MPCCompWExlim.MV_Max;       mpc1.ManipulatedVariables.Max  = MPCCompWExlim.MV_Max; % Max comp Freq
mpc1.MV(1).RateMin = -inf;     mpc1.ManipulatedVariables.RateMin = -inf;   %  Minimum Comp Freq rate
mpc1.MV(1).RateMax = inf;      mpc1.ManipulatedVariables.RateMax = inf;    %  Max Comp Freq rate
mpc1.ManipulatedVariables.Target = 'nominal';
mpc1.ManipulatedVariables.ScaleFactor  = MVScFactor;


%%  Output Variables

mpc1.OutputVariables.Min = MPCCompWExlim.OutVarMin; %mpc1.MO(1).Min = -90; % Min Water Temp in WEx outlet    
mpc1.OutputVariables.Max = MPCCompWExlim.OutVarMax;  %mpc1.MO(1).Max = 90; % Max Water Temp in WEx outlet   
mpc1.OutputVariables.Name = 'Delay';


%% MPC Settings

mpc1.Ts= Ts;  % Sampling time
mpc1.Weights.ManipulatedVariablesRate  = MPC_ManipulatedVariablesRate;  %
mpc1.Weights.OutputVariables           = MPC_OutputVariables;    %
mpc1.PredictionHorizon                 = MPC_PredictionHorizon;
mpc1.ControlHorizon                    = MPC_ControlHorizon;
%review(mpc1);



%% Sim  

out = sim('MPC_MIMO1.slx', 'ReturnWorkspaceOutputs','on'); 
%out = sim_out ;


%% Plot
figure()
yyaxis left
t2 = out.simout.time .*(1/Ts);
plot(t2, out.simout.signals.values(:,2), 'LineWidth',2);
hold on
plot(t2, out.simout.signals.values(:,1), 'LineWidth',2);
xlabel('t (min)'); ylabel('Temperature');
axis([0  100 0 80])
set(gcf,'color','w');


yyaxis right

plot(t2, out.compfreq.signals.values, 'LineWidth',2);

xlabel('t (min)'); ylabel('Compressor Freq');
set(gcf,'color','w');
axis([0  100 0 110])
legend( 'Water Temp WEx outlet reference', 'Water Temp WEx outlet','Compressor Freq');


figure()
S = stepinfo(out.simout.signals.values(:,1),t2);
risetime(out.simout.signals.values(:,1));
