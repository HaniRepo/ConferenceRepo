

Ts = .05;
MV_min    = 0;   MV_Max = 94;
OutVarMin = -90; OutVarMax =  90;
MVScFactor = 1;



%% ManipulatedVariables MISO
mpc_mimo.MV(1).Min = MV_min;       mpc_mimo.ManipulatedVariables.Min  = 0;
mpc_mimo.MV(1).Max = MV_Max;       mpc_mimo.ManipulatedVariables.Max = 94; 
mpc_mimo.MV(1).RateMin = -inf;     mpc_mimo.ManipulatedVariables.RateMin = -inf;  
mpc_mimo.MV(1).RateMax = inf;      mpc_mimo.ManipulatedVariables.RateMax = inf; 
mpc_mimo.ManipulatedVariables.Target = 'nominal';
mpc_mimo.ManipulatedVariables.ScaleFactor  = MVScFactor;



%% Output Variables MISO
mpc_mimo.OutputVariables.Min = OutVarMin; %mpc1.MO(1).Min = -90;     
mpc_mimo.OutputVariables.Max = OutVarMax;  %mpc1.MO(1).Max = 90;  
mpc_mimo.OutputVariables.Name = 'Delay';



%%
mpc1.Ts= .05;
mpc1.Weights.ManipulatedVariablesRate  = .1;
mpc1.Weights.OutputVariables = 1;
mpc1.PredictionHorizon = 10;
mpc1.ControlHorizon = 2;
%review(mpc1);


  

%%
open('MPC_1_1D.slx');
out = sim('MPC_1_1D.slx', 'ReturnWorkspaceOutputs','on'); 



%%

figure()

t2 = out.simout.time .*(1/Ts);
hold on
plot(t2, out.simout.signals.values(:,1), 'LineWidth',2);
%plot(t2, out.simout.signals.values(:,2), 'LineWidth',2); SISO removed
plot(t2, out.simout.signals.values(:,3), 'LineWidth',2);
plot(t2, out.simout.signals.values(:,4), 'LineWidth',2);

xlabel('t (min)'); ylabel('Water Temp WEx outlet Temperature');
axis([950  1200 36 41])

set(gcf,'color','w');

legend( 'Multivariable MPC', 'PID','Reference');
grid on

S = stepinfo(out.simout.signals.values(900:1300,1),t2(900:1300)); % MIMO
S2 = stepinfo(out.simout.signals.values(900:1300,2),t2(900:1300)); % SISO
S3 = stepinfo(out.simout.signals.values(900:1300,3),t2(900:1300)); % PID





