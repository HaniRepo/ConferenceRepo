clear all;
close all;
clc;



load('modif_mpf.mat');
load('modif_mpf_cooling.mat');
load('modif_mpf_mimo.mat');


load mpc_mimo; mpc_mimo = mpc1; clear mpc1;
load mpf_mimo; mpf_mimo = mpf; clear mpf;


%Cooling
load mpf_cooling;  mpf_cooling = mpf; clear mpf;
load MPC_Cooling; 


load mpc1; 
load mpf;

Ts = .05;
MV_min    = 0;   MV_Max = 94;
OutVarMin = -90; OutVarMax =  90;
MVScFactor = 1;



%% ManipulatedVariables siso
mpc1.MV(1).Min = MV_min;       mpc1.ManipulatedVariables.Min  = 0;
mpc1.MV(1).Max = MV_Max;       mpc1.ManipulatedVariables.Max = 94; 
mpc1.MV(1).RateMin = -inf;     mpc1.ManipulatedVariables.RateMin = -inf;  
mpc1.MV(1).RateMax = inf;      mpc1.ManipulatedVariables.RateMax = inf; 
mpc1.ManipulatedVariables.Target = 'nominal';
mpc1.ManipulatedVariables.ScaleFactor  = MVScFactor;

%% Output Variables siso
mpc1.OutputVariables.Min = OutVarMin; %mpc1.MO(1).Min = -90;     
mpc1.OutputVariables.Max = OutVarMax;  %mpc1.MO(1).Max = 90;  
mpc1.OutputVariables.Name = 'Delay';


%% ManipulatedVariables MISO
mpc_mimo.MV(1).Min = MV_min;       mpc_mimo.ManipulatedVariables.Min  = 0;
mpc_mimo.MV(1).Max = MV_Max;       mpc_mimo.ManipulatedVariables.Max = 94; 
mpc_mimo.MV(1).RateMin = -inf;     mpc_mimo.ManipulatedVariables.RateMin = -inf;  
mpc_mimo.MV(1).RateMax = inf;      mpc_mimo.ManipulatedVariables.RateMax = inf; 
mpc_mimo.ManipulatedVariables.Target = 'nominal';
mpc_mimo.ManipulatedVariables.ScaleFactor  = MVScFactor;



%% Output Variables MISO
mpc_mimo.OutputVariables.Min = OutVarMin; %mpc1.MO(1).Min = -90;     
mpc_mimo.OutputVariables.Max = OutVarMax;  %mpc1.MO(1).Max = 90;  
mpc_mimo.OutputVariables.Name = 'Delay';



%%
mpc1.Ts= .05;
mpc1.Weights.ManipulatedVariablesRate  = .1;
mpc1.Weights.OutputVariables = 1;
mpc1.PredictionHorizon = 10;
mpc1.ControlHorizon = 2;
%review(mpc1);

%%
open('Total_Arch.slx');
out = sim('Total_Arch.slx', 'ReturnWorkspaceOutputs','on'); 



%%

figure()

t2 = out.simout_HPlant.time .*(1/Ts);
hold on
plot(t2, out.simout_HPlant.signals.values(:,1), 'LineWidth',2);
plot(t2, out.simout_HPlant.signals.values(:,2), 'LineWidth',2);
plot(t2, out.simout_HPlant.signals.values(:,3), 'LineWidth',2);
plot(t2, out.simout_HPlant.signals.values(:,4), 'LineWidth',2);

xlabel('t (min)'); ylabel('Water Temp WEx outlet Temperature');
axis([950  1200 36 41])

set(gcf,'color','w');

legend( 'MPC A', 'MPC B', 'PID','Reference');
grid on

S = stepinfo(out.simout_HPlant.signals.values(900:1300,1),t2(900:1300)); % MIMO
S2 = stepinfo(out.simout_HPlant.signals.values(900:1300,2),t2(900:1300)); % SISO
S3 = stepinfo(out.simout_HPlant.signals.values(900:1300,3),t2(900:1300)); % PID

title('Illustrated for Heating Plant event');



